#!/usr/bin/env bash
set -euo pipefail

QCOW="/vm/centos9.qcow2"
SEED="/vm/seed.iso"

if [[ ! -f "$QCOW" || ! -f "$SEED" ]]; then
  echo "QCOW or seed.iso missing inside image" >&2
  exit 1
fi

ACCEL_OPTS=()
if [ -e /dev/kvm ]; then
  echo "[*] Using KVM"
  ACCEL_OPTS=(-enable-kvm -cpu host)
else
  echo "[*] KVM not available; using TCG"
  ACCEL_OPTS=(-accel tcg -cpu max)
fi

NET_OPTS=(-netdev user,id=net0,hostfwd=tcp::2222-:22,hostfwd=tcp::8080-:8080 -device virtio-net-pci,netdev=net0)

exec qemu-system-x86_64 \
  "${ACCEL_OPTS[@]}" \
  -m 2048 -smp 2 \
  -drive "if=virtio,file=${QCOW},format=qcow2" \
  -drive "if=virtio,file=${SEED},format=raw,readonly=on,media=cdrom" \
  -device virtio-rng-pci \
  -nographic -serial mon:stdio \
  "${NET_OPTS[@]}"
