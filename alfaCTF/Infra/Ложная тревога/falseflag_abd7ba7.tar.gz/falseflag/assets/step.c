#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

extern char **environ;

static void _log(const char *msg) {
    write(2, msg, strlen(msg));
}

static void die(const char *msg) {
    _log(msg);
    _exit(1);
}

static int is_abcd(char c) {
    return (c=='A' || c=='B' || c=='C' || c=='D');
}

static void log_ctx(void) {
    int fd = open("/proc/self/attr/current", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return;
    char buf[256];
    ssize_t n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return;
    size_t len = (size_t)n;
    if (len > 0 && buf[len - 1] == '\n') len--;
    buf[len] = '\0';
    (void)write(2, buf, len);
    (void)write(2, "\n", 1);
}

int main(int argc, char **argv) {
    log_ctx();
    const char *chain = (argc >= 2) ? argv[1] : NULL;

    if (chain && *chain) {
        char step = chain[0];
        if (!is_abcd(step)) die("bad password\n");

        char next[16];
        memcpy(next, "/opt/task/", 10);
        next[10]  = step;
        next[11] = '\0';

        const char *rest = chain + 1;

        char *const nargv[] = { next, (char*)rest, NULL };

        _log(chain);
        _log("\n");
        execve(next, nargv, NULL);
        die("execve failed\n");
    }

    int fd = open("/flag", O_RDONLY | O_CLOEXEC);
    if (fd < 0) die("flag open failed\n");

    char buf[4096];
    for (;;) {
        ssize_t r = read(fd, buf, sizeof buf);
        if (r == 0) break;
        if (r < 0) die("flag read failed");
        ssize_t off = 0;
        while (off < r) {
            ssize_t w = write(1, buf + off, (size_t)(r - off));
            if (w < 0) die("flag write failed\n");
            off += w;
        }
    }
    close(fd);
    return 0;
}
