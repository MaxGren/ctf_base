from flask import Flask, request, render_template
import subprocess

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    result = ""
    if request.method == 'POST':
        key = request.form.get('key', '').strip()
        if set(key) <= set('ABCD'):
            p = subprocess.run(["/opt/task/step", key], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=False)
            if p.returncode == 0:
                result = p.stdout.strip()
            else:
                result = 'Wrong key'
        else:
            result = 'Wrong key'
    return render_template("index.html", result=result)