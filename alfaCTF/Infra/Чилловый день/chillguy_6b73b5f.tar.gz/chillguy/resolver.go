package main

import (
	"context"
	"fmt"
	"log"
	"net"
	"time"
	"net/http"

	"github.com/miekg/dns"
)

var (
	cache = make(map[string]cacheEntry)
)

type cacheEntry struct {
	rrs []dns.RR
	expiresAt time.Time
}

func makeQuery(c *dns.Client, dnsServer, host string, rrtype uint16) (*dns.Msg, error) {
	msg := new(dns.Msg)
	msg.Id = dns.Id()
	msg.RecursionDesired = true
	msg.Question = []dns.Question{
		{
			dns.Fqdn(host),
			rrtype,
			dns.ClassINET,
		},
	}

	r, _, err := c.Exchange(msg, dnsServer)
	if err != nil {
		return nil, err
	}

	return r, nil
}

func lookupHostWithCache(host string) ([]dns.RR, error) {
	if entry, ok := cache[host]; ok && time.Now().Before(entry.expiresAt) {
		return entry.rrs, nil
	}

	clientConfig, err := dns.ClientConfigFromFile("/etc/resolv.conf")
	if err != nil {
		return nil, err
	}

	dnsServer := clientConfig.Servers[0] + ":53"

	c := new(dns.Client)

	r2, err := makeQuery(c, dnsServer, host, dns.TypeAAAA)
	if err != nil {
		return nil, err
	}

	r1, err := makeQuery(c, dnsServer, host, dns.TypeA)
	if err != nil {
		return nil, err
	}

	r := append(r1.Answer, r2.Answer...)

	cache[host] = cacheEntry{
		rrs: r,
		expiresAt: time.Now().Add(time.Minute * 5),
	}

	return r, nil
}

func isHostAllowed(host string) bool {
	rrs, err := lookupHostWithCache(host)
	if err != nil {
		log.Println(err)
		return false
	}

	hasValidRecords := false
	for _, rr := range rrs {
		fmt.Println(rr.String())
		if rr.Header().Rrtype == dns.TypeA {
			// SECURITY: disallow metadata service
			if rr.Header().Name == "169.254.169.254" {
				return false
			} else {
				hasValidRecords = true
			}
		}
	}

	return hasValidRecords
}

func createTransport() *http.Transport {
	return &http.Transport{
		DialContext: func(ctx context.Context, network string, addr string) (conn net.Conn, err error) {
			host, port, err := net.SplitHostPort(addr)
			if err != nil {
				return nil, err
			}
			if !isHostAllowed(host) {
				return nil, fmt.Errorf("host %s is not allowed", host)
			}
			ips, err := lookupHostWithCache(host)
			if err != nil {
				return nil, err
			}
			for _, ip := range ips {
				var dialer net.Dialer
				conn, err = dialer.DialContext(ctx, network, net.JoinHostPort(ip.Header().Name, port))
				if err == nil {
					break
				}
			}
			return
		},
	}
}
