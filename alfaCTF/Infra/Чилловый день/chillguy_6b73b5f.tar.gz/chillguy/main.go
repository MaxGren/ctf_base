package main

import (
	"bytes"
	"fmt"
	"html/template"
	"io"
	"log"
	"net/http"
	"net/url"
	"os"
	"time"
	"golang.org/x/net/html"
)

var (
	t *http.Transport
)

type ArchiveItem struct {
	Title       string    `json:"title"`
	URL         string    `json:"url"`
	ArchiveDate time.Time `json:"archive_date"`
	FileSize    int64     `json:"file_size"`
	HTML       string     `json:"html"`
}

type ArchiveService struct {
	templates *template.Template
}

func NewArchiveService() *ArchiveService {
	templates := template.Must(template.ParseGlob("templates/*.html"))
	return &ArchiveService{
		templates: templates,
	}
}

func (as *ArchiveService) handleHome(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}

	data := map[string]interface{}{
		"Archives": []ArchiveItem{},
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := as.templates.ExecuteTemplate(w, "index.html", data); err != nil {
		http.Error(w, "Template error", http.StatusInternalServerError)
	}
}

func (as *ArchiveService) handleArchiveWebsite(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	websiteURL := r.FormValue("url")
	if websiteURL == "" {
		http.Error(w, "URL is required", http.StatusBadRequest)
		return
	}

	parsedURL, err := url.Parse(websiteURL)
	if err != nil || parsedURL.Scheme == "" {
		http.Error(w, "Invalid URL", http.StatusBadRequest)
		return
	}

	archiveInfo, err := as.archiveWebsite(websiteURL)
	if err != nil {
		log.Printf("Failed to archive website %s: %v", websiteURL, err)
		as.showWebsitePreview(w, r, nil, websiteURL, "Не удалось архивировать сайт: "+err.Error())
		return
	}

	as.showWebsitePreview(w, r, archiveInfo, websiteURL, "")
}

func (as *ArchiveService) archiveWebsite(websiteURL string) (*ArchiveItem, error) {
	client := &http.Client{
		Transport: t,
	}

	resp, err := client.Get(websiteURL)
	if err != nil {
		return nil, fmt.Errorf("failed to fetch website: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("website returned status: %d", resp.StatusCode)
	}

	htmlContent, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read HTML: %v", err)
	}

	doc, err := html.Parse(bytes.NewReader(htmlContent))
	if err != nil {
		return nil, fmt.Errorf("failed to parse HTML: %v", err)
	}

	title := as.extractTitle(doc)
	if title == "" {
		title = websiteURL
	}

	archiveInfo := &ArchiveItem{
		Title:       title,
		URL:         websiteURL,
		ArchiveDate: time.Now(),
		HTML:       string(htmlContent),
		FileSize:    int64(len(string(htmlContent))),
	}

	return archiveInfo, nil
}

func (as *ArchiveService) extractTitle(doc *html.Node) string {
	var title string
	var traverse func(*html.Node)
	traverse = func(n *html.Node) {
		if n.Type == html.ElementNode && n.Data == "title" {
			if n.FirstChild != nil {
				title = n.FirstChild.Data
				return
			}
		}
		for c := n.FirstChild; c != nil; c = c.NextSibling {
			traverse(c)
		}
	}
	traverse(doc)
	return title
}

func (as *ArchiveService) showWebsitePreview(w http.ResponseWriter, r *http.Request, archiveInfo *ArchiveItem, websiteURL string, errMsg string) {

	data := map[string]interface{}{
		"Archive":       archiveInfo,
		"URL":           websiteURL,
		"Error":         errMsg,
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := as.templates.ExecuteTemplate(w, "website-preview.html", data); err != nil {
		http.Error(w, "Template error", http.StatusInternalServerError)
	}
}

func main() {
	service := NewArchiveService()

	http.HandleFunc("/", service.handleHome)
	http.HandleFunc("/archive-website", service.handleArchiveWebsite)

	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}


	t = createTransport()

	log.Printf("Starting chill archive service on port %s", port)
	log.Fatal(http.ListenAndServe(":"+port, nil))
}
