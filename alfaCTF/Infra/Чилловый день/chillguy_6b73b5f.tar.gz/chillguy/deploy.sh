#!/bin/bash

chown -R root:root /home/alfactf/

echo 'alfa{XXXXXXXXXXXXXXXXXXXXXX}' > /home/alfactf/flag.txt

chmod -R 755 /home/alfactf/
