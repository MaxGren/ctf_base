package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"time"
	"os"
)

func VerifyRecaptcha(response string) (bool, error) {
	secret := os.Getenv("RECAPTCHA_SECRET_KEY")
	if secret == "" {
		return true, nil
	}

	data := url.Values{
		"secret":   {secret},
		"response": {response},
	}

	resp, err := http.PostForm("https://www.google.com/recaptcha/api/siteverify", data)
	if err != nil {
		return false, fmt.Errorf("failed to verify reCAPTCHA: %v", err)
	}
	defer resp.Body.Close()

	var result struct {
		Success     bool      `json:"success"`
		Score       float64   `json:"score"`
		Action      string    `json:"action"`
		ChallengeTS time.Time `json:"challenge_ts"`
		Hostname    string    `json:"hostname"`
		ErrorCodes  []string  `json:"error-codes"`
	}

	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return false, fmt.Errorf("failed to decode reCAPTCHA response: %v", err)
	}

	return result.Success, nil
} 