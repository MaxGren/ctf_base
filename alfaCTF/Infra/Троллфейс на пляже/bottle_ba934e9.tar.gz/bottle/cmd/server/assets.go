package main

import "embed"

//go:embed web/*
var staticFiles embed.FS 