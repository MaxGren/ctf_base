package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"time"
)

const (
	maxAsmBytes   = 64 * 1024 // 64 KB
	compileTimeout = 10 * time.Second
	runTimeout     = 2 * time.Minute
)

type runRequest struct {
	Asm  string `json:"asm"`
	RecaptchaResponse string `json:"recaptcha_response"`
}

type runResponse struct {
	Stdout string `json:"stdout"`
	Stderr string `json:"stderr"`
	ExitCode int    `json:"exit_code"`
	Error   string `json:"error,omitempty"`
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func compileAsm(tmpDir string, asm string) (string, string, error) {
	asmPath := filepath.Join(tmpDir, "prog.s")
	binPath := filepath.Join(tmpDir, "prog")
	if err := os.WriteFile(asmPath, []byte(asm), 0600); err != nil {
		return "", "", fmt.Errorf("write asm: %w", err)
	}
	// Assemble and link statically with minimal runtime, entrypoint _start
	cmd := exec.CommandContext(context.Background(), "gcc",
		"-x", "assembler",
		"-nostdlib", "-static",
		"-Wl,-e,_start,-z,noexecstack",
		"-o", binPath, asmPath,
	)
	var out bytes.Buffer
	debug := os.Getenv("DEBUG")
	if debug != "" {
		cmd.Stdout = &out
		cmd.Stderr = &out
	}
	cmd.Env = []string{"PATH=/usr/bin:/bin:/usr/sbin:/sbin"}
	if err := runWithTimeout(cmd, compileTimeout); err != nil {
		return "", out.String(), fmt.Errorf("build: %w", err)
	}
	if err := os.Chmod(binPath, 0700); err != nil {
		return "", "", fmt.Errorf("chmod bin: %w", err)
	}
	return binPath, "", nil
}

func runWithTimeout(cmd *exec.Cmd, d time.Duration) error {
	ctx, cancel := context.WithTimeout(context.Background(), d)
	defer cancel()
	if err := cmd.Start(); err != nil {
		return err
	}
	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()
	select {
	case <-ctx.Done():
		_ = cmd.Process.Kill()
		<-done
		return context.DeadlineExceeded
	case err := <-done:
		return err
	}
}

func runSandboxed(runnerPath string, binPath string, input []byte) (stdout string, stderr string, exitCode int, err error) {
	ctx, cancel := context.WithTimeout(context.Background(), runTimeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, runnerPath, append([]string{binPath})...)
	var outBuf, errBuf bytes.Buffer
	cmd.Stdout = &outBuf
	cmd.Stderr = &errBuf
	stdin, _ := cmd.StdinPipe()
	if err = cmd.Start(); err != nil {
		log.Println(err)
		return "", "", -1, err
	}
	if len(input) > 0 {
		_, _ = io.Copy(stdin, bytes.NewReader(input))
	}
	_ = stdin.Close()
	err = cmd.Wait()
	if ctx.Err() == context.DeadlineExceeded {
		return outBuf.String(), errBuf.String(), -1, errors.New("timeout")
	}
	exit := 0
	var ee *exec.ExitError
	if err != nil {
		log.Println(err, outBuf.String(), errBuf.String())
		if errors.As(err, &ee) {
			exit = ee.ExitCode()
		} else {
			return outBuf.String(), errBuf.String(), -1, err
		}
	}
	if exit > 1 {
		exit = 1
	}
	return outBuf.String(), errBuf.String(), exit, nil
}

func handleRun(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	var req runRequest
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, maxAsmBytes+4096)).Decode(&req); err != nil {
		writeJSON(w, http.StatusBadRequest, runResponse{Error: "invalid json", ExitCode: -1})
		return
	}
	success, err := VerifyRecaptcha(req.RecaptchaResponse)
	if err != nil {
		writeJSON(w, http.StatusBadRequest, runResponse{Error: "can't verify recaptcha", ExitCode: -1})
		return
	}

	if !success {
		writeJSON(w, http.StatusBadRequest, runResponse{Error: "recaptcha failed", ExitCode: -1})
		return
	}

	if len(req.Asm) == 0 || len(req.Asm) > maxAsmBytes {
		writeJSON(w, http.StatusBadRequest, runResponse{Error: "asm size invalid", ExitCode: -1})
		return
	}

	tmpDir, err := os.MkdirTemp("", "asmrun-")
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, runResponse{Error: "tmpdir", ExitCode: -1})
		return
	}
	defer os.RemoveAll(tmpDir)

	binPath, compErrOut, err := compileAsm(tmpDir, req.Asm)
	if err != nil {
		writeJSON(w, http.StatusBadRequest, runResponse{Error: err.Error() + "\n" + compErrOut, ExitCode: -1})
		return
	}

	runnerPath, err := exec.LookPath("runner")
	if err != nil {
		runnerPath = filepath.Join(filepath.Dir(os.Args[0]), "runner")
	}

	stdout, stderr, exit, err := runSandboxed(runnerPath, binPath, nil)
	resp := runResponse{Stdout: stdout, Stderr: stderr, ExitCode: exit}
	if err != nil {
		resp.Error = err.Error()
	}
	writeJSON(w, http.StatusOK, resp)
}

func main() {
	http.HandleFunc("/run", handleRun)
	var webFS fs.FS = staticFiles
	if sub, err := fs.Sub(staticFiles, "web"); err == nil {
		webFS = sub
	}
	http.Handle("/", http.FileServer(http.FS(webFS)))

	addr := ":8080"
	if v := os.Getenv("PORT"); v != "" {
		addr = ":" + v
	}
	log.Printf("listening on %s", addr)
	log.Fatal(http.ListenAndServe(addr, nil))
} 