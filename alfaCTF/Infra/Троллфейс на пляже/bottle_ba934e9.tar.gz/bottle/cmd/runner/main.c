// Build: gcc -O2 -Wall -Wextra -o runner main.c -lseccomp
// Run:   ./runner <bin> [args...]

#define _GNU_SOURCE
#if !defined(__linux__)
# error "This program is Linux-only."
#endif

#include <errno.h>
#include <seccomp.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>
#include <linux/prctl.h>

extern char **environ;

static const char *allow_names[] = {
    "read",
    "connect",
    "socket",
    "open",
    "close",
    "exit",
    "execve",
};

static void set_rlimits(void) {
    struct rlimit rl;

    rl.rlim_cur = rl.rlim_max = 2;
    (void)setrlimit(RLIMIT_CPU, &rl);

    rl.rlim_cur = rl.rlim_max = 128u << 20;
    (void)setrlimit(RLIMIT_AS, &rl);

    rl.rlim_cur = rl.rlim_max = 1u << 20;
    (void)setrlimit(RLIMIT_FSIZE, &rl);

    rl.rlim_cur = rl.rlim_max = 0;
    (void)setrlimit(RLIMIT_CORE, &rl);

    rl.rlim_cur = rl.rlim_max = 64;
    (void)setrlimit(RLIMIT_NOFILE, &rl);

    rl.rlim_cur = rl.rlim_max = 0;
    (void)setrlimit(RLIMIT_NPROC, &rl);
}

static int install_seccomp(void) {
    if (seccomp_api_get() < 2) {
        errno = EOPNOTSUPP;
        return -1;
    }

    scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_ERRNO(EPERM));
    if (!ctx) return -1;

    for (size_t i = 0; i < sizeof(allow_names)/sizeof(allow_names[0]); ++i) {
        int sc = seccomp_syscall_resolve_name(allow_names[i]);
        if (sc == __NR_SCMP_ERROR) {
            seccomp_release(ctx);
            errno = EINVAL;
            return -1;
        }
        if (seccomp_rule_add(ctx, SCMP_ACT_ALLOW, sc, 0) != 0) {
            int saved = errno;
            seccomp_release(ctx);
            errno = saved;
            return -1;
        }
    }

    if (seccomp_load(ctx) != 0) {
        int saved = errno;
        seccomp_release(ctx);
        errno = saved;
        return -1;
    }

    seccomp_release(ctx);
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: %s <bin> [args...]\n", argv[0]);
        return 2;
    }

    const char *bin = argv[1];
    char **args = &argv[1];

    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0) {
        perror("prctl PR_SET_NO_NEW_PRIVS");
        return 1;
    }

    set_rlimits();

    if (install_seccomp() != 0) {
        syscall(SYS_exit, 1);
    }

    execve(bin, args, environ);
    syscall(SYS_exit, 1);
}
