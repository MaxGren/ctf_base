import os
import redis
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options

REDIS_URL = os.getenv('REDIS_URL', 'redis://redis:6379/0')
WEB_BASE = os.getenv('WEB_BASE', 'http://web:8080')
BOT_USERNAME = os.getenv('BOT_USERNAME', 'pavel')
BOT_PASSWORD = os.getenv('BOT_PASSWORD', 'pavelpass')

def make_driver():
	options = Options()
	options.add_argument('--headless=new')
	options.add_argument('--no-sandbox')
	options.add_argument('start-maximized')
	options.add_argument('disable-infobars')
	options.add_argument('--disable-extensions')
	options.add_argument('--disable-dev-shm-usage')
	options.add_argument('--disable-gpu')
	options.add_argument('--disable-default-apps')
	options.add_argument('--no-first-run')
	options.add_argument('--no-default-browser-check')
	options.add_argument('--disable-client-side-phishing-detection')
	options.add_argument('--disable-popup-blocking')
	options.add_argument('--disable-translate')
	options.add_argument('--ignore-certificate-errors')
	options.add_argument('--ignore-ssl-errors')
	options.add_argument('--ignore-certificate-errors-spki-list')
	options.add_argument('--unsafely-treat-insecure-origin-as-secure=http://web:8080')
	driver = webdriver.Chrome(options=options)
	return driver

def extract_first_post_text(driver, user_uuid: str) -> str:
	profile_url = f"{WEB_BASE}/profile/{user_uuid}"
	driver.get(profile_url)
	try:
		WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, 'posts')))
	except Exception:
		return ''
	try:
		container = driver.find_element(By.ID, 'posts')
		first = container.find_elements(By.CSS_SELECTOR, 'div.border.border-slate-200.p-3.flex.gap-3')[0]
		content_el = first.find_element(By.CSS_SELECTOR, 'div.mt-1')
		text = content_el.text.strip()

		try:
			WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.ID, 'does-not-exist-just-sleeping')))
		except Exception:
			pass
		return text
	except Exception:
		return ''


def login_as_bot(driver):
	driver.get(WEB_BASE)
	FLAG = os.getenv('FLAG', 'alfa{***REDACTED***}')
	driver.add_cookie({'name' : 'flag', 'value' : FLAG, 'domain' : f"web", 'path': '/', 'httpOnly': False, 'secure': False})

	try:
		WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, 'login-form')))
		form = driver.find_element(By.ID, 'login-form')
		form.find_element(By.NAME, 'username').clear()
		form.find_element(By.NAME, 'username').send_keys(BOT_USERNAME)
		form.find_element(By.NAME, 'password').clear()
		form.find_element(By.NAME, 'password').send_keys(BOT_PASSWORD)
		form.find_element(By.CSS_SELECTOR, 'button').click()
		WebDriverWait(driver, 10).until(EC.url_matches(r".*/profile/.*"))
		return True
	except Exception:
		return False


def post_text(driver, text: str) -> bool:
	try:
		WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, 'post-content')))
		area = driver.find_element(By.ID, 'post-content')
		area.clear()
		area.send_keys(text)
		btn = driver.find_element(By.ID, 'post-submit')
		btn.click()
		WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.ID, 'posts')))
		try:
			WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.ID, 'does-not-exist-just-sleeping')))
		except Exception:
			pass
		return True
	except Exception:
		return False


def main():
	driver = make_driver()

	r = redis.StrictRedis.from_url(REDIS_URL, decode_responses=True)
	while True:
		item = r.blpop('bot.visit_url', 0)
		print(f"Processing item {item}", flush=True)
		if not item:
			continue
		user_uuid = item[1]
		print(f"Processing user {user_uuid}", flush=True)
		driver = make_driver()
		try:
			text = extract_first_post_text(driver, user_uuid)
			if not text:
				print('No text found in top post, skipping', flush=True)
				continue
			ok = login_as_bot(driver)
			if not ok:
				print('Login failed', flush=True)
				continue
			if post_text(driver, text):
				print('Posted successfully', flush=True)
			else:
				print('Post failed', flush=True)
		except Exception as ex:
			print(f"ERROR: {ex}", flush=True)
		finally:
			try:
				driver.quit()
			except Exception:
				pass


if __name__ == '__main__':
	print('Starting bot', flush=True)
	main() 