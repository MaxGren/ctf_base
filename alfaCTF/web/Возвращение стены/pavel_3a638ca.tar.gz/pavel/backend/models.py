from datetime import datetime
from typing import List
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import String, Text, ForeignKey, DateTime
from database import Base

class User(Base):
	__tablename__ = "users"

	id: Mapped[int] = mapped_column(primary_key=True, index=True)
	uuid: Mapped[str] = mapped_column(String(36), unique=True, index=True)
	username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
	password_hash: Mapped[str] = mapped_column(String(255))
	status: Mapped[str] = mapped_column(Text, default="")
	avatar_url: Mapped[str] = mapped_column(String(512), default="")
	created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

	posts: Mapped[List["Post"]] = relationship(back_populates="user", cascade="all, delete-orphan")
	files: Mapped[List["FileMeta"]] = relationship(back_populates="user", cascade="all, delete-orphan")

class Post(Base):
	__tablename__ = "posts"

	id: Mapped[int] = mapped_column(primary_key=True, index=True)
	user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
	content: Mapped[str] = mapped_column(Text)
	created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

	user: Mapped[User] = relationship(back_populates="posts")

class FileMeta(Base):
	__tablename__ = "files"

	id: Mapped[int] = mapped_column(primary_key=True, index=True)
	user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
	stored_name: Mapped[str] = mapped_column(String(255))
	original_name: Mapped[str] = mapped_column(String(255))
	content_type: Mapped[str] = mapped_column(String(128))
	size: Mapped[int] = mapped_column()
	uploaded_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

	user: Mapped[User] = relationship(back_populates="files") 