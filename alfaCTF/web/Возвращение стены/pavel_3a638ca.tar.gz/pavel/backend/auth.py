import os
from datetime import datetime, timedelta
from typing import Optional
from fastapi import Depends, HTTPException, status, Request
from jose import jwt, JWTError
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from database import get_db
from models import User

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
JWT_SECRET = os.getenv("JWT_SECRET", "dev_jwt_secret")
JWT_ALG = os.getenv("JWT_ALGORITHM", "HS256")
JWT_EXPIRE_MIN = int(os.getenv("JWT_EXPIRE_MINUTES", "43200"))

TOKEN_COOKIE_NAME = "access_token"

def hash_password(password: str) -> str:
	return pwd_context.hash(password)

def verify_password(password: str, password_hash: str) -> bool:
	return pwd_context.verify(password, password_hash)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
	to_encode = data.copy()
	expire = datetime.utcnow() + (expires_delta or timedelta(minutes=JWT_EXPIRE_MIN))
	to_encode.update({"exp": expire})
	return jwt.encode(to_encode, JWT_SECRET, algorithm=JWT_ALG)


def set_token_cookie(response, token: str) -> None:
	response.set_cookie(
		key=TOKEN_COOKIE_NAME,
		value=token,
		httponly=True,
		secure=False,
		samesite="lax",
		max_age=JWT_EXPIRE_MIN * 60,
		path="/",
	)


def clear_token_cookie(response) -> None:
	response.delete_cookie(TOKEN_COOKIE_NAME, path="/")


def get_current_user(request: Request, db: Session = Depends(get_db)) -> User:
	token = request.cookies.get(TOKEN_COOKIE_NAME)
	if not token:
		raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
	try:
		payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
		username: str = payload.get("sub")
		if username is None:
			raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
	except JWTError:
		raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
	user = db.query(User).filter(User.username == username).first()
	if not user:
		raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED)
	return user


def get_optional_user(request: Request, db: Session) -> Optional[User]:
	token = request.cookies.get(TOKEN_COOKIE_NAME)
	if not token:
		return None
	try:
		payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
		username: str = payload.get("sub")
		if not username:
			return None
		user = db.query(User).filter(User.username == username).first()
		return user
	except JWTError:
		return None 