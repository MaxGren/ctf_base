import os
import uuid as uuidlib
from typing import List
from fastapi import APIRouter, Depends, File, UploadFile, HTTPException, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from database import get_db
from models import User, FileMeta
from auth import get_current_user

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "/app/uploads")

router = APIRouter()

@router.get("/user_files")
async def list_user_files(username: str = Query(...), db: Session = Depends(get_db)):
	user = db.query(User).filter(User.username == username).first()
	if not user:
		raise HTTPException(status_code=404, detail="User not found")
	files = (
		db.query(FileMeta)
		.filter(FileMeta.user_id == user.id)
		.order_by(FileMeta.uploaded_at.desc())
		.all()
	)
	return [
		{
			"stored_name": f.stored_name,
			"original_name": f.original_name,
			"size": f.size,
			"content_type": f.content_type,
			"url": f"/get-file?filename={f.stored_name}",
		}
		for f in files
	]

@router.get("/get-file")
async def get_uploaded_file(filename: str = Query(...)):
	base_name = os.path.basename(filename)
	file_path = os.path.join(UPLOAD_DIR, base_name)
	if not os.path.exists(file_path):
		raise HTTPException(status_code=404)
	return FileResponse(file_path)

@router.post("/upload")
async def upload_file(file: UploadFile = File(...), current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
	os.makedirs(UPLOAD_DIR, exist_ok=True)
	ext = os.path.splitext(file.filename)[1]
	stored_name = f"{uuidlib.uuid4().hex}{ext}"
	file_path = os.path.join(UPLOAD_DIR, stored_name)
	while os.path.exists(file_path):
		stored_name = f"{uuidlib.uuid4().hex}{ext}"
		file_path = os.path.join(UPLOAD_DIR, stored_name)
	with open(file_path, "wb") as f:
		content = file.file.read()
		f.write(content)
	meta = FileMeta(
		user_id=current_user.id,
		stored_name=stored_name,
		original_name=file.filename,
		content_type=file.content_type or "application/octet-stream",
		size=len(content),
	)
	db.add(meta)
	db.commit()
	db.refresh(meta)
	return {
		"stored_name": meta.stored_name,
		"original_name": meta.original_name,
		"url": f"/get-file?filename={meta.stored_name}",
	} 