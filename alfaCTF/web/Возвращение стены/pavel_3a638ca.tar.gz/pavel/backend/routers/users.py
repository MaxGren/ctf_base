import uuid as uuidlib
from fastapi import APIRouter, Depends, Form, Response, HTTPException, Request, Query
from sqlalchemy.orm import Session
from database import get_db
from models import User
from auth import hash_password, verify_password, create_access_token, set_token_cookie, clear_token_cookie, get_current_user, get_optional_user

router = APIRouter()

@router.post("/register")
async def register(response: Response, username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
	username = (username or "").strip()
	if len(username) < 8 or len(password or "") < 8:
		raise HTTPException(status_code=400, detail="Минимальная длина логина и пароля — 8 символов")
	existing = db.query(User).filter(User.username == username).first()
	if existing:
		raise HTTPException(status_code=400, detail="Username already exists")
	user = User(
		username=username,
		uuid=str(uuidlib.uuid4()),
		password_hash=hash_password(password),
	)
	db.add(user)
	db.commit()
	db.refresh(user)
	token = create_access_token({"sub": user.username})
	set_token_cookie(response, token)
	return {"ok": True, "user": {"uuid": user.uuid, "username": user.username}}

@router.post("/login")
async def login(response: Response, username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
	user = db.query(User).filter(User.username == username).first()
	if not user or not verify_password(password, user.password_hash):
		raise HTTPException(status_code=401, detail="Invalid credentials")
	token = create_access_token({"sub": user.username})
	set_token_cookie(response, token)
	return {"ok": True, "user": {"uuid": user.uuid, "username": user.username}}

@router.post("/logout")
async def logout(response: Response):
	clear_token_cookie(response)
	return {"ok": True}

@router.get("/status")
async def get_status(user_uuid: str = Query(...), db: Session = Depends(get_db)):
	user = db.query(User).filter(User.uuid == user_uuid).first()
	if not user:
		raise HTTPException(status_code=404)
	return {"username": user.username, "status": user.status or "", "avatar_url": user.avatar_url or ""}

@router.post("/status")
async def set_status(status: str = Form(""), current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
	current_user.status = status[:1000]
	db.add(current_user)
	db.commit()
	return {"ok": True, "status": current_user.status}

@router.post("/avatar")
async def set_avatar(avatar_url: str = Form(""), current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
	current_user.avatar_url = avatar_url.strip()[:500]
	db.add(current_user)
	db.commit()
	return {"ok": True, "avatar_url": current_user.avatar_url}

@router.get("/me")
async def me(request: Request, db: Session = Depends(get_db)):
	user = get_optional_user(request, db)
	if not user:
		return {"user": None}
	return {"user": {"uuid": user.uuid, "username": user.username, "status": user.status, "avatar_url": user.avatar_url}} 