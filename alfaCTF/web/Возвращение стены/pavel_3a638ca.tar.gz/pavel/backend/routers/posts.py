from typing import List
from fastapi import APIRouter, Depends, Form, HTTPException, Query
from sqlalchemy.orm import Session
from database import get_db
from models import User, Post
from auth import get_current_user
import os
try:
	import redis as _redis
except Exception:
	_redis = None

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
BOT_USERNAME = os.getenv("BOT_USERNAME", "").strip()

MAX_POST_LEN = 512

router = APIRouter()

@router.get("/posts")
async def list_posts(
	user_uuid: str = Query(...),
	limit: int = Query(10, ge=1, le=50),
	page: int = Query(1, ge=1),
	db: Session = Depends(get_db),
):
	user = db.query(User).filter(User.uuid == user_uuid).first()
	if not user:
		raise HTTPException(status_code=404, detail="User not found")
	total_items = db.query(Post).filter(Post.user_id == user.id).count()
	offset = (page - 1) * limit
	posts = (
		db.query(Post)
		.filter(Post.user_id == user.id)
		.order_by(Post.id.desc())
		.offset(offset)
		.limit(limit)
		.all()
	)
	items = [
		{"id": p.id, "content": p.content, "created_at": p.created_at.isoformat()}
		for p in posts
	]
	total_pages = (total_items + limit - 1) // limit if total_items else 1
	return {
		"items": items,
		"page": page,
		"limit": limit,
		"total_items": total_items,
		"total_pages": total_pages,
	}

@router.post("/posts")
async def create_post(content: str = Form(...), current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
	text = (content or "").strip()
	if not text:
		raise HTTPException(status_code=400, detail="Пустой пост недопустим")
	if len(text) > MAX_POST_LEN:
		raise HTTPException(status_code=400, detail=f"Максимальная длина поста {MAX_POST_LEN} символов")
	post = Post(user_id=current_user.id, content=text)
	db.add(post)
	db.commit()
	db.refresh(post)
	try:
		total_posts = db.query(Post).filter(Post.user_id == current_user.id).count()
		if total_posts == 3 and _redis is not None and current_user.username != BOT_USERNAME:
			print('Enqueuing bot.visit_url', flush=True)
			r = _redis.StrictRedis.from_url(REDIS_URL, decode_responses=True)
			r.rpush("bot.visit_url", current_user.uuid)
	except Exception:
		pass
	return {"id": post.id, "content": post.content, "created_at": post.created_at.isoformat()} 