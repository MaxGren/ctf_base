import os
from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware
from database import create_database
from routers import users, posts, uploads

app = FastAPI(title="Mini Social Network")

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "/app/uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app.add_middleware(
	CORSMiddleware,
	allow_origins=["*"],
	allow_credentials=True,
	allow_methods=["*"],
	allow_headers=["*"],
)

app.include_router(users.router, tags=["auth"])
app.include_router(posts.router, tags=["posts"])
app.include_router(uploads.router, tags=["uploads"]) 

@app.on_event("startup")
def on_startup() -> None:
	create_database()
	bot_username = os.getenv("BOT_USERNAME", "").strip()
	bot_password = os.getenv("BOT_PASSWORD", "").strip()
	bot_avatar_url = "https://sun9-62.userapi.com/s/v1/ig2/U9vQzbe0H-g0r82kKQ1sHOaKLVlMHEzBX_WnYn1pfJ3p_HvPVnl3or9x0E6rM6VfiIWSJY4_2QzcIwi6Sd_rFE_-.jpg?quality=95&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360,480x480,540x540,640x640,720x720,1024x1024&from=bu&cs=1024x0"
	if bot_username and bot_password:
		try:
			from database import SessionLocal
			from models import User, Post
			from auth import hash_password
			import uuid as uuidlib
			db = SessionLocal()
			try:
				existing = db.query(User).filter(User.username == bot_username).first()
				if not existing:
					user = User(
						username=bot_username,
						uuid=str(uuidlib.uuid4()),
						password_hash=hash_password(bot_password),
						avatar_url=bot_avatar_url,
					)
					db.add(user)
					db.commit()
					try:
						welcome = Post(user_id=user.id, content="Добро пожаловать в мой микроблог!")
						db.add(welcome)
						db.commit()
					except Exception:
						pass
				else:
					if not (existing.avatar_url or "").strip():
						existing.avatar_url = bot_avatar_url
						db.add(existing)
						db.commit()
			finally:
				db.close()
		except Exception:
			pass 