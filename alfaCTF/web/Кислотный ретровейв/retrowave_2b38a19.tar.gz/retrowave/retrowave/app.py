from flask import Flask, render_template, send_from_directory, jsonify, request, send_file
from flask_cors import CORS
import os
import json
from mutagen import File
from mutagen.mp3 import MP3
from mutagen.wave import WAVE
from mutagen.oggvorbis import OggVorbis
from pathlib import Path

app = Flask(__name__)
CORS(app)

SONGS_DIRS = ['/copyright','/songs']
ALLOWED_EXTENSIONS = {'.mp3', '.wav', '.ogg', '.flac', '.m4a'}

def get_song_info(filepath):
    """Extract metadata from audio file"""
    try:
        if filepath.endswith('.mp3'):
            audio = MP3(filepath)
        elif filepath.endswith('.wav'):
            audio = WAVE(filepath)
        elif filepath.endswith('.ogg'):
            audio = OggVorbis(filepath)
        else:
            return None
        
        duration = int(audio.info.length) if hasattr(audio.info, 'length') else 0
        return {
            'duration': duration,
            'length_formatted': f"{duration // 60}:{duration % 60:02d}"
        }
    except:
        return None

def get_songs_list():
    """Get list of all available songs with metadata"""
    songs = []
    for SONGS_DIR in SONGS_DIRS:
        if os.path.exists(SONGS_DIR):
            for filename in os.listdir(SONGS_DIR):
                if any(filename.lower().endswith(ext) for ext in ALLOWED_EXTENSIONS):
                    filepath = os.path.join(SONGS_DIR, filename)
                    song_info = get_song_info(filepath)
                    
                    song_data = {
                        'filename': filename,
                        'name': os.path.splitext(filename)[0].replace('_', ' ').title(),
                        'url': f'{SONGS_DIR}/{filename}',
                        'is_copyright': SONGS_DIR == '/copyright'
                    }
                    
                    if song_info:
                        song_data.update(song_info)
                    
                    songs.append(song_data)
        
    return sorted(songs, key=lambda x: x['name'])

@app.route('/')
def index():
    """Main page with DJ console"""
    return render_template('index.html')

@app.route('/api/songs')
def api_songs():
    """API endpoint to get list of songs"""
    songs = get_songs_list()
    return jsonify(songs)

@app.route('/api/playlist')
def get_playlist():
    """Get current playlist"""
    songs = get_songs_list()
    return jsonify({
        'playlist': songs,
        'current_track': 0
    })

@app.route('/<path:filename>')
def serve_song(filename):
    filename = os.path.normpath("/"+filename)
    if Path(filename).expanduser().absolute().is_relative_to("/copyright"):
        return "Access denied", 403
    return send_file(filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=False)
