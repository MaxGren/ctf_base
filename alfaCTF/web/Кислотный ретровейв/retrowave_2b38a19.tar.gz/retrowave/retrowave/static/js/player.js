class RetrowavePlayer {
    constructor() {
        this.audio = document.getElementById('audio-player');
        this.playlist = [];
        this.queue = [];
        this.currentTrackIndex = 0;
        this.isPlaying = false;
        this.isShuffled = false;
        this.isRepeating = false;
        this.originalPlaylist = [];
        
        // Web Audio API setup for equalizer
        this.audioContext = null;
        this.source = null;
        this.gainNode = null;
        this.eqFilters = {};
        this.isAudioContextInitialized = false;
        
        // Visualizer setup
        this.analyser = null;
        this.visualizerCanvas = null;
        this.visualizerCtx = null;
        this.visualizerEnabled = true;
        this.visualizerType = 'bars';
        this.animationId = null;
        
        this.initializeElements();
        this.bindEvents();
        this.loadPlaylist();
        this.initializeVolumeControls();
        this.initializeEqualizer();
        this.initializeVisualizer();
        
        // Initialize button states
        this.pauseBtn.style.display = 'none';
        this.playBtn.style.display = 'block';
    }

    initializeElements() {
        // Player controls
        this.playBtn = document.getElementById('play-btn');
        this.pauseBtn = document.getElementById('pause-btn');
        this.stopBtn = document.getElementById('stop-btn');
        this.prevBtn = document.getElementById('prev-btn');
        this.nextBtn = document.getElementById('next-btn');
        
        // Progress elements
        this.progressFill = document.getElementById('progress-fill');
        this.currentTimeDisplay = document.getElementById('current-time');
        this.totalTimeDisplay = document.getElementById('total-time');
        
        // Track info
        this.currentTrackName = document.getElementById('current-track-name');
        
        // Playlist elements
        this.playlistContainer = document.getElementById('playlist');
        this.shuffleBtn = document.getElementById('shuffle-btn');
        this.repeatBtn = document.getElementById('repeat-btn');
        
        // Queue elements
        this.queueContainer = document.getElementById('queue');
        this.clearQueueBtn = document.getElementById('clear-queue-btn');
        
        // Volume controls
        this.masterVolume = document.getElementById('master-volume');
        
        // Equalizer controls
        this.eqControls = {
            '32': document.getElementById('eq-32'),
            '64': document.getElementById('eq-64'),
            '125': document.getElementById('eq-125'),
            '250': document.getElementById('eq-250'),
            '500': document.getElementById('eq-500'),
            '1k': document.getElementById('eq-1k'),
            '2k': document.getElementById('eq-2k'),
            '4k': document.getElementById('eq-4k'),
            '8k': document.getElementById('eq-8k'),
            '16k': document.getElementById('eq-16k')
        };
        
        // Visualizer elements
        this.visualizerCanvas = document.getElementById('visualizer');
        this.visualizerCtx = this.visualizerCanvas.getContext('2d');
    }

    bindEvents() {
        // Player control events
        this.playBtn.addEventListener('click', () => this.play());
        this.pauseBtn.addEventListener('click', () => this.pause());
        this.stopBtn.addEventListener('click', () => this.stop());
        this.prevBtn.addEventListener('click', () => this.previous());
        this.nextBtn.addEventListener('click', () => this.next());
        
        // Audio events
        this.audio.addEventListener('loadedmetadata', () => this.updateTimeDisplay());
        this.audio.addEventListener('timeupdate', () => this.updateProgress());
        this.audio.addEventListener('ended', () => this.handleTrackEnd());
        this.audio.addEventListener('error', (e) => this.handleError(e));
        
        // Playlist control events
        this.shuffleBtn.addEventListener('click', () => this.toggleShuffle());
        this.repeatBtn.addEventListener('click', () => this.toggleRepeat());
        
        // Queue control events
        this.clearQueueBtn.addEventListener('click', () => this.clearQueue());
        
        // Progress bar click
        document.querySelector('.progress-bar').addEventListener('click', (e) => this.seekTo(e));
    }

    initializeVisualizer() {
        // Set canvas size
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
    }

    resizeCanvas() {
        const container = this.visualizerCanvas.parentElement;
        const rect = container.getBoundingClientRect();
        this.visualizerCanvas.width = rect.width - 40;
        this.visualizerCanvas.height = 200;
    }

    toggleVisualizer() {
        this.visualizerEnabled = !this.visualizerEnabled;
        this.visualizerToggle.textContent = this.visualizerEnabled ? 'ON' : 'OFF';
        this.visualizerToggle.classList.toggle('active', this.visualizerEnabled);
        
        if (this.visualizerEnabled && this.isPlaying) {
            this.startVisualizer();
        } else {
            this.stopVisualizer();
        }
    }

    startVisualizer() {
        if (!this.visualizerEnabled || !this.analyser) return;
        this.stopVisualizer();
        this.animateVisualizer();
    }

    stopVisualizer() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
        }
        // Clear canvas
        this.visualizerCtx.clearRect(0, 0, this.visualizerCanvas.width, this.visualizerCanvas.height);
    }

    animateVisualizer() {
        if (!this.visualizerEnabled || !this.analyser) return;

        const bufferLength = this.analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        this.analyser.getByteFrequencyData(dataArray);

        this.visualizerCtx.clearRect(0, 0, this.visualizerCanvas.width, this.visualizerCanvas.height);

        switch (this.visualizerType) {
            case 'bars':
                this.drawBars(dataArray);
                break;
            case 'waveform':
                this.drawWaveform(dataArray);
                break;
            case 'circles':
                this.drawCircles(dataArray);
                break;
            case 'grid':
                this.drawGrid(dataArray);
                break;
        }

        this.animationId = requestAnimationFrame(() => this.animateVisualizer());
    }

    drawBars(dataArray) {
        const barWidth = this.visualizerCanvas.width / dataArray.length;
        const barSpacing = 2;
        const maxBarHeight = this.visualizerCanvas.height - 20;

        for (let i = 0; i < dataArray.length; i++) {
            const barHeight = (dataArray[i] / 255) * maxBarHeight;
            const x = i * (barWidth + barSpacing);
            const y = this.visualizerCanvas.height - barHeight - 10;

            // Create gradient
            const gradient = this.visualizerCtx.createLinearGradient(0, y, 0, this.visualizerCanvas.height);
            gradient.addColorStop(0, '#00ffff');
            gradient.addColorStop(0.5, '#ff00ff');
            gradient.addColorStop(1, '#ffff00');

            this.visualizerCtx.fillStyle = gradient;
            this.visualizerCtx.fillRect(x, y, barWidth, barHeight);

            // Add glow effect
            this.visualizerCtx.shadowColor = '#00ffff';
            this.visualizerCtx.shadowBlur = 10;
            this.visualizerCtx.fillRect(x, y, barWidth, barHeight);
            this.visualizerCtx.shadowBlur = 0;
        }
    }

    drawWaveform(dataArray) {
        this.visualizerCtx.strokeStyle = '#00ffff';
        this.visualizerCtx.lineWidth = 2;
        this.visualizerCtx.beginPath();

        const sliceWidth = this.visualizerCanvas.width / dataArray.length;
        let x = 0;

        for (let i = 0; i < dataArray.length; i++) {
            const v = dataArray[i] / 255;
            const y = v * this.visualizerCanvas.height / 2;

            if (i === 0) {
                this.visualizerCtx.moveTo(x, y);
            } else {
                this.visualizerCtx.lineTo(x, y);
            }

            x += sliceWidth;
        }

        this.visualizerCtx.lineTo(this.visualizerCanvas.width, this.visualizerCanvas.height / 2);
        this.visualizerCtx.stroke();

        // Add glow effect
        this.visualizerCtx.shadowColor = '#00ffff';
        this.visualizerCtx.shadowBlur = 15;
        this.visualizerCtx.stroke();
        this.visualizerCtx.shadowBlur = 0;
    }

    drawCircles(dataArray) {
        const centerX = this.visualizerCanvas.width / 2;
        const centerY = this.visualizerCanvas.height / 2;
        const maxRadius = Math.min(centerX, centerY) - 20;

        for (let i = 0; i < dataArray.length; i += 4) {
            const value = dataArray[i] / 255;
            const radius = value * maxRadius;
            const angle = (i / dataArray.length) * Math.PI * 2;

            const x = centerX + Math.cos(angle) * radius;
            const y = centerY + Math.sin(angle) * radius;

            this.visualizerCtx.beginPath();
            this.visualizerCtx.arc(x, y, 3, 0, Math.PI * 2);
            this.visualizerCtx.fillStyle = `hsl(${i * 360 / dataArray.length}, 100%, 50%)`;
            this.visualizerCtx.fill();

            // Add glow effect
            this.visualizerCtx.shadowColor = this.visualizerCtx.fillStyle;
            this.visualizerCtx.shadowBlur = 10;
            this.visualizerCtx.fill();
            this.visualizerCtx.shadowBlur = 0;
        }
    }

    drawGrid(dataArray) {
        const gridSize = 20;
        const cols = Math.floor(this.visualizerCanvas.width / gridSize);
        const rows = Math.floor(this.visualizerCanvas.height / gridSize);

        for (let i = 0; i < dataArray.length && i < cols * rows; i++) {
            const col = i % cols;
            const row = Math.floor(i / cols);
            const value = dataArray[i] / 255;

            const x = col * gridSize;
            const y = row * gridSize;
            const size = value * gridSize * 0.8;

            this.visualizerCtx.fillStyle = `rgba(0, 255, 255, ${value})`;
            this.visualizerCtx.fillRect(x + (gridSize - size) / 2, y + (gridSize - size) / 2, size, size);

            // Add glow effect
            this.visualizerCtx.shadowColor = '#00ffff';
            this.visualizerCtx.shadowBlur = 5;
            this.visualizerCtx.fillRect(x + (gridSize - size) / 2, y + (gridSize - size) / 2, size, size);
            this.visualizerCtx.shadowBlur = 0;
        }
    }

    async loadPlaylist() {
        try {
            const response = await fetch('/api/songs');
            const songs = await response.json();
            
            this.playlist = songs;
            this.originalPlaylist = [...songs];
            this.renderPlaylist();
            this.renderQueue();
            
            if (songs.length > 0) {
                this.loadTrack(0);
            }
        } catch (error) {
            console.error('Error loading playlist:', error);
            this.showError('Failed to load playlist');
        }
    }

    renderPlaylist() {
        this.playlistContainer.innerHTML = '';
        
        this.playlist.forEach((song, index) => {
            const playlistItem = document.createElement('div');
            playlistItem.className = 'playlist-item';
            playlistItem.dataset.index = index;
            
            // Add copyright styling if song is copyright-protected
            if (song.is_copyright) {
                playlistItem.classList.add('copyright-song');
            }
            
            playlistItem.innerHTML = `
                <div class="song-info">
                    <div class="song-name">
                        ${song.name}
                        ${song.is_copyright ? '<span class="copyright-badge">🚫</span>' : ''}
                    </div>
                    <div class="song-duration">${song.length_formatted || '0:00'}</div>
                </div>
                <div class="song-controls">
                    <button class="song-btn play-song" title="${song.is_copyright ? 'Copyright Protected' : 'Play'}">▶</button>
                    <button class="song-btn queue-song" title="${song.is_copyright ? 'Copyright Protected' : 'Add to Queue'}">+</button>
                </div>
            `;
            
            // Add click events
            const playBtn = playlistItem.querySelector('.play-song');
            const queueBtn = playlistItem.querySelector('.queue-song');
            
            playBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.loadTrack(index);
                this.play();
            });
            
            queueBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.addToQueue(song);
            });
            
            playlistItem.addEventListener('click', () => {
                this.loadTrack(index);
                this.play();
            });
            
            this.playlistContainer.appendChild(playlistItem);
        });
    }

    renderQueue() {
        this.queueContainer.innerHTML = '';
        
        if (this.queue.length === 0) {
            this.queueContainer.innerHTML = `
                <div style="text-align: center; padding: 40px; color: #ff00ff; opacity: 0.7;">
                    <div style="font-size: 1rem;">Queue is empty</div>
                    <div style="font-size: 0.8rem;">Add songs from the playlist</div>
                </div>
            `;
            return;
        }
        
        this.queue.forEach((song, index) => {
            const queueItem = document.createElement('div');
            queueItem.className = 'queue-item';
            queueItem.dataset.index = index;
            
            queueItem.innerHTML = `
                <div class="song-info">
                    <div class="song-name">${song.name}</div>
                    <div class="song-duration">${song.length_formatted || '0:00'}</div>
                </div>
                <div class="song-controls">
                    <button class="song-btn play-queue" title="Play Now">▶</button>
                    <button class="song-btn remove-queue" title="Remove">×</button>
                </div>
            `;
            
            // Add click events
            const playBtn = queueItem.querySelector('.play-queue');
            const removeBtn = queueItem.querySelector('.remove-queue');
            
            playBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.playFromQueue(index);
            });
            
            removeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.removeFromQueue(index);
            });
            
            this.queueContainer.appendChild(queueItem);
        });
    }

    loadTrack(index) {
        if (index < 0 || index >= this.playlist.length) return;
        
        this.currentTrackIndex = index;
        const track = this.playlist[index];
        
        this.currentTrackName.textContent = track.name;
        
        // Update active playlist item
        document.querySelectorAll('.playlist-item').forEach(item => {
            item.classList.remove('active');
        });
        
        const activeItem = document.querySelector(`[data-index="${index}"]`);
        if (activeItem) {
            activeItem.classList.add('active');
        }
        
        // Set the audio source
        this.audio.src = track.url;
        
        // Connect audio to Web Audio API when track loads (only once)
        if (!this.source) {
            this.audio.addEventListener('canplay', () => {
                this.connectAudioToEqualizer();
            }, { once: true });
        }
    }

    play() {
        if (this.playlist.length === 0) return;
        
        // Ensure audio context is resumed
        if (this.audioContext && this.audioContext.state === 'suspended') {
            this.audioContext.resume();
        }
        
        this.audio.play().then(() => {
            this.isPlaying = true;
            this.playBtn.style.display = 'none';
            this.pauseBtn.style.display = 'block';
            
            // Start visualizer if enabled
            if (this.visualizerEnabled) {
                this.startVisualizer();
            }
        }).catch(error => {
            console.error('Error playing audio:', error);
            this.showError('Failed to play track');
        });
    }

    pause() {
        this.audio.pause();
        this.isPlaying = false;
        this.playBtn.style.display = 'block';
        this.pauseBtn.style.display = 'none';
        
        // Stop visualizer
        this.stopVisualizer();
    }

    stop() {
        this.audio.pause();
        this.audio.currentTime = 0;
        this.isPlaying = false;
        this.playBtn.style.display = 'block';
        this.pauseBtn.style.display = 'none';
        
        // Stop visualizer
        this.stopVisualizer();
    }

    previous() {
        if (this.currentTrackIndex > 0) {
            this.loadTrack(this.currentTrackIndex - 1);
            if (this.isPlaying) this.play();
        }
    }

    next() {
        if (this.currentTrackIndex < this.playlist.length - 1) {
            this.loadTrack(this.currentTrackIndex + 1);
            if (this.isPlaying) this.play();
        }
    }

    handleTrackEnd() {
        if (this.isRepeating) {
            this.audio.currentTime = 0;
            this.play();
        } else if (this.queue.length > 0) {
            this.playNextFromQueue();
        } else if (this.currentTrackIndex < this.playlist.length - 1) {
            this.next();
        } else {
            this.stop();
        }
    }

    updateProgress() {
        if (this.audio.duration) {
            const progress = (this.audio.currentTime / this.audio.duration) * 100;
            this.progressFill.style.width = `${progress}%`;
            this.updateTimeDisplay();
        }
    }

    updateTimeDisplay() {
        const currentTime = this.formatTime(this.audio.currentTime);
        const totalTime = this.formatTime(this.audio.duration || 0);
        
        this.currentTimeDisplay.textContent = currentTime;
        this.totalTimeDisplay.textContent = totalTime;
    }

    formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }

    seekTo(event) {
        const progressBar = event.currentTarget;
        const rect = progressBar.getBoundingClientRect();
        const clickX = event.clientX - rect.left;
        const percentage = clickX / rect.width;
        
        if (this.audio.duration) {
            this.audio.currentTime = percentage * this.audio.duration;
        }
    }

    toggleShuffle() {
        this.isShuffled = !this.isShuffled;
        this.shuffleBtn.classList.toggle('active', this.isShuffled);
        
        if (this.isShuffled) {
            this.shufflePlaylist();
        } else {
            this.restoreOriginalPlaylist();
        }
    }

    toggleRepeat() {
        this.isRepeating = !this.isRepeating;
        this.repeatBtn.classList.toggle('active', this.isRepeating);
    }

    shufflePlaylist() {
        const currentTrack = this.playlist[this.currentTrackIndex];
        this.playlist = this.shuffleArray([...this.originalPlaylist]);
        
        // Keep current track at the beginning
        const currentIndex = this.playlist.findIndex(track => track.filename === currentTrack.filename);
        if (currentIndex > 0) {
            const [removed] = this.playlist.splice(currentIndex, 1);
            this.playlist.unshift(removed);
            this.currentTrackIndex = 0;
        }
        
        this.renderPlaylist();
    }

    restoreOriginalPlaylist() {
        const currentTrack = this.playlist[this.currentTrackIndex];
        this.playlist = [...this.originalPlaylist];
        
        // Find current track in original playlist
        const originalIndex = this.playlist.findIndex(track => track.filename === currentTrack.filename);
        if (originalIndex >= 0) {
            this.currentTrackIndex = originalIndex;
        }
        
        this.renderPlaylist();
    }

    shuffleArray(array) {
        const shuffled = [...array];
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
    }

    addToQueue(song) {
        this.queue.push(song);
        this.renderQueue();
        this.showNotification(`Added "${song.name}" to queue`);
    }

    removeFromQueue(index) {
        const removedSong = this.queue.splice(index, 1)[0];
        this.renderQueue();
        this.showNotification(`Removed "${removedSong.name}" from queue`);
    }

    clearQueue() {
        this.queue = [];
        this.renderQueue();
        this.showNotification('Queue cleared');
    }

    playFromQueue(index) {
        if (index >= 0 && index < this.queue.length) {
            const song = this.queue[index];
            this.queue.splice(index, 1);
            this.renderQueue();
            
            // Find song in playlist and play it
            const playlistIndex = this.playlist.findIndex(track => track.filename === song.filename);
            if (playlistIndex >= 0) {
                this.loadTrack(playlistIndex);
                this.play();
            }
        }
    }

    playNextFromQueue() {
        if (this.queue.length > 0) {
            this.playFromQueue(0);
        }
    }

    initializeVolumeControls() {
        // Master volume
        this.masterVolume.addEventListener('input', (e) => {
            const volume = e.target.value / 100;
            this.audio.volume = volume;
            e.target.nextElementSibling.textContent = e.target.value;
        });
    }

    initializeEqualizer() {
        // Initialize Web Audio API
        this.setupAudioContext();
        
        // Add event listeners for each EQ band
        Object.entries(this.eqControls).forEach(([frequency, control]) => {
            control.addEventListener('input', (e) => {
                const value = parseFloat(e.target.value);
                e.target.nextElementSibling.textContent = value;
                this.updateEQFilter(frequency, value);
            });
        });
    }

    setupAudioContext() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            this.gainNode = this.audioContext.createGain();
            
            // Create analyzer for visualizer
            this.analyser = this.audioContext.createAnalyser();
            this.analyser.fftSize = 256;
            this.analyser.smoothingTimeConstant = 0.8;
            
            // Create EQ filters
            const frequencies = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
            frequencies.forEach(freq => {
                const filter = this.audioContext.createBiquadFilter();
                filter.type = 'peaking';
                filter.frequency.value = freq;
                filter.Q.value = 1;
                filter.gain.value = 0;
                
                this.eqFilters[freq] = filter;
            });
            
            // Connect filters in series
            let previousNode = this.gainNode;
            frequencies.forEach(freq => {
                const filter = this.eqFilters[freq];
                previousNode.connect(filter);
                previousNode = filter;
            });
            
            // Connect the last filter to analyzer and then to destination
            previousNode.connect(this.analyser);
            this.analyser.connect(this.audioContext.destination);
            
            this.isAudioContextInitialized = true;
        } catch (error) {
            console.warn('Web Audio API not supported, equalizer will be disabled');
        }
    }

    updateEQFilter(frequency, value) {
        if (!this.isAudioContextInitialized) return;
        
        const freq = parseInt(frequency.replace('k', '000'));
        const filter = this.eqFilters[freq];
        
        if (filter) {
            filter.gain.value = value;
        }
    }

    handleError(error) {
        console.error('Audio error:', error);
        
        // Check if it's a 403 error by examining the error details
        if (error.target && error.target.error) {
            const audioError = error.target.error;
            
            // Check for network error (code 4) which could be 403
            if (audioError.code === 4) {
                // Make a quick check to see if it's actually a 403
                const currentTrack = this.playlist[this.currentTrackIndex];
                if (currentTrack && currentTrack.url) {
                    fetch(currentTrack.url, { method: 'HEAD' })
                        .then(response => {
                            if (response.status === 403) {
                                this.showCopyrightError();
                            } else {
                                this.showError('Error playing audio file');
                            }
                        })
                        .catch(() => {
                            this.showError('Error playing audio file');
                        });
                } else {
                    this.showError('Error playing audio file');
                }
            } else {
                this.showError('Error playing audio file');
            }
        } else {
            this.showError('Error playing audio file');
        }
    }
    
    showCopyrightError() {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(255, 165, 0, 0.9);
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            border: 2px solid #ffa500;
            box-shadow: 0 0 20px rgba(255, 165, 0, 0.5);
            z-index: 1000;
            font-family: 'Orbitron', monospace;
            font-weight: bold;
        `;
        notification.textContent = '🚫 BLOCKED: Copyright Issues';
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 4000);
    }

    showError(message) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(255, 0, 0, 0.9);
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            border: 2px solid #ff0000;
            box-shadow: 0 0 20px rgba(255, 0, 0, 0.5);
            z-index: 1000;
            font-family: 'Orbitron', monospace;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    showNotification(message) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(0, 255, 255, 0.9);
            color: black;
            padding: 15px 20px;
            border-radius: 8px;
            border: 2px solid #00ffff;
            box-shadow: 0 0 20px rgba(0, 255, 255, 0.5);
            z-index: 1000;
            font-family: 'Orbitron', monospace;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 2000);
    }

    connectAudioToEqualizer() {
        if (!this.isAudioContextInitialized) return;
        
        try {
            // Resume audio context if suspended
            if (this.audioContext.state === 'suspended') {
                this.audioContext.resume();
            }
            
            // Only create MediaElementSource once
            if (!this.source) {
                this.source = this.audioContext.createMediaElementSource(this.audio);
                // Connect source to gain node (which is connected to EQ filters)
                this.source.connect(this.gainNode);
                console.log('Audio connected to equalizer and visualizer');
            }
        } catch (error) {
            console.error('Error connecting audio to equalizer:', error);
        }
    }
}

// Initialize player when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.retrowavePlayer = new RetrowavePlayer();
});

// Add some sample songs if no songs are available
document.addEventListener('DOMContentLoaded', () => {
    // Check if we have any songs after a delay
    setTimeout(() => {
        const playlist = document.querySelectorAll('.playlist-item');
        if (playlist.length === 0) {
            const container = document.getElementById('playlist');
            container.innerHTML = `
                <div style="text-align: center; padding: 40px; color: #ff00ff;">
                    <div style="font-size: 1.2rem; margin-bottom: 10px;">No songs found</div>
                    <div style="font-size: 0.9rem; opacity: 0.8;">
                        Add MP3, WAV, or OGG files to the songs/ folder
                    </div>
                </div>
            `;
        }
    }, 2000);
});
