from typing import Annotated
from .models import Chat, User, user_chat
from fastapi import Request, Depends
from fastapi import HTTPException, status
from sqlalchemy import exists, select
from .db import DB


async def authenticate_user(
    request: Request, db: DB, username: str, password: str
) -> User | None:
    result = await db.scalars(
        select(User).where(
            User.username == username,
        )
    )
    user = result.one_or_none()
    if not user:
        return None
    if user.check_password(password):
        return user
    return None


async def get_current_user(request: Request, db: DB) -> User:

    user_id = request.session.get("user_id")
    result = await db.scalars(
        select(User).where(
            User.id == user_id,
        )
    )
    user = result.one_or_none()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_307_TEMPORARY_REDIRECT,
            detail="Not authenticated",
            headers={"Location": "/login"},
        )


    return user


CurrentUser = Annotated[User, Depends(get_current_user)]


async def get_current_chat(db: DB, user: CurrentUser, chat_id: int) -> Chat:
    chat_exists = await db.scalar(
        exists()
        .where(user_chat.c.user_id == user.id, user_chat.c.chat_id == chat_id)
        .select()
    )

    if not chat_exists:
        raise HTTPException(status_code=404, detail="Чат не найден")

    result = await db.scalars(select(Chat).where(Chat.id == chat_id))
    return result.unique().one()


CurrentChat = Annotated[Chat, Depends(get_current_chat)]
