from pydantic import BaseModel, ConfigDict
from typing import Any, Optional


class UserCreate(BaseModel):
    username: str
    password: str


class UserView(BaseModel):
    id: int
    username: str

    model_config = ConfigDict(from_attributes=True)


class UserResponse(BaseModel):
    users: list[UserView]


class MessageView(BaseModel):
    id: int
    sender: UserView
    text: str
    timestamp: str

    model_config = ConfigDict(from_attributes=True)


class MessageResponse(BaseModel):
    messages: list[MessageView]


class MCPCreate(BaseModel):
    url: str
    access_token: Optional[str] = None


class MCPView(BaseModel):
    id: int
    url: str
    cached_data: Optional[Any] = None

    model_config = ConfigDict(from_attributes=True)


class MCPResponse(BaseModel):
    mcps: list[MCPView]


class ChatSummary(BaseModel):
    id: int
    name: str
    last_message_time: str | None
    pinned: bool


class ChatSummaryResponse(BaseModel):
    chats: list[ChatSummary]
