import multiprocessing

from dotenv import load_dotenv
from gunicorn.app.base import BaseApplication


class CompositeApplication(BaseApplication):
    def __init__(self, app):
        self.application = app
        super().__init__()

    def load_config(self):
        config = {
            "bind": "0.0.0.0:8000",
            "workers": min(multiprocessing.cpu_count() * 2, 8),
            "timeout": 180,
            "worker_class": "uvicorn.workers.UvicornWorker",
            "forwarded_allow_ips": "*",
        }

        for key, value in config.items():
            if key in self.cfg.settings:
                self.cfg.set(key.lower(), value)

    def load(self):
        return self.application


load_dotenv()


def prod():
    from minmsg.app import app

    CompositeApplication(app).run()


def debug():
    import uvicorn

    uvicorn.run("minmsg.app:app", reload=True, port=8000)


__all__ = ["prod", "debug"]
