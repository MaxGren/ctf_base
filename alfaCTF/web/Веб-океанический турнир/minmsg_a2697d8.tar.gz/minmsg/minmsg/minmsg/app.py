import logging
import os
from pathlib import Path
import httpx

from fastapi import (
    FastAPI,
    Request,
    Response,
    Form,
    status,
    BackgroundTasks,
    HTTPException,
)
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy import exists, select

from .ai import reply_ai
from .auth import CurrentChat, CurrentUser, authenticate_user
from .bot import registry
from .db import DB, init_db
from .models import User, Message, MCP
from .schemas import (
    ChatSummaryResponse,
    MessageResponse,
    UserResponse,
    UserView,
    MCPCreate,
    MCPView,
    MCPResponse,
)
from .utils import (
    chat_to_summary,
    create_or_find_chat_between,
    get_chat_summary,
    message_to_view,
)

logger = logging.getLogger("uvicorn.error")


async def verify_recaptcha(token: str, remote_ip: str) -> bool:
    """Verify reCAPTCHA token with Google's API"""
    if not token:
        return False

    secret_key = os.environ.get("RECAPTCHA_SECRET_KEY")
    if not secret_key:
        logger.warning("RECAPTCHA_SECRET_KEY not set, skipping verification")
        return True  # Skip verification in development

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://www.google.com/recaptcha/api/siteverify",
                data={
                    "secret": secret_key,
                    "response": token,
                    "remoteip": remote_ip,
                },
            )
            result = response.json()
            return result.get("success", False)
    except Exception as e:
        logger.error(f"reCAPTCHA verification failed: {e}")
        return False


app = FastAPI(docs_url=None, redoc_url=None)
app.add_middleware(
    SessionMiddleware,
    secret_key=os.environ["SECRET_KEY"],
)




app_root = Path(__file__).parent
templates = Jinja2Templates(directory=app_root / "templates")
app.mount("/static", StaticFiles(directory=app_root / "static"), name="static")


@app.on_event("startup")
async def on_startup():
    await init_db()


@app.get("/login")
async def login_page(request: Request):
    return templates.TemplateResponse(request, "login.html", {})


@app.post("/login")
async def login(
    request: Request, db: DB, username: str = Form(...), password: str = Form(...)
):
    user = await authenticate_user(request, db, username, password)
    if not user:
        return templates.TemplateResponse(
            request, "login.html", {"error": "Неверные данные"}
        )
    request.session["user_id"] = user.id
    return RedirectResponse("/", status_code=status.HTTP_302_FOUND)


@app.get("/register")
async def register_page(request: Request):
    return templates.TemplateResponse(request, "register.html", {})


@app.post("/register")
async def register(
    request: Request,
    db: DB,
    username: str = Form(...),
    password: str = Form(...),
    password2: str = Form(...),
):
    await registry.create_bot_users(db)

    if (
        len(username) < 9
        or len(username) > 40
        or any(
            c not in "abcdefghijklmnopqrstuvwxyz0123456789_.-" for c in username.lower()
        )
    ):
        return templates.TemplateResponse(
            request,
            "register.html",
            {
                "error": "Логин должен быть от 9 до 40 символов, "
                "содержать только строчные буквы, цифры, точку и знак подчеркивания"
            },
        )

    if len(password) < 9:
        return templates.TemplateResponse(
            request,
            "register.html",
            {"error": "Пароль должен быть не менее 9 символов"},
        )

    if password != password2:
        return templates.TemplateResponse(
            request, "register.html", {"error": "Пароли не совпадают"}
        )

    existing = await db.scalar(
        exists()
        .where(
            User.username == username,
        )
        .select()
    )
    if existing:
        return templates.TemplateResponse(
            request, "register.html", {"error": "Логин уже занят"}
        )

    user = User(
        username=username,
    )
    user.set_password(password)
    db.add(user)
    await db.commit()
    await db.refresh(user)

    await create_or_find_chat_between(db, user, None)  # Create AI chat

    request.session["user_id"] = user.id
    return RedirectResponse("/", status_code=status.HTTP_302_FOUND)


@app.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=status.HTTP_302_FOUND)


@app.get("/")
async def index(request: Request, db: DB, user: CurrentUser):
    return templates.TemplateResponse(
        request,
        "index.html",
        {
            "user": user,
            "chats": await get_chat_summary(db, user),
        },
    )


@app.get("/search")
async def search_users(db: DB, user: CurrentUser, q: str = ""):
    q = q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    result = await db.scalars(
        select(User)
        .where(
            User.username.ilike(f"%{q}%"),
            User.id != user.id,
        )
        .limit(10)
    )
    users = result.unique().all()
    return UserResponse(users=list(map(UserView.model_validate, users)))


@app.get("/chat/{chat_id}")
async def chat_view(
    request: Request,
    db: DB,
    chat: CurrentChat,
    user: CurrentUser,
):
    messages_result = await db.scalars(
        select(Message)
        .where(Message.chat_id == chat.id)
        .order_by(Message.timestamp.desc())
        .limit(50)
    )
    messages = messages_result.unique().all()[::-1]

    # Get the last message ID for polling
    last_message_id = messages[-1].id if len(messages) > 0 else None

    smartnote_url = os.environ["SMARTNOTE_URL"]

    return templates.TemplateResponse(
        request,
        "chat.html",
        {
            "user": user,
            "current_chat": chat_to_summary(user, chat),
            "chats": await get_chat_summary(db, user),
            "messages": messages,
            "last_message_id": last_message_id,
            "recaptcha_site_key": os.environ.get("RECAPTCHA_SITE_KEY", ""),
            "smartnote_url": smartnote_url,
        },
    )


@app.get("/chat/{chat_id}/history")
async def chat_history(db: DB, chat: CurrentChat, before: int) -> MessageResponse:
    messages_result = await db.scalars(
        select(Message)
        .where(Message.chat_id == chat.id, Message.id < before)
        .order_by(Message.timestamp.desc())
        .limit(50)
    )
    messages = messages_result.unique().all()[::-1]

    return MessageResponse(messages=[message_to_view(message) for message in messages])


@app.get("/chat/{chat_id}/new")
async def new_messages(db: DB, chat: CurrentChat, after: int) -> MessageResponse:
    """Get messages after a specific message ID"""
    messages_result = await db.scalars(
        select(Message)
        .where(Message.chat_id == chat.id, Message.id > after)
        .order_by(Message.timestamp.asc())
        .limit(50)
    )
    messages = messages_result.unique().all()

    return MessageResponse(messages=[message_to_view(message) for message in messages])


@app.get("/chat/{chat_id}/id")
async def last_message_id(
    db: DB,
    chat: CurrentChat,
):
    message_id = await db.scalar(
        select(Message.id)
        .where(Message.chat_id == chat.id)
        .order_by(Message.timestamp.desc())
        .limit(1)
    )

    return {"id": message_id}


@app.get("/chats/summary")
async def chats_summary(db: DB, user: CurrentUser) -> ChatSummaryResponse:
    """Get a summary of all chats for polling - returns timestamps and message counts"""
    return await get_chat_summary(db, user)


@app.post("/chat/{chat_id}/send")
async def send_message(
    request: Request,
    db: DB,
    chat: CurrentChat,
    user: CurrentUser,
    bg: BackgroundTasks,
    text: str = Form(...),
    recaptcha_response: str = Form(alias="g-recaptcha-response", default=""),
):
    # Verify reCAPTCHA
    client_ip = (
        request.headers.get("x-real-ip")
        or (request.client and request.client.host)
        or "127.0.0.1"
    )
    if not await verify_recaptcha(recaptcha_response, client_ip):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="reCAPTCHA verification failed",
        )

    msg = Message(
        chat_id=chat.id,
        sender_id=user.id,
        text=text,
    )
    db.add(msg)
    await db.commit()
    await db.refresh(msg)

    if chat.chatmate_for(user) is not None:
        bg.add_task(registry.message_hook, msg.id)

    chat.last_message_time = msg.timestamp
    db.add(chat)

    # If this is AI chat, send to ChatGPT and get response
    if chat.chatmate_for(user) is None:
        bg.add_task(reply_ai, msg.id)

    return RedirectResponse(f"/chat/{chat.id}", status_code=status.HTTP_302_FOUND)


@app.post("/start_chat/{target_id}")
async def start_chat(db: DB, user: CurrentUser, target_id: int):
    result = await db.scalars(select(User).where(User.id == target_id))
    chatmate = result.unique().one_or_none()
    if chatmate is None:
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"detail": "Пользователь не найден"},
        )

    chat = await create_or_find_chat_between(db, user, chatmate)
    return {"chat_id": chat.id}


@app.get("/users/{user_id}/mcp")
async def get_user_mcps(db: DB, user: CurrentUser, user_id: int):
    """Get all MCP servers for a user"""
    result = await db.scalars(select(MCP).where(MCP.user_id == user_id))
    mcps = result.unique().all()
    return MCPResponse(mcps=list(map(MCPView.model_validate, mcps)))


@app.post("/users/{user_id}/mcp")
async def add_mcp_server(db: DB, user: CurrentUser, user_id: int, mcp_data: MCPCreate):
    """Add a new MCP server for a user"""
    # Try to fetch tools from the MCP server
    cached_data = {"tools": []}
    headers = (
        {"Authorization": f"Bearer {mcp_data.access_token}"}
        if mcp_data.access_token
        else None
    )
    try:
        async with streamablehttp_client(mcp_data.url, headers=headers) as (
            read_stream,
            write_stream,
            _,
        ):
            async with ClientSession(read_stream, write_stream) as session:
                # Initialize the connection
                await session.initialize()
                # List available tools
                tools = await session.list_tools()
                cached_data = {"tools": [tool.name for tool in tools.tools]}
    except Exception:
        logger.exception("User %d can't add server %s", user.id, mcp_data.url)
        # If there's any error, we'll still add the server but with no cached data
        cached_data = {"error": "Не удалось добавить сервер", "tools": []}

    mcp = MCP(
        user_id=user_id,
        url=mcp_data.url,
        access_token=mcp_data.access_token,
        cached_data=cached_data,
    )

    db.add(mcp)
    await db.commit()
    await db.refresh(mcp)

    return MCPView.model_validate(mcp)


@app.post("/users/{user_id}/mcp/{mcp_id}/delete")
async def delete_mcp_server(db: DB, user: CurrentUser, user_id: int, mcp_id: int):
    """Delete an MCP server"""
    result = await db.scalars(
        select(MCP).where(MCP.id == mcp_id, MCP.user_id == user_id)
    )
    mcp = result.unique().one_or_none()

    if not mcp:
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"detail": "Инструмент не найден"},
        )


    await db.delete(mcp)
    await db.commit()

    return {"status": "deleted"}
