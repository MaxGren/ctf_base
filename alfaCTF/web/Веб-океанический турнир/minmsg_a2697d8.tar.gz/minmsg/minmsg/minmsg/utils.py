from datetime import datetime

from fastapi import HTTPException, status
from sqlalchemy import and_, delete, select
from sqlalchemy.orm import Session

from .db import DB
from .models import Chat, Message, User, user_chat
from .schemas import ChatSummary, ChatSummaryResponse, MessageView, UserView


def format_utc_timestamp(dt: datetime):
    """Convert a naive UTC datetime to ISO format with Z suffix"""
    match dt:
        case None:
            return None
        case _ if dt.tzinfo is not None:
            return dt.isoformat()
        case _:
            return f"{dt.isoformat()}Z"


async def find_chat_between(db: DB, user: User, peer: User | None) -> Chat | None:
    uc2 = user_chat.alias("uc2")

    right_stmt = (uc2.c.user_id == peer.id) if peer else uc2.c.user_id.is_(None)

    result = await db.scalars(
        select(Chat)
        .join(user_chat, user_chat.c.chat_id == Chat.id)
        .join(
            uc2,
            and_(
                user_chat.c.chat_id == uc2.c.chat_id,
                user_chat.c.user_id != uc2.c.user_id,
            ),
            isouter=True,
        )
        .where(user_chat.c.user_id == user.id, right_stmt)
        .order_by(Chat.id.asc())
    )
    chats = result.unique().all()
    if len(chats) > 1:
        await db.execute(delete(Chat).where(Chat.id.in_([c.id for c in chats[1:]])))
        await db.commit()
    return chats[0] if chats else None


async def create_or_find_chat_between(db: DB, user: User, peer: User | None) -> Chat:
    """Creates chat with lock."""

    if (chat := await find_chat_between(db, user, peer)) is not None:
        return chat


    new_chat = Chat(pinned=peer is None, users=[user])
    if peer:
        new_chat.users.append(peer)
    db.add(new_chat)
    await db.commit()

    return await find_chat_between(db, user, peer)


def find_chat_between_sync(db: Session, user: User, peer: User | None) -> Chat | None:
    uc2 = user_chat.alias("uc2")

    right_stmt = (uc2.c.user_id == peer.id) if peer else uc2.c.user_id.is_(None)

    result = db.scalars(
        select(Chat)
        .join(user_chat, user_chat.c.chat_id == Chat.id)
        .join(
            uc2,
            and_(
                user_chat.c.chat_id == uc2.c.chat_id,
                user_chat.c.user_id != uc2.c.user_id,
            ),
            isouter=True,
        )
        .where(user_chat.c.user_id == user.id, right_stmt)
        .order_by(Chat.id.asc())
    )
    chats = result.unique().all()
    if len(chats) > 1:
        db.execute(delete(Chat).where(Chat.id.in_([c.id for c in chats[1:]])))
        db.commit()
    return chats[0] if chats else None


def create_or_find_chat_between_sync(
    db: Session, user: User, peer: User | None
) -> Chat:
    """Creates chat with lock."""

    if (chat := find_chat_between_sync(db, user, peer)) is not None:
        return chat


    new_chat = Chat(pinned=peer is None, users=[user])
    if peer:
        new_chat.users.append(peer)
    db.add(new_chat)
    db.commit()

    return find_chat_between_sync(db, user, peer)


def chat_to_summary(user: User, chat: Chat) -> ChatSummary:
    chatmate = chat.chatmate_for(user)
    return ChatSummary(
        id=chat.id,
        name="🤖 Робот Евлампий" if chatmate is None else f"👤 {chatmate.username}",
        last_message_time=format_utc_timestamp(chat.last_message_time),
        pinned=chat.pinned,
    )


async def get_chat_summary(db: DB, user: User) -> ChatSummaryResponse:
    result = await db.scalars(
        select(Chat)
        .join(user_chat, Chat.id == user_chat.c.chat_id)
        .where(user_chat.c.user_id == user.id)
        .order_by(Chat.pinned.desc(), Chat.last_message_time.desc().nulls_first())
    )
    chats = result.unique().all()
    return ChatSummaryResponse(chats=[chat_to_summary(user, chat) for chat in chats])


def message_to_view(message: Message) -> MessageView:
    return MessageView(
        id=message.id,
        sender=UserView.model_validate(message.sender) if message.sender else None,
        text=message.text,
        timestamp=format_utc_timestamp(message.timestamp),
    )
