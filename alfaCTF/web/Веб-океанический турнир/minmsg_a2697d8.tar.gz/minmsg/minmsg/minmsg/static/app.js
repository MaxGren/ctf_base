// Common JavaScript utilities for the messenger application

class MessengerAPI {
    static async searchUsers(query) {
        const response = await fetch(`/search?q=${encodeURIComponent(query)}`);
        return response.json();
    }

    static async startChat(userId) {
        const response = await fetch(`/start_chat/${userId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        return response.json();
    }

    static async sendMessage(chatId, text) {
        const form = new FormData();
        form.append('text', text);

        const response = await fetch(`/chat/${chatId}/send`, {
            method: 'POST',
            body: form
        });

        return response;
    }
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Auto-refresh functionality for chat
class ChatRefresher {
    constructor(interval = 10000) {
        this.interval = interval;
        this.isActive = false;
        this.intervalId = null;
    }

    start(refreshCallback) {
        if (this.isActive) return;

        this.isActive = true;
        this.intervalId = setInterval(refreshCallback, this.interval);
    }

    stop() {
        if (!this.isActive) return;

        this.isActive = false;
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
    }
}

// Search functionality
class UserSearch {
    constructor(inputElement, resultsElement) {
        this.input = inputElement;
        this.results = resultsElement;
        this.searchTimeout = null;

        this.init();
    }

    init() {
        this.input.addEventListener('input', debounce((e) => {
            this.handleSearch(e.target.value.trim());
        }, 300));

        // Hide results when clicking outside
        document.addEventListener('click', (e) => {
            if (!this.input.contains(e.target) && !this.results.contains(e.target)) {
                this.hideResults();
            }
        });
    }

    async handleSearch(query) {
        if (!query) {
            this.hideResults();
            return;
        }

        try {
            const data = await MessengerAPI.searchUsers(query);
            this.showResults(data.users);
        } catch (error) {
            console.error('Search error:', error);
            this.hideResults();
        }
    }

    showResults(users) {
        this.results.innerHTML = '';

        if (users.length === 0) {
            this.hideResults();
            return;
        }

        users.forEach(user => {
            const div = document.createElement('div');
            div.className = 'search-result';
            div.textContent = user.username;
            div.addEventListener('click', () => this.selectUser(user.id));
            this.results.appendChild(div);
        });

        this.results.style.display = 'block';
    }

    hideResults() {
        this.results.style.display = 'none';
    }

    async selectUser(userId) {
        try {
            const data = await MessengerAPI.startChat(userId);
            if (data.chat_id) {
                window.location.href = `/chat/${data.chat_id}`;
            }
        } catch (error) {
            console.error('Error starting chat:', error);
        }

        this.hideResults();
        this.input.value = '';
    }
}

// Export for module usage if needed
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        MessengerAPI,
        UserSearch,
        ChatRefresher,
        debounce,
        escapeHtml
    };
}
