// Messenger layout functionality
document.addEventListener('DOMContentLoaded', function() {
    // Format chat timestamps
    function formatChatTime(timestampString) {
        if (!timestampString) return '';

        const timestamp = new Date(timestampString);
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const messageDate = new Date(timestamp.getFullYear(), timestamp.getMonth(), timestamp.getDate());

        const diffDays = Math.floor((today - messageDate) / (1000 * 60 * 60 * 24));

        if (diffDays === 0) {
            // Today - show time in local timezone
            return timestamp.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit',
                hour12: false
            });
        } else if (diffDays === 1) {
            // Yesterday
            return 'Вчера';
        } else if (diffDays < 7) {
            // This week - show day name
            return timestamp.toLocaleDateString('en-US', { weekday: 'short' });
        } else {
            // Older - show date
            return timestamp.toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric'
            });
        }
    }

    // Update all chat times on page load
    document.querySelectorAll('.chat-time[data-timestamp]').forEach(timeElement => {
        const timestamp = timeElement.dataset.timestamp;
        if (timestamp) {
            timeElement.textContent = formatChatTime(timestamp);
        }
    });

    const search = document.getElementById('search');
    const results = document.getElementById('searchResults');

    let searchTimeout;
    search.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        const query = this.value.trim();

        if (!query) {
            results.style.display = 'none';
            return;
        }

        searchTimeout = setTimeout(() => {
            fetch(`/search?q=${encodeURIComponent(query)}`)
                .then(r => r.json())
                .then(data => {
                    results.innerHTML = '';
                    if (data.users.length > 0) {
                        data.users.forEach(user => {
                            const div = document.createElement('div');
                            div.className = 'search-result';
                            div.textContent = user.username;
                            div.onclick = () => startChat(user.id);
                            results.appendChild(div);
                        });
                        results.style.display = 'block';
                    } else {
                        results.style.display = 'none';
                    }
                })
                .catch(err => {
                    console.error('Не удалось найти пользователей:', err);
                });
        }, 300);
    });

    function startChat(userId) {
        fetch(`/start_chat/${userId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(r => r.json())
        .then(data => {
            if (data.chat_id) {
                window.location.href = `/chat/${data.chat_id}`;
            }
        })
        .catch(err => {
            console.error('Не удалось открыть чат:', err);
        });

        results.style.display = 'none';
        search.value = '';
    }

    // Close search results when clicking outside
    document.addEventListener('click', function(e) {
        if (!search.contains(e.target) && !results.contains(e.target)) {
            results.style.display = 'none';
        }
    });

    // Mobile sidebar toggle
    window.toggleSidebar = function() {
        const sidebar = document.querySelector('.sidebar');
        sidebar.classList.toggle('open');
    };

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 640) {
            const sidebar = document.querySelector('.sidebar');
            if (sidebar.classList.contains('open') && !sidebar.contains(e.target)) {
                sidebar.classList.remove('open');
            }
        }
    });
});
