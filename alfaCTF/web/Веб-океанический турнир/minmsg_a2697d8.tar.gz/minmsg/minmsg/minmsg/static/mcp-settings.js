// MCP Settings Management

let currentUserId;

function toggleMCPSettings() {
    const panel = document.getElementById('mcpSettingsPanel');
    const libraryPanel = document.getElementById('mcpLibraryPanel');

    // Close library panel if it's open
    if (libraryPanel) {
        libraryPanel.classList.remove('open');
    }

    panel.classList.toggle('open');

    if (panel.classList.contains('open')) {
        loadMCPServers();
    }
}

async function loadMCPServers() {
    try {
        const response = await fetch(`/users/${currentUserId}/mcp`);
        if (response.ok) {
            const data = await response.json();
            displayMCPServers(data.mcps);
        } else {
            console.error('Не удалось загрузить инструменты');
        }
    } catch (error) {
        console.error('Ошибка при загрузке инструментов:', error);
    }
}

function displayMCPServers(mcps) {
    const mcpList = document.getElementById('mcpList');

    if (mcps.length === 0) {
        mcpList.innerHTML = '<p style="color: #666; font-style: italic;">Пока инструментов нет.</p>';
        return;
    }

    mcpList.innerHTML = mcps.map(mcp => `
        <div class="mcp-item" data-mcp-id="${mcp.id}">
            <div class="mcp-item-header">
                <div class="mcp-url">${mcp.url}</div>
                <button class="mcp-delete-btn" onclick="deleteMCPServer(${mcp.id})">Удалить</button>
            </div>
            ${mcp.cached_data && mcp.cached_data.tools ? `
                <div class="mcp-tools">
                    <div class="mcp-tools-title">Доступные команды:</div>
                    <div class="mcp-tools-list">
                        ${mcp.cached_data.tools.map(tool => `
                            <span class="mcp-tool-tag">${tool}</span>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
            ${mcp.cached_data && mcp.cached_data.error ? `
                <div style="font-size: 12px; color: #dc3545; margin-top: 5px;">
                    ⚠️ Ошибка: ${mcp.cached_data.error}
                </div>
            ` : ''}
        </div>
    `).join('');
}

async function addMCPServer(event) {
    event.preventDefault();

    const url = document.getElementById('mcpUrl').value.trim();
    const token = document.getElementById('mcpToken').value.trim();

    if (!url) {
        alert('Введите URL сервера');
        return;
    }

    try {
        const requestData = { url };
        if (token) {
            requestData.access_token = token;
        }

        const response = await fetch(`/users/${currentUserId}/mcp`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestData)
        });

        if (response.ok) {
            // Clear form
            document.getElementById('mcpUrl').value = '';
            document.getElementById('mcpToken').value = '';

            // Reload MCP servers list
            loadMCPServers();
        } else {
            const error = await response.json();
            alert(`Не удалось добавить инструмент: ${error.detail || 'Неизвестная ошибка'}`);
        }
    } catch (error) {
        console.error('Не удалось добавить инструмент:', error);
        alert('Не удалось добавить инструмент. Пожалуйста, обновите страницу и попробуйте еще раз.');
    }
}

async function deleteMCPServer(mcpId) {
    if (!confirm('Точно удалить этот инструмент?')) {
        return;
    }

    try {
        const response = await fetch(`/users/${currentUserId}/mcp/${mcpId}/delete`, {
            method: 'POST'
        });

        if (response.ok) {
            // Remove the item from the UI
            const mcpItem = document.querySelector(`[data-mcp-id="${mcpId}"]`);
            if (mcpItem) {
                mcpItem.remove();
            }

            // Reload to ensure consistency
            loadMCPServers();
        } else {
            const error = await response.json();
            alert(`Не удалось удалить инструмент: ${error.detail || 'Unknown error'}`);
        }
    } catch (error) {
        console.error('Не удалось удалить инструмент:', error);
        alert('Не удалось удалить инструмент. Пожалуйста, обновите страницу и попробуйте еще раз.');
    }
}

// MCP Library Functions
function toggleMCPLibrary() {
    const libraryPanel = document.getElementById('mcpLibraryPanel');
    libraryPanel.classList.toggle('open');
}

function useMCPFromLibrary(url) {
    // Type 1 button: paste URL into the form field
    const urlInput = document.getElementById('mcpUrl');
    if (urlInput) {
        urlInput.value = url;
        urlInput.focus();
    }

    // Close the library panel
    const libraryPanel = document.getElementById('mcpLibraryPanel');
    if (libraryPanel) {
        libraryPanel.classList.remove('open');
    }
}

function openMCPAuthentication(url) {
    // Type 2 button: open URL in new tab
    window.open(url, '_blank', 'noopener,noreferrer');
}

// Initialize MCP settings when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    const addMCPForm = document.getElementById('addMCPForm');
    if (addMCPForm) {
        addMCPForm.addEventListener('submit', addMCPServer);
    }
});
