function initChatListPolling(initialChatSummary) {
    let currentChatSummary = initialChatSummary;
    let timeout;

    function schedulePoll() {
        let thisTimeout = setTimeout(() => {
            if (document.hidden) {
                return;
            }

            fetch('/chats/summary')
                .then(r => r.json())
                .then(newChatSummary => {
                    // Check if anything has changed
                    if (hasChatsChanged(currentChatSummary, newChatSummary)) {
                        // Update everything by reloading the page
                        window.location.reload();
                    } else {
                        currentChatSummary = newChatSummary;
                    }

                    if (timeout == thisTimeout) schedulePoll();
                })
                .catch(err => {
                    console.error('Error polling for chat list updates:', err);
                    if (timeout == thisTimeout) schedulePoll();
                });
        }, 5000); // Poll every 5 seconds
        timeout = thisTimeout;
    }

    function hasChatsChanged(oldSummary, newSummary) {
        return JSON.stringify(oldSummary) !== JSON.stringify(newSummary);
    }

    // Start polling
    schedulePoll();

    // Pause polling when page is hidden, resume when visible
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            schedulePoll();
        }
    });
}
