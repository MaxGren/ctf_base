// Chat page JavaScript functionality

// Format timestamps to local timezone
function formatMessageTime(timestampString) {
    if (!timestampString) return '';

    const timestamp = new Date(timestampString);
    return timestamp.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
    });
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Auto-scroll to bottom
    const messagesDiv = document.getElementById('messages');
    if (messagesDiv) {
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
    }

    // Update all message times on page load
    document.querySelectorAll('.message-time[data-timestamp]').forEach(timeElement => {
        const timestamp = timeElement.dataset.timestamp;
        if (timestamp) {
            timeElement.textContent = formatMessageTime(timestamp);
        }
    });
});// Handle form submission
const form = document.getElementById('messageForm');
const input = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');

// reCAPTCHA variables
let pendingSubmission = false;

// Submit on Enter (but not Shift+Enter)
input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        const text = input.value.trim();
        if (text && !sendBtn.disabled) {
            showRecaptchaPopup();
        }
    }
});

form.addEventListener('submit', function(e) {
    const text = input.value.trim();
    if (!text) {
        e.preventDefault();
        return;
    }

    // Check if reCAPTCHA token exists
    const recaptchaResponse = document.getElementById('recaptchaResponse').value;

    if (!recaptchaResponse) {
        e.preventDefault();
        showRecaptchaPopup();
        return;
    }

    sendBtn.disabled = true;
    sendBtn.textContent = 'Отправка...';
});

// reCAPTCHA functions
function showRecaptchaPopup() {
    const popup = document.getElementById('recaptchaPopup');
    popup.style.display = 'flex';
    pendingSubmission = true;
}

function closeRecaptchaPopup() {
    const popup = document.getElementById('recaptchaPopup');
    popup.style.display = 'none';
    pendingSubmission = false;

    // Reset reCAPTCHA
    if (typeof grecaptcha !== 'undefined') {
        grecaptcha.reset();
    }
    document.getElementById('recaptchaResponse').value = '';
}

function onRecaptchaSuccess(token) {
    document.getElementById('recaptchaResponse').value = token;

    // If we were waiting to submit, trigger form submission immediately
    if (pendingSubmission) {
        pendingSubmission = false; // Reset this first to prevent loops

        closeRecaptchaPopup();

        // Trigger form submission directly
        const text = input.value.trim();
        if (text) {
            sendBtn.disabled = true;
            sendBtn.textContent = 'Отправка...';

            // Create form submission manually
            const formData = new FormData();
            formData.append('text', text);
            formData.append('g-recaptcha-response', token);

            fetch(form.action, {
                method: 'POST',
                body: formData
            }).then(async (response) => {
                if (response.redirected) {
                    window.location.href = response.url;
                } else {
                    alert('Ошибка при отправке сообщения: ' + await response.text() + '\n\nПопробуйте ещё раз.')
                }
            }).catch(error => {
                console.error('Submission error:', error);
                sendBtn.disabled = false;
                sendBtn.textContent = 'Отправить';
            });
        }
    } else {
        closeRecaptchaPopup();
    }
}

// Focus on input and initialize scrollbar state
input.focus();

// Initial check for scrollbar visibility
function checkScrollbarVisibility() {
    if (input.scrollHeight > 120) {
        input.classList.add('scrollable');
    } else {
        input.classList.remove('scrollable');
    }
}

// Check on page load
checkScrollbarVisibility();

// Chat polling functionality
function initChatPolling(chatId, initialLastMessageId) {
    // Store the current last message ID for polling
    let currentLastMessageId = initialLastMessageId;
    let timeout;

    // Function to get the actual last message ID from the DOM
    function getLastMessageIdFromDOM() {
        const messagesDiv = document.getElementById('messages');
        if (!messagesDiv) return null;

        const messages = messagesDiv.querySelectorAll('.message[data-message-id]');
        if (messages.length === 0) return null;

        let lastId = null;
        messages.forEach(message => {
            const messageId = parseInt(message.dataset.messageId);
            if (lastId === null || messageId > lastId) {
                lastId = messageId;
            }
        });

        return lastId;
    }

    function schedulePoll() {
        let thisTimeout = setTimeout(() => {
            if (document.hidden) {
                return;
            }

            fetch(`/chat/${chatId}/id`)
                .then(r => r.json())
                .then(data => {
                    const newLastMessageId = data.id;
                    const domLastMessageId = getLastMessageIdFromDOM();

                    // Update our tracking to match what's actually in the DOM
                    if (domLastMessageId && domLastMessageId > currentLastMessageId) {
                        currentLastMessageId = domLastMessageId;
                    }

                    // Only reload if there are truly new messages we don't have
                    if (newLastMessageId && newLastMessageId > currentLastMessageId && currentLastMessageId !== null) {
                        window.location.reload();
                    } else if (currentLastMessageId === null && newLastMessageId) {
                        currentLastMessageId = newLastMessageId;
                    }

                    if (timeout == thisTimeout) schedulePoll();
                })
                .catch(err => {
                    console.error('Error polling for new messages:', err);
                    if (timeout == thisTimeout) schedulePoll();
                });
        }, 5000); // Poll in 5 seconds
        timeout = thisTimeout;
    }

    // Start polling
    schedulePoll();

    // Pause polling when page is hidden, resume when visible
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            schedulePoll();
        }
    });
}

// Message history loading functionality
function initMessageHistory(chatId, currentUserId) {
    const messagesDiv = document.getElementById('messages');
    if (!messagesDiv) return;

    let isLoading = false;
    let hasMoreMessages = true;

    // Get the oldest message ID from current messages
    function getOldestMessageId() {
        const messages = messagesDiv.querySelectorAll('.message[data-message-id]');
        if (messages.length === 0) return null;

        let oldestId = null;
        messages.forEach(message => {
            const messageId = parseInt(message.dataset.messageId);
            if (oldestId === null || messageId < oldestId) {
                oldestId = messageId;
            }
        });

        return oldestId;
    }

    // Create message HTML from message data
    function createMessageElement(message) {
        const messageDiv = document.createElement('div');
        let messageClass = 'message ';

        if (message.sender && message.sender.id === currentUserId) {
            messageClass += 'own';
        } else if (message.sender === null) {
            messageClass += 'ai';
        } else {
            messageClass += 'other';
        }

        messageDiv.className = messageClass;
        messageDiv.setAttribute('data-message-id', message.id);

        let messageHTML = '';

        // Add sender name for non-own messages
        if (!message.sender || message.sender.id !== currentUserId) {
            const senderName = message.sender === null ? '🤖 Робот Евлампий' :
                              (message.sender ? message.sender.username : 'Unknown');
            messageHTML += `<div class="message-sender">${senderName}</div>`;
        }

        messageHTML += `
            <div class="message-bubble">${message.text}</div>
            <div class="message-time" data-timestamp="${message.timestamp}">${formatMessageTime(message.timestamp)}</div>
        `;

        messageDiv.innerHTML = messageHTML;
        return messageDiv;
    }

    // Load older messages
    async function loadOlderMessages() {
        if (isLoading || !hasMoreMessages) return;

        const oldestId = getOldestMessageId();
        if (!oldestId) return;

        isLoading = true;

        // Store current scroll position
        const previousScrollHeight = messagesDiv.scrollHeight;

        try {
            // Create a loading indicator
            const loadingDiv = document.createElement('div');
            loadingDiv.className = 'loading-indicator';
            loadingDiv.innerHTML = '<div style="text-align: center; padding: 10px; color: #666; font-size: 14px;">Загрузка сообщений...</div>';
            messagesDiv.insertBefore(loadingDiv, messagesDiv.firstChild);

            const response = await fetch(`/chat/${chatId}/history?before=${oldestId}`);
            const data = await response.json();

            // Remove loading indicator
            loadingDiv.remove();

            if (!data.messages || data.messages.length === 0) {
                hasMoreMessages = false;
                return;
            }

            // Create message elements and insert them at the top
            const fragment = document.createDocumentFragment();
            data.messages.forEach(message => {
                const messageElement = createMessageElement(message);
                fragment.appendChild(messageElement);
            });

            // Insert new messages at the beginning
            messagesDiv.insertBefore(fragment, messagesDiv.firstChild);

            // Restore scroll position to maintain user's view
            const newScrollHeight = messagesDiv.scrollHeight;
            messagesDiv.scrollTop = newScrollHeight - previousScrollHeight;

        } catch (error) {
            console.error('Error loading older messages:', error);
            // Remove loading indicator if it exists
            const loadingIndicator = messagesDiv.querySelector('.loading-indicator');
            if (loadingIndicator) {
                loadingIndicator.remove();
            }
        } finally {
            isLoading = false;
        }
    }

    // Add scroll event listener
    messagesDiv.addEventListener('scroll', () => {
        // Check if scrolled to top (with some threshold)
        if (messagesDiv.scrollTop <= 50 && !isLoading && hasMoreMessages) {
            loadOlderMessages();
        }
    });
}

// Make reCAPTCHA functions available globally
window.showRecaptchaPopup = showRecaptchaPopup;
window.closeRecaptchaPopup = closeRecaptchaPopup;
window.onRecaptchaSuccess = onRecaptchaSuccess;
