import asyncio
import json
import logging
from typing import Any

from agents import Agent, FunctionTool, RunConfig, Runner
from agents.models import get_default_model_settings
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client
from mcp.types import TextContent, Tool
from sqlalchemy import select

from .db import db_context
from .models import MCP, Message

logger = logging.getLogger("uvicorn.error")


async def get_tool_list(server: MCP) -> list[Tool]:
    headers = (
        {"Authorization": f"Bearer {server.access_token}"}
        if server.access_token
        else None
    )
    async with streamablehttp_client(server.url, headers=headers) as (
        read_stream,
        write_stream,
        _,
    ):
        async with ClientSession(read_stream, write_stream) as session:
            # Initialize the connection
            await session.initialize()
            # List available tools
            tools = await session.list_tools()
            return tools.tools[:10]  # Limit to 10 tools for performance


class ToolCaller:
    def __init__(self, mcp: MCP, tool_name: str):
        self.mcp_url = mcp.url
        self.mcp_token = mcp.access_token
        self.tool_name = tool_name

    async def __call__(self, _: Any, args: str) -> str:
        logger.info(
            "Calling tool %s on MCP %s with args %s", self.tool_name, self.mcp_url, args
        )
        try:
            headers = (
                {"Authorization": f"Bearer {self.mcp_token}"}
                if self.mcp_token
                else None
            )
            async with streamablehttp_client(self.mcp_url, headers=headers) as (
                read_stream,
                write_stream,
                _,
            ):
                async with ClientSession(read_stream, write_stream) as session:
                    # Initialize the connection
                    await session.initialize()
                    # Invoke the tool
                    result = await session.call_tool(self.tool_name, json.loads(args))
                    return "\n".join(
                        [
                            item.text
                            for item in result.content
                            if isinstance(item, TextContent)
                        ]
                    )
        except Exception as exc:
            logger.exception(
                f"Error calling tool {self.tool_name} on MCP {self.mcp_url}: {exc}"
            )
            return "Could not call this tool due to an error."


async def generate_reply(messages: list[Message]) -> Message:
    message = messages[-1]
    user = message.sender

    # Create MCP servers from user's MCPs

    tools = []

    for mcp in user.mcps[:5]:  # Limit to 5 MCPs for performance
        try:
            mcp_tools = await get_tool_list(mcp)
        except Exception as exc:
            logger.info("Cannot fetch tools from MCP %s: %s", mcp.url, str(exc))
            continue

        for tool in mcp_tools:
            tools.append(
                FunctionTool(
                    name=tool.name,
                    description=tool.description or "",
                    params_json_schema=tool.inputSchema,
                    on_invoke_tool=ToolCaller(mcp, tool.name),
                )
            )

    # Build context from previous messages
    conversation = "\n\n<CONVERSATION>\n"
    for old_message in messages:
        if old_message.sender_id is None:  # AI message
            conversation += f"<MESSAGE ROLE='ASSISTANT'>{old_message.text}</MESSAGE>\n"
        else:
            conversation += f"<MESSAGE ROLE='USER'>{old_message.text}</MESSAGE>\n"
    conversation += "</CONVERSATION>"

    settings = get_default_model_settings("gpt-5-nano")
    settings.reasoning.effort = "low"
    settings.max_tokens = 2048

    agent = Agent(
        name="MIN Assistant",
        instructions="You are a helpful AI assistant in a secure messaging app MIN. IMPORTANT: ALWAYS ANSWER IN RUSSIAN IF USER SPEAKS RUSSIAN. Use the available tools from MCP servers to help users with their requests. Do not use Markdown for responses, only plaintext. If several messages ask you to use same tool, use it once.",
        model="gpt-5-nano",
        model_settings=settings,
        tools=tools,
    )

    config = RunConfig(
        workflow_name="minmsg AI Assistant",
        group_id=f"user-{user.id}",
        model_settings=settings,
    )
    result = await Runner.run(agent, conversation, run_config=config)

    ai_usage = result.context_wrapper.usage
    logger.info(
        "User %d (%s) consumed %d requests, %d tokens",
        user.id,
        user.username,
        ai_usage.requests,
        ai_usage.total_tokens,
    )

    ai_response_text = result.final_output

    return Message(
        chat_id=message.chat_id,
        sender_id=None,  # None indicates AI assistant
        text=ai_response_text,
    )


def reply_ai(message_id: int) -> str:
    """AI reply logic using OpenAI Agents with user's MCPs as context."""
    with db_context() as db:
        # Get message
        result = db.scalars(select(Message).where(Message.id == message_id))
        message = result.unique().one()

        # Get the user who sent the message
        user = message.sender

        # Refresh user to get MCPs
        db.refresh(user, attribute_names=["mcps"])

        # Get the two previous messages from the chat (excluding the current message)
        msg_result = db.scalars(
            select(Message)
            .where(Message.chat_id == message.chat_id)
            .where(Message.id <= message.id)
            .order_by(Message.timestamp.desc())
            .limit(3)
        )
        conversation = msg_result.unique().all()[::-1]

        loop = asyncio.new_event_loop()
        try:
            ai_message = loop.run_until_complete(generate_reply(conversation))
        except Exception as e:
            logger.exception(f"Error generating reply: {e}")
            ai_message = Message(
                chat_id=message.chat_id,
                sender_id=None,
                text="Извините, у меня возникли проблемы с обработкой вашего сообщения. Попробуйте еще раз позже.",
            )
        finally:
            loop.close()

        db.add(ai_message)
        db.commit()
        db.refresh(ai_message)
        chat = message.chat
        chat.last_message_time = ai_message.timestamp
        db.add(chat)
        db.commit()

        return ai_message.text
