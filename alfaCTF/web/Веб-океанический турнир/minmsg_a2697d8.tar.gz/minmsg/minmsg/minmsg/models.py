from .db import Base
from sqlalchemy import (
    BigInteger,
    Column,
    Integer,
    String,
    ForeignKey,
    DateTime,
    Table,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import JSONB
from datetime import datetime
from typing import Any, Optional
import bcrypt


user_chat = Table(
    "user_chats",
    Base.metadata,
    Column(
        "user_id",
        Integer,
        ForeignKey("users.id", onupdate="cascade", ondelete="cascade"),
        primary_key=True,
    ),
    Column(
        "chat_id",
        Integer,
        ForeignKey("chats.id", onupdate="cascade", ondelete="cascade"),
        primary_key=True,
    ),
)


class User(Base):
    """Users and their credentials."""

    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, autoincrement=True, primary_key=True)
    username: Mapped[str] = mapped_column(String, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String, nullable=False)

    sent_messages: Mapped[list["Message"]] = relationship(
        "Message", back_populates="sender"
    )
    mcps: Mapped[list["MCP"]] = relationship("MCP", back_populates="user")
    chats: Mapped[list["Chat"]] = relationship(
        "Chat", secondary=user_chat, back_populates="users"
    )

    __table_args__ = (UniqueConstraint("username"), )

    def set_password(self, password: str) -> None:
        self.password_hash = bcrypt.hashpw(
            password.encode("utf-8"), bcrypt.gensalt()
        ).decode("utf-8")

    def check_password(self, password: str) -> bool:
        return bcrypt.checkpw(
            password.encode("utf-8"), self.password_hash.encode("utf-8")
        )


class Message(Base):
    """Messages."""

    __tablename__ = "messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    chat_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("chats.id", onupdate="cascade", ondelete="cascade"),
        nullable=False,
    )
    # Null is AI assistant
    sender_id: Mapped[int | None] = mapped_column(
        Integer,
        ForeignKey("users.id", onupdate="cascade", ondelete="cascade"),
        nullable=True,
    )
    text: Mapped[str] = mapped_column(Text, nullable=False)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime,
        default=lambda: datetime.utcnow(),
        server_default=func.now(),
    )

    sender: Mapped[Optional["User"]] = relationship(
        "User", back_populates="sent_messages", lazy="joined"
    )
    chat: Mapped["Chat"] = relationship(
        "Chat", back_populates="messages", lazy="joined"
    )


class MCP(Base):
    """MCP servers installed by current user."""

    __tablename__ = "mcps"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("users.id", onupdate="cascade", ondelete="cascade"),
        nullable=False,
    )
    url: Mapped[str] = mapped_column(String, nullable=False)
    access_token: Mapped[str | None] = mapped_column(String, nullable=True)
    cached_data: Mapped[Any | None] = mapped_column(JSONB, nullable=True)

    user: Mapped["User"] = relationship("User", back_populates="mcps", lazy="joined")


class Chat(Base):
    """Chat between two users."""

    __tablename__ = "chats"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    users: Mapped[list["User"]] = relationship(
        "User", secondary=user_chat, back_populates="chats", lazy="joined"
    )
    pinned: Mapped[bool] = mapped_column(
        default=False, server_default="false"
    )  # AI chat is pinned
    last_message_time: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
        default=None,
    )

    messages: Mapped[list["Message"]] = relationship("Message", back_populates="chat")

    def chatmate_for(self, user: User) -> User | None:
        """Get other chatting person. Returns None for AI chat."""
        for peer in self.users:
            if peer != user:
                return peer
        return None
