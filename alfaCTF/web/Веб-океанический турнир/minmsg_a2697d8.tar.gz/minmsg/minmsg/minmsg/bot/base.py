import logging
import threading
from concurrent.futures import Future
from contextvars import ContextVar

from sqlalchemy import select

from ..ai import reply_ai
from ..db import DB, db_context
from ..models import User, Message
from ..utils import create_or_find_chat_between_sync

logger = logging.getLogger("uvicorn.error")


def run_in_thread(fn, *args, **kwargs):
    future = Future()

    def wrapper():
        try:
            result = fn(*args, **kwargs)
            future.set_result(result)
        except Exception as e:
            future.set_exception(e)

    threading.Thread(target=wrapper).start()
    return future


class BaseBot:
    _bot_id: ContextVar[int | None] = ContextVar("bot_id", default=None)

    def init_context(self, bot_id: int) -> None:
        self._bot_id.set(bot_id)

    @property
    def username(self) -> str:
        """This method should return the username of the bot."""
        raise NotImplementedError

    async def initialize(self, db: DB, user: User) -> None:
        """This method may do additional actions to initialize the user."""
        pass

    def reply(self, conversation: list[Message]) -> str:
        """This method should implement the bot's reply logic.

        Arguments:
            conversation: Three last messages in the chat, ordered by timestamp ascending.
                          The last message is always the one to reply to.

        Returns: The bot's reply as a string."""
        raise NotImplementedError

    def fallback(self, exc: Exception) -> str:
        """This method should return fallback message in case of error."""
        raise NotImplementedError

    def write_to_ai_assistant(self, text: str) -> str:
        """This method allows you to write to AI assistant in separate chat.

        Arguments:
            text: text to send to AI assistant

        Returns: AI assistant's reply as a string."""

        message_id = send_message(self._bot_id.get(), None, text)
        return run_in_thread(reply_ai, message_id).result()

    def write_to_user(self, user_id: int, text: str) -> None:
        """This method allows you to write message to user.
        DOES NOT await user's reply as it is not instant.

        Arguments:
            user_id: ID of the user to send the message
            text: text of the message"""

        send_message(self._bot_id.get(), user_id, text)


def send_message(author_id: int, target_id: int | None, message: str) -> int:
    with db_context() as db:
        result = db.scalars(select(User).where(User.id == author_id))
        me = result.unique().one()

        if target_id is not None:
            result = db.scalars(select(User).where(User.id == target_id))
            target = result.unique().one()
        else:
            target = None

        chat = create_or_find_chat_between_sync(db, me, target)

        new_message = Message(chat=chat, sender=me, text=message)
        db.add(new_message)
        db.commit()
        db.refresh(new_message)

        return new_message.id
