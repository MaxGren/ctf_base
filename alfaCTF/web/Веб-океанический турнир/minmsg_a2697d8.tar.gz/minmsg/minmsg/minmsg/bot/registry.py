import logging

from sqlalchemy import exists, select

from ..db import DB, db_context
from ..models import Message, User
from ..utils import create_or_find_chat_between
from .base import BaseBot
from .gigachad import Gigachad

logger = logging.getLogger("uvicorn.error")

registry: list[BaseBot] = [Gigachad()]


async def create_bot_users(
    db: DB,
):
    created_users: list[User] = []
    for bot in registry:
        bot_exists = await db.scalar(
            exists()
            .where(
                User.username == bot.username,
            )
            .select()
        )

        if bot_exists:
            continue

        bot_user = User(
            username=bot.username,
            password_hash="*",
        )
        db.add(bot_user)
        created_users.append(bot_user)

    await db.commit()
    for bot_user in created_users:
        await db.refresh(bot_user)
        await create_or_find_chat_between(db, bot_user, None)
        await bot.initialize(db, bot_user)


def message_hook(message_id: int) -> None:
    with db_context() as db:
        result = db.scalars(select(Message).where(Message.id == message_id))
        message = result.unique().one()

        bot_user = message.chat.chatmate_for(message.sender)

        if bot_user is None:
            return

        for bot in registry:
            if bot_user.username == bot.username:
                break
        else:
            return

        bot._bot_id.set(bot_user.id)

        # Get last three messages from the same chat
        msg_result = db.scalars(
            select(Message)
            .where(Message.chat_id == message.chat_id)
            .where(Message.id <= message.id)
            .order_by(Message.timestamp.desc())
            .limit(3)
        )
        conversation = msg_result.unique().all()[::-1]

        try:
            bot_reply = bot.reply(conversation)
        except Exception as exc:
            logger.exception(f"Error generating reply: {exc}")
            bot_reply = bot.fallback(exc)

        bot_message = Message(
            chat_id=message.chat_id,
            sender_id=bot_user.id,
            text=bot_reply,
        )

        db.add(bot_message)
        db.commit()
        db.refresh(bot_message)
        chat = message.chat
        chat.last_message_time = bot_message.timestamp
        db.add(chat)
        db.commit()
