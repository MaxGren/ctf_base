from contextlib import contextmanager
from typing import Annotated, AsyncGenerator, Generator
from fastapi import Depends
from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker
import os

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://min:min@db:5432/min")

sync_engine = create_engine(
    DATABASE_URL.replace("postgresql://", "postgresql+psycopg://")
)
SessionLocal = sessionmaker(sync_engine, autocommit=False, autoflush=False)

async_engine = create_async_engine(
    DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://")
)
AsyncSessionLocal = async_sessionmaker(async_engine, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


async def get_async_db() -> AsyncGenerator[AsyncSession]:
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except:
            await session.rollback()
            raise
        finally:
            await session.close()


@contextmanager
def db_context() -> Generator[Session]:
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except:
        db.rollback()
        raise
    finally:
        db.close()


DB = Annotated[AsyncSession, Depends(get_async_db)]


async def init_db():
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
