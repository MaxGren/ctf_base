const SATS_PER_BTC = 100_000_000;


let catalog = [];
let slices = [];
let basket = [];
let balanceSats = 0;


const formatBTC = (sats) => {
  if (!Number.isFinite(sats)) return `${sats} BTC`;
  const sign = sats < 0 ? "-" : "";
  const abs = Math.abs(Math.trunc(sats));
  const whole = Math.floor(abs / SATS_PER_BTC);
  const frac = String(abs % SATS_PER_BTC).padStart(8, "0");
  return `${sign}${whole}.${frac} BTC`;
};


const $balanceText = document.querySelector("#balance-text");
const $catalog = document.querySelector("#catalog");
const $basketBody = document.querySelector("#basket-body");
const $basketTotal = document.querySelector("#basket-total");
const $checkout = document.querySelector("#checkout-btn");
const $msg = document.querySelector("#message");

function showMsg(text, kind) {
  if (!$msg) return;
  $msg.className = `message ${kind || ""}`;
  $msg.textContent = text;
}



function encodeForm(params) {
  return Object.entries(params)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`)
    .join("&");
}

async function api(path, { method = "GET", params = null } = {}) {
  const opts = { method };
  if (method !== "GET" && params) {
    opts.headers = { "Content-Type": "application/x-www-form-urlencoded" };
    opts.body = encodeForm(params);
  }


  if (method === "GET" && params) {
    const qs = encodeForm(params);
    path = qs ? `${path}?${qs}` : path;
  }

  const res = await fetch(path, opts);

  let data = null;
  try { data = await res.json(); } catch { data = {}; }

  if (!res.ok) {
    const msg = (data && data.error) || `HTTP ${res.status}`;
    throw new Error(msg);
  }
  return data;
}

async function loadInit() {
  const data = await api("/vip/init");
  const cat = Array.isArray(data?.catalog) ? data.catalog : [];
  const slc = Array.isArray(data?.slices) ? data.slices : [];
  const bal = (typeof data?.balanceSats === "number" || typeof data?.balanceSats === "string")
    ? Number(data.balanceSats)
    : 0;

  catalog = cat.map(c => ({ ...c, priceSats: Number(c.priceSats) }));
  slices = slc;
  balanceSats = bal;

  renderBalance();
  renderCatalog();
  await refreshBasket();
}

async function refreshBasket() {
  const data = await api("/vip/basket");
  const items = Array.isArray(data?.items) ? data.items : [];
  const totalNum = (typeof data?.totalSats === "number" || typeof data?.totalSats === "string")
    ? Number(data.totalSats)
    : 0;

  basket = items.map(x => ({ ...x, priceSatsLine: Number(x.priceSatsLine) }));
  renderBasket(totalNum);
}


function renderBalance() {
  if ($balanceText) $balanceText.textContent = formatBTC(balanceSats);
}

function sliceLabel(sku, code) {
  const item = catalog.find(i => i.sku === sku);
  const list = (item && Array.isArray(item.slices) && item.slices.length)
    ? item.slices
    : slices;
  const s = list.find(x => x.code === code);
  return s ? s.label : code;
}

function renderCatalog() {
  if (!$catalog) return;
  $catalog.innerHTML = "";


  const item = (catalog || []).find(it => it.sku === "FLAG");
  if (item) {
    const card = document.createElement("div");
    card.className = "card";

    const h3 = document.createElement("h3");
    h3.textContent = item.name;

    const price = document.createElement("div");
    price.className = "price";
    price.textContent = `Price: ${formatBTC(item.priceSats)}`;

    const addBtn = document.createElement("button");
    addBtn.className = "btn primary";
    addBtn.textContent = "Add";
    addBtn.addEventListener("click", async () => {
      try {
        await api("/vip/basket/add", { method: "POST", params: { sku: "FLAG" } });
        await refreshBasket();
        showMsg(`Added ${item.name}`, "ok");
      } catch (e) {
        showMsg(e.message, "err");
      }
    });

    const row = document.createElement("div");
    row.className = "row";
    row.appendChild(addBtn);

    card.appendChild(h3);
    card.appendChild(price);
    card.appendChild(row);
    $catalog.appendChild(card);
  }


  const backCard = document.createElement("div");
  backCard.className = "card";
  const backH3 = document.createElement("h3");
  backH3.textContent = "🌴🌴🌴";
  const backA = document.createElement("a");
  backA.href = "/";
  backA.className = "btn primary";
  backA.textContent = "Back to main";
  backCard.appendChild(backH3);
  backCard.appendChild(backA);
  $catalog.appendChild(backCard);
  backCard.style.display = "flex";
  backCard.style.flexDirection = "column";
  backA.style.marginTop = "auto";
  backA.style.width = "125px";
}

function renderBasket(total) {
  $basketBody.innerHTML = "";
  basket.forEach((it, idx) => {
    const tr = document.createElement("tr");

    const tdName = document.createElement("td");
    tdName.textContent = it.name;

    const tdSlice = document.createElement("td");
    tdSlice.textContent = sliceLabel(it.sku, it.sliceCode);

    const tdPrice = document.createElement("td");
    tdPrice.textContent = formatBTC(it.priceSatsLine);

    const tdAct = document.createElement("td");
    const rm = document.createElement("button");
    rm.className = "btn danger";
    rm.textContent = "Remove";
    rm.addEventListener("click", async () => {
      try {
        await api("/vip/basket/remove", {
          method: "POST",
          params: { index: idx }
        });
        await refreshBasket();
        showMsg("Removed item", "warn");
      } catch (e) {
        showMsg(e.message, "err");
      }
    });
    tdAct.appendChild(rm);

    tr.appendChild(tdName);
    tr.appendChild(tdSlice);
    tr.appendChild(tdPrice);
    tr.appendChild(tdAct);
    $basketBody.appendChild(tr);
  });

  $basketTotal.textContent = formatBTC(total);
}


$checkout.addEventListener("click", async () => {
  try {
    const data = await api("/checkout-vip", { method: "POST" });
    if (data.ok) {
      balanceSats = Number(data.newBalanceSats);
      await refreshBasket();
      renderBalance();

      if (data.flag) {
        showMsg(`FLAG: ${data.flag}`, "ok");
      } else {
        showMsg("Checkout successful", "ok");
      }
    }
  } catch (e) {
    showMsg(e.message, "err");
  }
});


loadInit().catch(e => showMsg(e.message, "err"));
