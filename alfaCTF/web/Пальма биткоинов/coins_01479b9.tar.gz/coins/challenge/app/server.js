import http from "http";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 8080;
const STATIC_DIR = path.join(__dirname, "static");


const SLICES = [
  { code: "1/1", num: 1, den: 1, label: "Whole" },
  { code: "1/2", num: 1, den: 2, label: "1/2" },
  { code: "1/4", num: 1, den: 4, label: "1/4" },
  { code: "1/8", num: 1, den: 8, label: "1/8" }
];


const MAIN_ITEMS = [
  { sku: "BANAN", name: "BananaCoin 🍌", priceSats:  50_000 },
  { sku: "COCON", name: "CocoCoin 🥥",   priceSats:  80_000 },
  { sku: "MANGO", name: "MangoCoin 🥭",  priceSats: 120_000 }
];

const VIP_ITEMS = [
  { sku: "FLAG",  name: "FLAG 🏁",       priceSats: 999_999_999 }
];


const sessions = new Map();
function newSession() { return { balanceSats: 0, basketMain: [], basketVip: [] }; }

function getOrCreateSession(reqHeaders, resHeaders) {
  const cookies = parseCookies(reqHeaders.cookie || "");
  let sid = cookies.sid;
  if (!sid || !sessions.has(sid)) {
    sid = crypto.randomBytes(16).toString("hex");
    sessions.set(sid, newSession());
    resHeaders["Set-Cookie"] = `sid=${sid}; HttpOnly; SameSite=Lax; Path=/`;
  }
  return { sid, session: sessions.get(sid) };
}


function parseCookies(cookieStr) {
  const out = {};
  cookieStr.split(";").forEach(p => {
    const [k, ...rest] = p.trim().split("=");
    if (!k) return;
    out[decodeURIComponent(k)] = decodeURIComponent(rest.join("=") || "");
  });
  return out;
}

function parseSlice(sliceCode) {
  if (typeof sliceCode !== "string") return null;

  const parts = sliceCode.split("/");
  if (parts.length !== 2) return null;

  const left = parts[0].trim();
  const right = parts[1].trim();

  const numN = Number(left);
  const denN = Number(right);

  if (!Number.isFinite(numN) || !Number.isFinite(denN)) return null;
  if (!Number.isInteger(numN) || !Number.isInteger(denN)) return null;
  if (numN < 0) return null;

  return { code: `${numN}/${denN}`, num: numN, den: denN };
}

function basketTotal(basket) {
  return (basket || []).reduce((a, it) => a + Number(it.priceSatsLine || 0), 0);
}

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".webp": "image/webp",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".svg": "image/svg+xml"
};


function isApiPath(pathname) {
  return [
    "/init",
    "/basket",
    "/basket/add",
    "/basket/remove",
    "/checkout-main",

    "/vip/init",
    "/vip/basket",
    "/vip/basket/add",
    "/vip/basket/remove",
    "/checkout-vip"
  ].includes(pathname);
}


http.createServer(async (req, res) => {
  const headers = { "Content-Type": "text/plain; charset=utf-8" };
  try {
    const { session } = getOrCreateSession(req.headers, headers);
    const url = new URL(req.url, "http://localhost");


    if (isApiPath(url.pathname)) {
      await handleRoutes(req, res, headers, url, session);
      return;
    }


    const safePath = path.posix.normalize(decodeURIComponent(url.pathname));
    const relPath = safePath === "/"
      ? "index.html"
      : (safePath === "/vip" ? "vip.html" : safePath.replace(/^\/+/, ""));
    const filePath = path.join(STATIC_DIR, relPath);

    fs.readFile(filePath, (err, content) => {
      if (res.headersSent) return;
      if (err) {
        res.writeHead(404, headers);
        res.end("Not found\n");
        return;
      }
      const ext = path.extname(filePath).toLowerCase();
      res.writeHead(200, { ...headers, "Content-Type": MIME[ext] || "application/octet-stream" });
      res.end(content);
    });
  } catch (e) {
    if (!res.headersSent) {
      res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("Internal Server Error\n");
    }
  }
}).listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on port ${PORT}`);
});


async function handleRoutes(req, res, headers, url, session) {
  const params = await readParams(req, url);


  if (req.method === "GET" && url.pathname === "/init") {
    const toSlice = s => ({ code: s.code, label: s.label });
    const slicesView = SLICES.map(toSlice);
    const catalog = MAIN_ITEMS.map(({ sku, name, priceSats }) => ({
      sku, name, priceSats, slices: slicesView
    }));
    return sendJSON(res, headers, 200, {
      balanceSats: session.balanceSats,
      catalog
    });
  }


  if (req.method === "GET" && url.pathname === "/vip/init") {
    const catalog = VIP_ITEMS.map(({ sku, name, priceSats }) => ({ sku, name, priceSats }));
    return sendJSON(res, headers, 200, { balanceSats: session.balanceSats, catalog });
  }


  if (req.method === "GET" && url.pathname === "/basket") {
    const items = (session.basketMain || []).map(x => ({ ...x }));
    const total = basketTotal(session.basketMain);
    return sendJSON(res, headers, 200, { items, totalSats: total });
  }

  if (req.method === "POST" && url.pathname === "/basket/add") {
    const { sku, sliceCode } = params || {};
    const item = MAIN_ITEMS.find(x => x.sku === String(sku));
    if (!item) {
      return sendJSON(res, headers, 400, { error: "Item not found" });
    }
    const parsed = parseSlice(String(sliceCode || ""));
    if (!parsed) {
      return sendJSON(res, headers, 400, { error: "Invalid slice format" });
    }
    const line = (item.priceSats * parsed.num) / parsed.den;
    session.basketMain.push({
      sku: item.sku,
      name: item.name,
      sliceCode: parsed.code,
      priceSatsLine: line
    });
    const items = session.basketMain.map(x => ({ ...x }));
    return sendJSON(res, headers, 200, { ok: true, items, totalSats: basketTotal(session.basketMain) });
  }

  if (req.method === "POST" && url.pathname === "/basket/remove") {
    const index = Number(params?.index);
    if (!Number.isInteger(index) || index < 0 || index >= (session.basketMain || []).length) {
      return sendJSON(res, headers, 400, { error: "Invalid index" });
    }
    session.basketMain.splice(index, 1);
    const items = session.basketMain.map(x => ({ ...x }));
    return sendJSON(res, headers, 200, { ok: true, items, totalSats: basketTotal(session.basketMain) });
  }

  if (req.method === "POST" && url.pathname === "/checkout-main") {
    const total = basketTotal(session.basketMain);
    if (total < 0) return sendJSON(res, headers, 400, { error: "Invalid total" });

    const invalid = (session.basketMain || []).some(it => !MAIN_ITEMS.find(mi => mi.sku === it.sku));
    if (invalid) return sendJSON(res, headers, 400, { error: "Main basket contains invalid item" });
    if (!(session.balanceSats < total)) {
      session.balanceSats -= total;
      session.basketMain = [];
      return sendJSON(res, headers, 200, { ok: true, newBalanceSats: session.balanceSats });
    }
    return sendJSON(res, headers, 400, { error: "Insufficient balance" });
  }


  if (req.method === "GET" && url.pathname === "/vip/basket") {
    const items = (session.basketVip || []).map(x => ({ ...x }));
    const total = basketTotal(session.basketVip);
    return sendJSON(res, headers, 200, { items, totalSats: total });
  }

  if (req.method === "POST" && url.pathname === "/vip/basket/add") {
    const { sku } = params || {};
    const flag = VIP_ITEMS.find(x => x.sku === "FLAG");
    if (String(sku) !== "FLAG" || !flag) {
      return sendJSON(res, headers, 400, { error: "Item not found" });
    }
    session.basketVip.push({
      sku: flag.sku,
      name: flag.name,

      priceSatsLine: flag.priceSats
    });
    const items = session.basketVip.map(x => ({ ...x }));
    return sendJSON(res, headers, 200, { ok: true, items, totalSats: basketTotal(session.basketVip) });
  }

  if (req.method === "POST" && url.pathname === "/vip/basket/remove") {
    const index = Number(params?.index);
    if (!Number.isInteger(index) || index < 0 || index >= (session.basketVip || []).length) {
      return sendJSON(res, headers, 400, { error: "Invalid index" });
    }
    session.basketVip.splice(index, 1);
    const items = session.basketVip.map(x => ({ ...x }));
    return sendJSON(res, headers, 200, { ok: true, items, totalSats: basketTotal(session.basketVip) });
  }

  if (req.method === "POST" && url.pathname === "/checkout-vip") {
    const total = basketTotal(session.basketVip);
    if (total < 0) return sendJSON(res, headers, 400, { error: "Invalid total" });
    if (!(session.balanceSats < total)) {
      const containsFlag = (session.basketVip || []).some(it => it.sku === "FLAG");
      session.balanceSats -= total;
      session.basketVip = [];
      if (containsFlag) {
        const flag = "alfa{XXXXXXXXXXXXXXXXXXXXXXXXXX}";

        return sendJSON(res, headers, 200, {
          ok: true,
          newBalanceSats: session.balanceSats,
          flag
        });
      }
      return sendJSON(res, headers, 200, { ok: true, newBalanceSats: session.balanceSats });
    }
    return sendJSON(res, headers, 400, { error: "Insufficient balance" });
  }


  return sendJSON(res, headers, 404, { error: "Not found" });
}


function getCookie(req, name) {
  const raw = req.headers.cookie || '';
  for (const part of raw.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return v.join('=');
  }
  return '';
}

async function readParams(req, url) {
  if (req.method === "GET") {
    return Object.fromEntries(url.searchParams.entries());
  }

  return await new Promise(resolve => {
    let body = "";
    req.on("data", chunk => { body += chunk; if (body.length > 1e6) req.destroy(); });
    req.on("end", () => {
      const out = {};
      (body || "").split("&").forEach(pair => {
        if (!pair) return;
        const [k, v = ""] = pair.split("=");
        out[decodeURIComponent(k)] = decodeURIComponent(v.replace(/\+/g, " "));
      });
      resolve(out);
    });
  });
}

function sendJSON(res, headers, code, obj) {
  const replacer = (k, v) => {
    if (typeof v === "bigint") return v.toString();
    if (typeof v === "number" && !Number.isFinite(v)) return String(v);
    return v;
  };
  let payload;
  try {
    payload = JSON.stringify(obj, replacer);
  } catch {
    payload = JSON.stringify({ error: "Internal serialization error" });
    code = 500;
  }
  res.writeHead(code, { ...headers, "Content-Type": "application/json; charset=utf-8" });
  res.end(payload);
}
