from fastapi import APIRouter

from .config import STREAM_STARTED_AT

router = APIRouter()


@router.get("/health")
async def health() -> dict:
    return {"status": "ok"}


@router.get("/config")
async def public_config() -> dict:
    return {"auth_provider": "shakalauth"}


@router.get("/status")
async def status_public() -> dict:
    return {"started_at": STREAM_STARTED_AT} 