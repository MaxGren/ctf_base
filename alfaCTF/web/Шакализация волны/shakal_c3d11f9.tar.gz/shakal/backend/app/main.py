import os
import io
import time
import hmac
import hashlib
from typing import AsyncGenerator, Optional, Dict, Any

from fastapi import FastAPI
from fastapi.responses import JSONResponse, RedirectResponse, StreamingResponse
from starlette.middleware.sessions import SessionMiddleware
from pydantic import BaseModel
from PIL import Image, ImageDraw
import numpy as np
import httpx
import base64
import json

from .config import APP_NAME, SECRET_KEY, API_PREFIX
from . import common_routes, auth_routes, reactions, admin_routes, stream_routes, support_routes
from .db import init_db
from .models import DEFAULT_REACTIONS, ReactionModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from .db import get_session

app = FastAPI(title=APP_NAME)
app.add_middleware(
    SessionMiddleware,
    secret_key=SECRET_KEY,
    same_site="None",
    https_only=True,
    session_cookie="shakaltv_session",
)

app.include_router(common_routes.router, prefix=API_PREFIX)
app.include_router(auth_routes.router, prefix=API_PREFIX)
app.include_router(reactions.router, prefix=API_PREFIX)
app.include_router(admin_routes.router, prefix=API_PREFIX)
app.include_router(stream_routes.router, prefix=API_PREFIX)
app.include_router(support_routes.router, prefix=API_PREFIX)


@app.on_event("startup")
async def on_startup():
    await init_db()
    from .db import SessionLocal
    async with SessionLocal() as session:
        existing = await session.execute(select(ReactionModel))
        rows = existing.scalars().all()
        if not rows:
            for r in DEFAULT_REACTIONS:
                session.add(ReactionModel(**r))
            await session.commit() 