APP_NAME = "ШакалТВ"
API_PREFIX = "/api"

import os
import time

SECRET_KEY = os.getenv("SECRET_KEY", "dev_secret_key_change_me")

MAIN_DOMAIN = (os.getenv("MAIN_DOMAIN") or os.getenv("COOKIE_DOMAIN", ".aflactf.ru").lstrip(".")).strip()
if MAIN_DOMAIN.startswith("."):
    MAIN_DOMAIN = MAIN_DOMAIN.lstrip(".")

COOKIE_DOMAIN = os.getenv("COOKIE_DOMAIN", f".{MAIN_DOMAIN}")

AUTH_CLIENT_ID = os.getenv("AUTH_CLIENT_ID", "shakaltv")
AUTH_BASE_URL_INTERNAL = os.getenv("AUTH_BASE_URL_INTERNAL", "http://shakalauth:8081")
AUTH_AUTHORIZE_PATH = "/oauth/authorize"
AUTH_TOKEN_PATH = "/oauth/token"
AUTH_PROVIDER_NAME = "ШакалАутх"

STREAM_STARTED_AT = int(time.time()) 