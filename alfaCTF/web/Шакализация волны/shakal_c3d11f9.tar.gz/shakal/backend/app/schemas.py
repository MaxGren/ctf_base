from typing import Optional

from fastapi import Request
from pydantic import BaseModel


class User(BaseModel):
    name: str
    email: str | None = None
    picture: Optional[str] = None
    username: Optional[str] = None
    auth_user_id: Optional[int] = None


def get_current_user(request: Request) -> Optional["User"]:
    stored = request.session.get("user")
    if not stored:
        return None
    return User(**stored) 