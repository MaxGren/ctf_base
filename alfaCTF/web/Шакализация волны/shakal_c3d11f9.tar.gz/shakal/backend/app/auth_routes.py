import base64
import hmac
import hashlib
import json
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, Request, status
from fastapi.responses import JSONResponse, RedirectResponse

from .config import (
    SECRET_KEY,
    AUTH_BASE_URL_INTERNAL,
    AUTH_TOKEN_PATH,
    AUTH_CLIENT_ID,
)
from .schemas import User, get_current_user
from .db import get_session
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, insert, update
from .models import UserModel

router = APIRouter()


def _urlsafe_b64encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")


def _urlsafe_b64decode(data_str: str) -> bytes:
    padding = '=' * ((4 - len(data_str) % 4) % 4)
    return base64.urlsafe_b64decode(data_str + padding)


def _sign_state_payload(payload: dict) -> str:
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    b64 = _urlsafe_b64encode(body)
    sig = hmac.new(SECRET_KEY.encode("utf-8"), b64.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{b64}.{sig}"


def _verify_state_token(token: str, max_age_seconds: int = 600) -> tuple[bool, Optional[dict]]:
    import time

    try:
        parts = token.split(".", 2)
        if len(parts) != 2:
            return False, None
        b64, sig = parts
        expected_sig = hmac.new(SECRET_KEY.encode("utf-8"), b64.encode("utf-8"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected_sig):
            return False, None
        payload = json.loads(_urlsafe_b64decode(b64))
        issued_at = int(payload.get("t", 0))
        if issued_at <= 0 or (int(time.time()) - issued_at) > max_age_seconds:
            return False, None
        return True, payload
    except Exception:
        return False, None


@router.get("/auth/login")
async def auth_login(request: Request):
    import time

    host_header = request.headers.get("host", "localhost")
    xf_proto = (request.headers.get("x-forwarded-proto") or "").lower()
    scheme = "https" if xf_proto == "https" else "http"

    next_param = request.query_params.get("next")

    try:
        parsed_next = str(next_param) if next_param else None
        if parsed_next and parsed_next.startswith("http"):
            redirect_scheme = parsed_next.split("://", 1)[0]
            redirect_host = parsed_next.split("://", 1)[1].split("/", 1)[0]
            print(redirect_scheme, redirect_host, flush=True)
        else:
            redirect_scheme = scheme
            redirect_host = host_header
    except Exception:
        redirect_scheme = scheme
        redirect_host = host_header

    redirect_uri = f"{redirect_scheme}://{redirect_host}/api/auth/callback"

    import secrets

    nonce = secrets.token_urlsafe(16)
    state_payload = {"n": nonce, "t": int(time.time())}
    if next_param:
        state_payload["next"] = str(next_param)
    state = _sign_state_payload(state_payload)

    incoming_host = request.headers.get("x-forwarded-host") or request.headers.get("host") or "localhost"
    host_part, _, port_part = incoming_host.partition(":")
    if host_part.startswith("tv-"):
        derived_auth_host = "auth-" + host_part[len("tv-"):]
    else:
        derived_auth_host = (
            "auth." + host_part[len("tv."):] if host_part.startswith("tv.") else host_part
        )
    auth_origin = f"{scheme}://{derived_auth_host}" + (f":{port_part}" if port_part else "")

    authorize_url = (
        f"{auth_origin}/oauth/authorize?client_id={AUTH_CLIENT_ID}"
        f"&redirect_uri={httpx.QueryParams({'redirect_uri': redirect_uri})['redirect_uri']}"
        f"&response_type=code&scope=basic&state={httpx.QueryParams({'state': state})['state']}"
    )
    if next_param:
        authorize_url += f"&next={httpx.QueryParams({'next': next_param})['next']}"
    return RedirectResponse(url=authorize_url, status_code=status.HTTP_302_FOUND)


@router.get("/auth/callback")
async def auth_callback(request: Request, session: AsyncSession = Depends(get_session)):
    import time

    params = dict(request.query_params)
    code = params.get("code")
    state = params.get("state")
    print(request.session, flush=True)
    ok, state_payload = _verify_state_token(state or "")
    if not code or not state or not ok:
        return JSONResponse({"error": "invalid_oauth_state"}, status_code=status.HTTP_400_BAD_REQUEST)

    host_header = request.headers.get("host", "localhost")
    xf_proto = (request.headers.get("x-forwarded-proto") or "").lower()
    scheme = "https" if xf_proto == "https" else "http"
    redirect_uri = f"{scheme}://{host_header}/api/auth/callback"

    token_url = f"{AUTH_BASE_URL_INTERNAL}{AUTH_TOKEN_PATH}"
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(token_url, data={
                "grant_type": "authorization_code",
                "client_id": AUTH_CLIENT_ID,
                "code": code,
                "redirect_uri": redirect_uri,
            })
            if resp.status_code != 200:
                return JSONResponse({"error": "oauth_token_error", "detail": resp.text}, status_code=status.HTTP_400_BAD_REQUEST)
            token_data = resp.json()
    except Exception as exc:
        return JSONResponse({"error": "oauth_exchange_failed", "detail": str(exc)}, status_code=status.HTTP_502_BAD_GATEWAY)

    user_info = token_data.get("user") or {}

    auth_user_id = user_info.get("id")
    username = user_info.get("username")
    name = user_info.get("name") or user_info.get("username") or "User"
    email = user_info.get("email")
    picture = user_info.get("picture")

    existing = None
    if auth_user_id is not None:
        result = await session.execute(select(UserModel).where(UserModel.auth_user_id == auth_user_id))
        existing = result.scalar_one_or_none()

    if existing:
        await session.execute(
            update(UserModel)
            .where(UserModel.id == existing.id)
            .values(username=username, name=name, email=email, picture=picture)
        )
    else:
        await session.execute(
            insert(UserModel).values(
                auth_user_id=auth_user_id,
                username=username,
                name=name,
                email=email,
                picture=picture,
            )
        )
    await session.commit()

    request.session["user"] = {
        "name": name,
        "email": email,
        "picture": picture,
        "username": username,
        "auth_user_id": auth_user_id,
    }

    next_value = None
    if state_payload and isinstance(state_payload, dict):
        next_value = state_payload.get("next")
    if next_value and isinstance(next_value, str):
        try:
            if "://" in next_value:
                after_scheme = next_value.split("://", 1)[1]
                host_part = after_scheme.split("/", 1)[0]
                print(host_part, request.url.hostname, flush=True)
                if host_part == request.url.hostname:
                    print("Redirecting to", next_value, flush=True)
                    return RedirectResponse(url=next_value)
            elif next_value.startswith("/"):
                return RedirectResponse(url=next_value)
        except Exception:
            pass

    return RedirectResponse(url="/")


@router.post("/logout")
async def logout(request: Request):
    request.session.clear()
    return JSONResponse({"ok": True})


@router.get("/user")
async def me(user: Optional[User] = Depends(get_current_user)):
    if not user:
        return JSONResponse({"error": "unauthorized"}, status_code=status.HTTP_401_UNAUTHORIZED)
    return user.model_dump() 