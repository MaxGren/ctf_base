from __future__ import annotations

from sqlalchemy import BigInteger, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from . import Base


class UserModel(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    auth_user_id: Mapped[int | None] = mapped_column(BigInteger, unique=True, nullable=True)
    username: Mapped[str | None] = mapped_column(String(255))
    name: Mapped[str] = mapped_column(String(255))
    email: Mapped[str | None] = mapped_column(String(255))
    picture: Mapped[str | None] = mapped_column(String(1024))


class ReactionModel(Base):
    __tablename__ = "reactions"
    __table_args__ = (UniqueConstraint("key", name="uq_reaction_key"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    key: Mapped[str] = mapped_column(String(64))
    emoji: Mapped[str] = mapped_column(String(16))
    label: Mapped[str] = mapped_column(String(64))
    n: Mapped[int] = mapped_column(Integer, default=0)


DEFAULT_REACTIONS: list[dict[str, str | int]] = [
    {"key": "fire", "emoji": "🔥", "label": "Огонь", "n": 12},
    {"key": "lol", "emoji": "😂", "label": "Смешно", "n": 7},
    {"key": "wow", "emoji": "😮", "label": "Вау", "n": 5},
    {"key": "heart", "emoji": "❤️", "label": "Лайк", "n": 20},
] 