from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse

from .config import APP_NAME, STREAM_STARTED_AT
from .schemas import User, get_current_user
from .db import get_session
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from .models import ReactionModel

import os

router = APIRouter()


@router.get("/admin/status")
async def admin_status(user: Optional[User] = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    if not user or user.username != "admin":
        return JSONResponse({"error": "forbidden"}, status_code=403)
    order = ["fire", "lol", "wow", "heart"]
    result = await session.execute(select(ReactionModel).where(ReactionModel.key.in_(order)))
    items = {r.key: r for r in result.scalars().all()}
    reactions = []
    for k in order:
        r = items.get(k)
        if r:
            reactions.append({"id": r.key, "emoji": r.emoji, "label": r.label, "n": r.n})
    return {
        "app": APP_NAME,
        "started_at": STREAM_STARTED_AT,
        "quality": "shakal",
        "reactions": reactions,
    }


@router.post("/admin/reactions/reset")
async def admin_reset_reactions(user: Optional[User] = Depends(get_current_user), session: AsyncSession = Depends(get_session)):
    if not user or user.username != "admin":
        return JSONResponse({"error": "forbidden"}, status_code=403)
    order = ["fire", "lol", "wow", "heart"]
    await session.execute(update(ReactionModel).where(ReactionModel.key.in_(order)).values(n=0))
    await session.commit()
    result = await session.execute(select(ReactionModel).where(ReactionModel.key.in_(order)))
    items = {r.key: r for r in result.scalars().all()}
    reactions = []
    for k in order:
        r = items.get(k)
        if r:
            reactions.append({"id": r.key, "emoji": r.emoji, "label": r.label, "n": r.n})
    return {"ok": True, "reactions": reactions}


@router.post("/admin/quality")
async def admin_set_quality(request: Request, user: Optional[User] = Depends(get_current_user)):
    if not user or user.username != "admin":
        return JSONResponse({"error": "forbidden"}, status_code=403)
    try:
        payload = await request.json()
    except Exception:
        payload = {}
    desired = str(payload.get("quality") or "").lower()
    if desired not in {"shakal", "4k"}:
        return JSONResponse({"error": "invalid_quality"}, status_code=400)
    response: Dict[str, Any] = {"ok": True, "quality": desired}
    if desired == "4k":
        FLAG = os.getenv("FLAG", "alfa{**REDACTED**}")
        response["message"] = f"Вот флаг: {FLAG}"
    return JSONResponse(response) 
