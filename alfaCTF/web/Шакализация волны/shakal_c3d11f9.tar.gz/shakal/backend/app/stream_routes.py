import io
import os
import time
from typing import AsyncGenerator, Optional

import numpy as np
from PIL import Image, ImageDraw
from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse, StreamingResponse

from .schemas import User, get_current_user
from .config import APP_NAME

router = APIRouter()

BOUNDARY = "frame"

FRAME_WIDTH = int(os.getenv("STREAM_WIDTH", "320"))
FRAME_HEIGHT = int(os.getenv("STREAM_HEIGHT", "180"))
JPEG_QUALITY = int(os.getenv("STREAM_JPEG_QUALITY", "10"))
TARGET_FPS = float(os.getenv("STREAM_FPS", "2.0"))
DRAW_OVERLAY = os.getenv("STREAM_DRAW_OVERLAY", "0") == "1"

_OVERLAY_IMG = None
if DRAW_OVERLAY:
    _OVERLAY_IMG = Image.new("RGBA", (FRAME_WIDTH, 30), (0, 0, 0, 100))


def generate_frame(counter: int) -> bytes:
    width, height = FRAME_WIDTH, FRAME_HEIGHT
    noise = np.random.randint(0, 255, (height, width, 3), dtype=np.uint8)
    img = Image.fromarray(noise, mode="RGB")

    if DRAW_OVERLAY:
        draw = ImageDraw.Draw(img)
        if _OVERLAY_IMG is not None:
            img.paste(_OVERLAY_IMG, (0, 0), _OVERLAY_IMG)
        text_color = (255, 255, 0)
        small = (200, 200, 200)
        timestamp = time.strftime("%H:%M:%S")
        label = f"{APP_NAME} — live #{counter}"
        draw.text((8, 6), label, fill=text_color)
        draw.text((8, 16), f"{timestamp}", fill=small)

    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=JPEG_QUALITY, subsampling=2, optimize=False)
    return buf.getvalue()


async def mjpeg_generator() -> AsyncGenerator[bytes, None]:
    i = 0
    frame_interval = 1.0 / TARGET_FPS if TARGET_FPS > 0 else 0.5
    last_time = time.perf_counter()
    while True:
        i += 1
        frame = generate_frame(i)
        yield (
            b"--" + BOUNDARY.encode() + b"\r\n"
            + b"Content-Type: image/jpeg\r\n"
            + f"Content-Length: {len(frame)}\r\n\r\n".encode()
            + frame
            + b"\r\n"
        )
        now = time.perf_counter()
        elapsed = now - last_time
        sleep_for = frame_interval - elapsed
        if sleep_for < 0:
            sleep_for = 0
        await _sleep(sleep_for)
        last_time = time.perf_counter()


async def _sleep(seconds: float):
    import asyncio

    await asyncio.sleep(seconds)


@router.get("/stream")
async def stream(user: Optional[User] = Depends(get_current_user)):
    if not user:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    headers = {"Cache-Control": "no-cache", "Pragma": "no-cache"}
    return StreamingResponse(
        mjpeg_generator(),
        media_type=f"multipart/x-mixed-replace; boundary={BOUNDARY}",
        headers=headers,
    ) 