from typing import Any, Dict, Optional

from asyncio import Lock
from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

from .schemas import User, get_current_user
from .db import get_session
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from .models import ReactionModel

router = APIRouter()

REACTION_LOCK = Lock()


@router.get("/reactions")
async def get_reactions(session: AsyncSession = Depends(get_session)):
    order = ["fire", "lol", "wow", "heart"]
    result = await session.execute(select(ReactionModel).where(ReactionModel.key.in_(order)))
    items = {r.key: r for r in result.scalars().all()}
    resp = []
    for k in order:
        r = items.get(k)
        if r:
            resp.append({"id": r.key, "emoji": r.emoji, "label": r.label, "n": r.n})
    return resp


@router.post("/reactions/{rid}/bump")
async def bump_reaction(
    rid: str,
    user: Optional[User] = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
):
    if not user:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    async with REACTION_LOCK:
        stmt = (
            update(ReactionModel)
            .where(ReactionModel.key == rid)
            .values(n=ReactionModel.n + 1)
            .returning(ReactionModel)
        )
        result = await session.execute(stmt)
        updated = result.fetchone()
        if not updated:
            return JSONResponse({"error": "unknown_reaction"}, status_code=400)
        await session.commit()

        order = ["fire", "lol", "wow", "heart"]
        result2 = await session.execute(select(ReactionModel).where(ReactionModel.key.in_(order)))
        items2 = {r.key: r for r in result2.scalars().all()}
        resp = []
        for k in order:
            r = items2.get(k)
            if r:
                resp.append({"id": r.key, "emoji": r.emoji, "label": r.label, "n": r.n})
        return {"ok": True, "reactions": resp} 