import os
import re

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

try:
    import redis as _redis
except Exception:
    _redis = None

router = APIRouter()

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")


@router.post("/support/message")
async def support_message(request: Request):
    try:
        payload = await request.json()
    except Exception:
        payload = {}
    text = str(payload.get("text") or "").strip()
    if not text:
        return JSONResponse({"ok": False, "error": "empty"}, status_code=400)
    urls = re.findall(r"https?://\S+", text)
    n_queued = 0
    if urls and _redis is not None:
        try:
            r = _redis.StrictRedis.from_url(REDIS_URL, decode_responses=True)
            for u in urls:
                r.rpush("bot.visit_url", u)
                n_queued += 1
        except Exception:
            pass
    return {"ok": True, "queued": n_queued} 