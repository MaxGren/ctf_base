import React, { useMemo, useRef, useState, useEffect } from 'react'

function AgentAvatar() {
  return (
    <div className="avatar" title="Шакал">
      <img src="https://sun9-71.userapi.com/s/v1/ig2/A4pkd7eqRuQzWGONq1i5Hk69YWi8lQGHLpZOU5G3qaSYSJJ9bwUHlKo1okGP1n47am7lT16YqytXdZR_rfcASfke.jpg?quality=95&as=32x37,48x56,72x83,108x125,160x185,240x278,360x417,480x556,540x626,640x742,720x834,932x1080&from=bu&cs=932x0" alt="Шакал" />
    </div>
  )
}

export default function ChatWidget() {
  const [open, setOpen] = useState(false)
  const [text, setText] = useState('')
  const [messages, setMessages] = useState(() => [
    { id: 1, from: 'agent', text: 'Привет! Я Шакал 🐺 Поддержка на связи.' }
  ])
  const listRef = useRef(null)

  const send = async () => {
    const t = text.trim()
    if (!t) return
    setMessages((m) => [...m, { id: Date.now(), from: 'you', text: t }])
    setText('')
    try {
      const res = await fetch('/api/support/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ text: t })
      })
      const data = await res.json().catch(() => ({}))
      if (res.ok) {
        const queued = data?.queued ?? 0
        setMessages((m) => [...m, { id: Date.now() + 1, from: 'agent', text: queued > 0 ? '✅ Принято в обработку' : '✔️ Сообщение доставлено' }])
      } else {
        setMessages((m) => [...m, { id: Date.now() + 1, from: 'agent', text: '⚠️ Ошибка отправки' }])
      }
    } catch (e) {
      setMessages((m) => [...m, { id: Date.now() + 1, from: 'agent', text: '⚠️ Сеть недоступна' }])
    }
  }

  useEffect(() => {
    if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight
  }, [messages])

  return (
    <>
      <button className="chat-toggle" onClick={() => setOpen((v) => !v)} title="Чат с поддержкой">💬</button>
      {open && (
        <div className="chat-panel">
          <div className="chat-header">
            <AgentAvatar />
            <div>
              <div className="chat-title">Шакал · Поддержка</div>
              <div style={{ fontSize: 12, color: '#9ca3af' }}>Онлайн</div>
            </div>
          </div>
          <div className="msgs" ref={listRef}>
            {messages.map((m) => (
              <div key={m.id} className={"msg " + (m.from === 'you' ? 'you' : 'agent')}>
                {m.from !== 'you' && <AgentAvatar />}
                <div className="bubble">{m.text}</div>
              </div>
            ))}
          </div>
          <div className="chat-input">
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Напишите сообщение..."
              onKeyDown={(e) => { if (e.key === 'Enter') send() }}
            />
            <button onClick={send}>Отправить</button>
          </div>
        </div>
      )}
    </>
  )
} 