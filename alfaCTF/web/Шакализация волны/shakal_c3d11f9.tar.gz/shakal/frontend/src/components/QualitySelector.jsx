import React from 'react'

export default function QualitySelector() {
  return (
    <div className="controls">
      <label className="control">
        <span className="control-label">Качество</span>
        <select className="control-select" disabled title="Недоступно: только шакальное качество">
          <option value="shakal">Шакальное</option>
        </select>
      </label>
    </div>
  )
} 