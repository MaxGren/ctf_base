import React, { useEffect, useMemo, useState } from 'react'

function Badge({ children, tone = 'default' }) {
  return (
    <span className={`badge ${tone}`}>{children}</span>
  )
}

export default function StatsBar() {
  const [startedAt, setStartedAt] = useState(null)
  const [tick, setTick] = useState(0)
  const [viewers, setViewers] = useState(() => 137)

  useEffect(() => {
    fetch('/api/status', { credentials: 'include' })
      .then((r) => r.ok ? r.json() : { started_at: null })
      .then((d) => setStartedAt(d.started_at ?? null))
      .catch(() => setStartedAt(null))
  }, [])

  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 1000)
    const v = setInterval(() => setViewers((v) => Math.max(42, v + (Math.random() > 0.5 ? 1 : -1))), 3000)
    return () => { clearInterval(id); clearInterval(v) }
  }, [])

  const uptime = useMemo(() => {
    if (!startedAt) return '00:00:00'
    const secs = Math.max(0, Math.floor(Date.now() / 1000 - startedAt))
    const h = Math.floor(secs / 3600).toString().padStart(2, '0')
    const m = Math.floor((secs % 3600) / 60).toString().padStart(2, '0')
    const s = Math.floor(secs % 60).toString().padStart(2, '0')
    return `${h}:${m}:${s}`
  }, [tick, startedAt])

  return (
    <div className="card stats">
      <div className="stat">
        <div className="label">Зрители</div>
        <div className="value">{viewers}</div>
      </div>
      <div className="stat">
        <div className="label">Эфир</div>
        <div className="value">{uptime}</div>
      </div>
      <div className="stat">
        <div className="label">Качество</div>
        <div className="value"><Badge tone="warn">Шакальное</Badge></div>
      </div>
      <div className="stat">
        <div className="label">Битрейт</div>
        <div className="value"><Badge>~128 kbps</Badge></div>
      </div>
    </div>
  )
} 