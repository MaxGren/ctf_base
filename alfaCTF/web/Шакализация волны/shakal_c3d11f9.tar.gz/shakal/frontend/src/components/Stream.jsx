import React from 'react'
import QualitySelector from './QualitySelector'

export default function Stream({ isAuthenticated }) {
  if (!isAuthenticated) {
    return (
      <div className="card stream-holder">
        <div style={{ padding: 20, textAlign: 'center' }}>
          <h3>Трансляция доступна после входа</h3>
          <p className="muted">Пожалуйста, войдите через ШакалАутх, чтобы смотреть эфир</p>
        </div>
      </div>
    )
  }

  return (
    <div className="card stream-holder">
      <div className="stream-bar">
        <div className="stream-title">Прямая трансляция</div>
        <QualitySelector />
      </div>
      <div className="stream">
        <img src="/api/stream" alt="ШакалТВ — прямая трансляция" />
      </div>
    </div>
  )
} 