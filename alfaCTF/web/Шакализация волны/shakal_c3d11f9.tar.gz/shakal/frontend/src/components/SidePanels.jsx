import React from 'react'

function Panel({ title, children }) {
  return (
    <div className="card panel">
      <div className="panel-title">{title}</div>
      <div className="panel-body">{children}</div>
    </div>
  )
}

export default function SidePanels() {
  return (
    <div className="side-stack">
      <Panel title="Расписание">
        <ul className="list">
          <li><b>Каждый день</b>: 20:00 — Ночной шакалинг</li>
          <li><b>Пн/Ср/Пт</b>: 18:00 — Мем-обзор</li>
          <li><b>Сб</b>: 16:00 — Ретро-игры</li>
        </ul>
      </Panel>
      <Panel title="Новости">
        <ul className="list bullets">
          <li>Добавили вход через Telegram</li>
          <li>Появились реакции под эфиром</li>
          <li>Пофиксили баг с тёмной темой на мобильных</li>
        </ul>
      </Panel>
      <Panel title="О проекте">
        <p>ШакалТВ — ламповый эфир с атмосферой начала 2000-х.</p>
        <p>Есть вопрос? Откройте чатик поддержки внизу справа и напишите Шакалу.</p>
      </Panel>
    </div>
  )
} 
