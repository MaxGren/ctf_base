import React from 'react'

const MESSAGES = [
  'Шакал: не переключайтесь! 🐺',
  'Поддержите наш эфир! 🙂',
  'Сегодня в программе: ретро-игры, мемы и лоу-фай вайбы',
  'Качество шакальное, атмосфера топ!'
]

function Group() {
  return (
    <div className="ticker-group">
      {MESSAGES.map((m, i) => (
        <span key={i}>📢 {m}</span>
      ))}
    </div>
  )
}

export default function Ticker() {
  return (
    <div className="ticker" role="marquee" aria-label="Новости эфира">
      <div className="ticker-row">
        <Group />
        <Group aria-hidden="true" />
      </div>
    </div>
  )
} 
