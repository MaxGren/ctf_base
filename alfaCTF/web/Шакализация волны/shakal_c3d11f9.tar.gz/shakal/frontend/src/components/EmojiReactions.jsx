import React, { useEffect, useState } from 'react'

export default function EmojiReactions() {
  const [items, setItems] = useState([])

  useEffect(() => {
    fetch('/api/reactions', { credentials: 'include' })
      .then((r) => r.ok ? r.json() : [])
      .then((data) => setItems(Array.isArray(data) ? data : []))
      .catch(() => setItems([]))
  }, [])

  const bump = async (id) => {
    try {
      const res = await fetch(`/api/reactions/${id}/bump`, { method: 'POST', credentials: 'include' })
      if (res.ok) {
        const data = await res.json()
        if (data && Array.isArray(data.reactions)) setItems(data.reactions)
        return
      }
    } catch (e) {}
    setItems((arr) => arr.map((x) => x.id === id ? { ...x, n: x.n + 1 } : x))
  }

  if (!items.length) return null

  return (
    <div className="reactions">
      {items.map((x) => (
        <button key={x.id} className="reaction" onClick={() => bump(x.id)} title={x.label}>
          <span className="emo">{x.emoji}</span>
          <span className="cnt">{x.n}</span>
        </button>
      ))}
    </div>
  )
} 