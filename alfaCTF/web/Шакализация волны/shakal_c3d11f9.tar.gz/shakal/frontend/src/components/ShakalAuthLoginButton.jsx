import React from 'react'

export default function ShakalAuthLoginButton() {
  const onClick = () => {
    const next = encodeURIComponent(window.location.href)
    window.location.href = `/api/auth/login?next=${next}`
  }

  return (
    <button className="button primary" onClick={onClick}>
      Войти через ШакалАутх
    </button>
  )
} 