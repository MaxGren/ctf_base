import React, { useEffect, useState } from 'react'
import { fetchAdminStatus, resetReactions, setQuality } from '../api'

function formatUptime(startedAt) {
  if (!startedAt) return '-'
  const secs = Math.max(0, Math.floor(Date.now() / 1000 - startedAt))
  const d = Math.floor(secs / 86400)
  const h = Math.floor((secs % 86400) / 3600)
  const m = Math.floor((secs % 3600) / 60)
  const s = secs % 60
  return [
    d ? `${d}д` : null,
    h ? `${h}ч` : null,
    m ? `${m}м` : null,
    `${s}с`
  ].filter(Boolean).join(' ')
}

export default function AdminPanel() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [status, setStatus] = useState(null)
  const [resetLoading, setResetLoading] = useState(false)
  const [quality, setQualityState] = useState('shakal')
  const [qualityBusy, setQualityBusy] = useState(false)
  const [qualityMessage, setQualityMessage] = useState('')

  const load = async () => {
    setLoading(true)
    setError('')
    try {
      const data = await fetchAdminStatus()
      if (!data) {
        setError('Нет доступа')
      } else {
        setStatus(data)
        if (data.quality) setQualityState(data.quality)
      }
    } catch (e) {
      setError('Ошибка загрузки')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const onReset = async () => {
    setResetLoading(true)
    setError('')
    try {
      await resetReactions()
      await load()
    } catch (e) {
      setError('Не удалось сбросить реакции')
    } finally {
      setResetLoading(false)
    }
  }

  const onApplyQuality = async () => {
    setQualityBusy(true)
    setQualityMessage('')
    setError('')
    try {
      const res = await setQuality(quality)
      await load()
      if (res && res.message) setQualityMessage(res.message)
    } catch (e) {
      setError('Не удалось применить качество')
    } finally {
      setQualityBusy(false)
    }
  }

  const totalReactions = status?.reactions?.reduce((sum, r) => sum + (r.n || 0), 0) || 0

  return (
    <div className="card" style={{ marginTop: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h3 style={{ margin: 0 }}>Админ панель</h3>
        <a href="#/" className="button secondary">На главную</a>
      </div>

      {loading && <p className="muted">Загрузка...</p>}
      {error && <p className="muted" style={{ color: 'var(--danger, #b00)' }}>{error}</p>}

      {status && (
        <div className="admin-grid" style={{ marginTop: 12 }}>
          <div>
            <div className="section">
              <div className="section-title"><span className="icon">📊</span> Сводка</div>
              <div className="admin-kpis">
                <div className="kpi">
                  <div className="kpi-label">Приложение</div>
                  <div className="kpi-value">{status.app}</div>
                </div>
                <div className="kpi">
                  <div className="kpi-label">Аптайм</div>
                  <div className="kpi-value">{formatUptime(status.started_at)}</div>
                </div>
                <div className="kpi">
                  <div className="kpi-label">Реакций всего</div>
                  <div className="kpi-value">{totalReactions}</div>
                </div>
              </div>
            </div>

            <div className="section">
              <div className="section-title"><span className="icon">🎛️</span> Качество трансляции</div>
              <div className="toolbar" style={{ marginBottom: 8 }}>
                <label className="control">
                  <span className="control-label">Качество</span>
                  <select className="control-select" value={quality} onChange={e => setQualityState(e.target.value)}>
                    <option value="shakal">Шакальное</option>
                    <option value="4k">4К</option>
                  </select>
                </label>
                <button className="button" onClick={onApplyQuality} disabled={qualityBusy}>
                  {qualityBusy ? 'Применение...' : 'Применить'}
                </button>
                <span className="badge">Текущее: {status.quality}</span>
              </div>
              {qualityMessage && (
                <div className="callout">{qualityMessage}</div>
              )}
            </div>

            <div className="section">
              <div className="section-title"><span className="icon">🔥</span> Реакции</div>
              <div className="toolbar" style={{ marginBottom: 6 }}>
                <button className="button ghost" onClick={onReset} disabled={resetLoading}>
                  {resetLoading ? 'Сброс...' : 'Сбросить счетчики'}
                </button>
                <span className="muted">Всего: {totalReactions}</span>
              </div>
              <table className="table">
                <thead>
                  <tr>
                    <th>Эмо</th>
                    <th>ID</th>
                    <th>Название</th>
                    <th>Счетчик</th>
                  </tr>
                </thead>
                <tbody>
                  {status.reactions.map(r => (
                    <tr key={r.id}>
                      <td style={{ width: 60 }}>{r.emoji}</td>
                      <td style={{ width: 120 }}>{r.id}</td>
                      <td>{r.label}</td>
                      <td style={{ width: 120, fontWeight: 800 }}>{r.n}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <div className="section">
              <div className="section-title"><span className="icon">ℹ️</span> Справка</div>
              <p className="muted" style={{ marginTop: 0 }}>
                Здесь вы можете управлять параметрами эфира и отслеживать показатели в реальном времени.
              </p>
              <ul className="list bullets">
                <li>Рекомендуется держать Качество трансляции на <b>шакальном</b></li>
                <li>Сброс счетчиков мгновенный и необратимый</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  )
} 