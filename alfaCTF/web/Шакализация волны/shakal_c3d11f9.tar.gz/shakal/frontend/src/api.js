export async function fetchUser() {
  const res = await fetch('/api/user', { credentials: 'include' })
  if (!res.ok) return null
  return await res.json()
}

export async function logout() {
  await fetch('/api/logout', { method: 'POST', credentials: 'include' })
}

export async function fetchConfig() {
  const res = await fetch('/api/config', { credentials: 'include' })
  if (!res.ok) return {}
  return await res.json()
}

export async function fetchAdminStatus() {
  const res = await fetch('/api/admin/status', { credentials: 'include' })
  if (!res.ok) return null
  return await res.json()
}

export async function resetReactions() {
  const res = await fetch('/api/admin/reactions/reset', { method: 'POST', credentials: 'include' })
  if (!res.ok) throw new Error('reset failed')
  return await res.json()
}

export async function setQuality(quality) {
  const res = await fetch('/api/admin/quality', {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ quality }),
  })
  if (!res.ok) throw new Error('set quality failed')
  return await res.json()
} 