import React, { useEffect, useState } from 'react'
import Stream from './components/Stream'
import ChatWidget from './components/ChatWidget'
import { fetchUser, logout, fetchConfig } from './api'
import ShakalAuthLoginButton from './components/ShakalAuthLoginButton'
import Ticker from './components/Ticker'
import StatsBar from './components/StatsBar'
import EmojiReactions from './components/EmojiReactions'
import SidePanels from './components/SidePanels'
import AdminPanel from './components/AdminPanel'

export default function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [config, setConfig] = useState({})
  const [route, setRoute] = useState(window.location.hash || '#/')

  useEffect(() => {
    fetchUser().then((u) => { setUser(u); setLoading(false) })
    fetchConfig().then((c) => setConfig(c))
  }, [])

  useEffect(() => {
    const onHashChange = () => setRoute(window.location.hash || '#/')
    window.addEventListener('hashchange', onHashChange)
    return () => window.removeEventListener('hashchange', onHashChange)
  }, [])

  const onLogout = async () => {
    await logout()
    setUser(null)
    window.location.replace('/')
  }

  const isAdmin = !!user && user.username === 'admin'
  const showingAdmin = route === '#/admin'

  return (
    <>
      <header className="header">
        <a href="/" className="brand" style={{ textDecoration: 'none', color: 'inherit' }}>
          <div className="logo"><span>Ш</span></div>
          <div>ШакалТВ</div>
        </a>
        <div className="auth">
          {loading ? (
            <span className="muted">Загрузка...</span>
          ) : user ? (
            <>
              {isAdmin && (
                <a href="#/admin" className="button" style={{ marginRight: 8 }}>Админ панель</a>
              )}
              <div className="avatar">
                {user.picture ? <img src={user.picture} alt={user.name} /> : <span>🦊</span>}
              </div>
              <span>{user.name}</span>
              <button className="button secondary" onClick={onLogout}>Выйти</button>
            </>
          ) : (
            <ShakalAuthLoginButton />
          )}
        </div>
      </header>

      {showingAdmin && isAdmin ? (
        <main className="container">
          <AdminPanel />
        </main>
      ) : (
        <>
          <Ticker />

          <main className="container">
            <StatsBar />
            <div className="layout">
              <div className="col-main">
                <Stream isAuthenticated={!!user} />
                <EmojiReactions />
                <div className="card" style={{ marginTop: 16 }}>
                  <h3 style={{ marginTop: 0 }}>Описание эфира</h3>
                  <p className="muted">Смотрите наш уникальный лоу-фай эфир. Шум, зерно, и немного магии. Качество — шакальное, и поэтому душевное.</p>
                </div>
              </div>
              <aside className="col-side">
                <SidePanels />
              </aside>
            </div>
          </main>

          <footer className="footer">
            <div className="container">
              <div>© {new Date().getFullYear()} ШакалТВ — сделано с 🐺 и немножко ✨</div>
            </div>
          </footer>

          <ChatWidget />
        </>
      )}
    </>
  )
} 
