#!/bin/sh
set -e

CERT_DIR=/etc/nginx/ssl
mkdir -p "$CERT_DIR"

MAIN_DOMAIN=${MAIN_DOMAIN:-aflactf.ru}
TV_HOST="tv.$MAIN_DOMAIN"
AUTH_HOST="auth.$MAIN_DOMAIN"
WILDCARD="*.$MAIN_DOMAIN"

if [ ! -f "$CERT_DIR/server.crt" ] || [ ! -f "$CERT_DIR/server.key" ]; then
	if ! openssl req -x509 -nodes -newkey rsa:2048 -keyout "$CERT_DIR/server.key" -out "$CERT_DIR/server.crt" -days 365 -subj "/CN=$WILDCARD" -addext "subjectAltName=DNS:$TV_HOST,DNS:$AUTH_HOST,DNS:$MAIN_DOMAIN,DNS:$WILDCARD,IP:127.0.0.1" 2>/dev/null; then
		openssl req -x509 -nodes -newkey rsa:2048 -keyout "$CERT_DIR/server.key" -out "$CERT_DIR/server.crt" -days 365 -subj "/CN=$WILDCARD"
	fi
fi

if [ -f /etc/nginx/conf.d/default.conf.template ]; then
	envsubst '$MAIN_DOMAIN' < /etc/nginx/conf.d/default.conf.template > /etc/nginx/conf.d/default.conf
fi

exec nginx -g "daemon off;" 