import os
import time
import redis
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options

FLAG = os.getenv('FLAG', '')

REDIS_HOST = os.getenv('REDIS_HOST', 'redis')
REDIS_URL = os.getenv('REDIS_URL', 'redis://redis:6379/0')

MAIN_DOMAIN = (os.getenv('MAIN_DOMAIN') or os.getenv('COOKIE_DOMAIN', '.aflactf.ru').lstrip('.')).strip() or 'aflactf.ru'
if MAIN_DOMAIN.startswith('.'):
    MAIN_DOMAIN = MAIN_DOMAIN.lstrip('.')
WEB_HTTPS_PORT = os.getenv('WEB_HTTPS_PORT', '20016')

SHK_AUTH_URL = os.getenv('SHK_AUTH_URL', f'https://auth.{MAIN_DOMAIN}:{WEB_HTTPS_PORT}')
WEB_BASE = os.getenv('WEB_BASE', f'https://tv.{MAIN_DOMAIN}:{WEB_HTTPS_PORT}')

ADMIN_USERNAME = os.getenv('ADMIN_USERNAME', 'admin')
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'SecretPass123!')


def driver_sleep(driver, sec):
    try:
        WebDriverWait(driver, sec).until(EC.presence_of_element_located((By.CLASS_NAME, 'sleeping')))
    except Exception:
        pass


def make_driver():
    options = Options()
    options.add_argument('--headless=new')
    options.add_argument('--no-sandbox')
    options.add_argument('start-maximized')
    options.add_argument('disable-infobars')
    options.add_argument('--disable-extensions')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--disable-gpu')
    options.add_argument('--disable-default-apps')
    options.add_argument('--no-first-run')
    options.add_argument('--no-default-browser-check')
    options.add_argument('--disable-client-side-phishing-detection')
    options.add_argument('--disable-popup-blocking')
    options.add_argument('--disable-translate')
    options.add_argument('--ignore-certificate-errors')
    options.add_argument('--ignore-ssl-errors')
    options.add_argument('--ignore-certificate-errors-spki-list')
    options.add_argument('--verbose')
    driver = webdriver.Chrome(options=options)
    return driver


def ensure_oauth_session(driver):
    login_url = f"{SHK_AUTH_URL}/login"
    print(login_url, flush=True)
    driver.get(login_url)
    try:
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, 'username')))
        driver.find_element(By.NAME, 'username').clear()
        driver.find_element(By.NAME, 'username').send_keys(ADMIN_USERNAME)
        driver.find_element(By.NAME, 'password').clear()
        driver.find_element(By.NAME, 'password').send_keys(ADMIN_PASSWORD)
        driver.find_element(By.CSS_SELECTOR, 'button[type=submit]').click()
    except Exception as ex:
        print(ex, flush=True)
    driver_sleep(driver, 1)
    
    try:
        driver.get(f"{WEB_BASE}/api/auth/login?next=/")
    except Exception as ex:
        print(ex,flush=True)
    try:
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, 'root')))
    except Exception:
        driver_sleep(driver, 2)



def main():
    r = redis.StrictRedis.from_url(REDIS_URL, decode_responses=True)
    while True:
        url = r.blpop('bot.visit_url', 0)[1]
        if not url:
            continue
        print('Processing url:', url, flush=True)
        driver = make_driver()
        try:
            print('Browser ready, preparing OAuth and opening url:', url, flush=True)
            ensure_oauth_session(driver)
            driver.get(url)
            driver_sleep(driver, 7)
        except Exception as ex:
            print(f"ERROR while processing {url}: {ex}", flush=True)
        finally:
            try:
                driver.quit()
            except Exception:
                pass
            print('Browser closed', flush=True)


if __name__ == '__main__':
    try:
        print('Starting bot', flush=True)
        main()
    except Exception as ex:
        print(f"ERROR: {ex}", flush=True) 