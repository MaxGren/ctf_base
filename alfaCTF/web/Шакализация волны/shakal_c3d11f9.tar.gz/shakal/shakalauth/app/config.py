import os

APP_NAME = "ШакалАутх"
AUTH_HOST = os.getenv("AUTH_HOST", "0.0.0.0")
AUTH_PORT = int(os.getenv("AUTH_PORT", "8081"))
SESSION_SECRET = os.getenv("AUTH_SESSION_SECRET", os.getenv("SECRET_KEY", "dev_auth_secret"))

MAIN_DOMAIN = (os.getenv("MAIN_DOMAIN") or os.getenv("COOKIE_DOMAIN", ".aflactf.ru").lstrip(".")).strip()
if MAIN_DOMAIN.startswith("."):
	MAIN_DOMAIN = MAIN_DOMAIN.lstrip(".")
COOKIE_DOMAIN = os.getenv("COOKIE_DOMAIN", f".{MAIN_DOMAIN}")

ALLOWED_CLIENTS = {"shakaltv"} 