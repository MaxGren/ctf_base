from typing import Optional
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import Integer, String, BigInteger, ForeignKey, UniqueConstraint

from .db import Base


class AuthUser(Base):
	__tablename__ = "auth_users"

	id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
	username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
	name: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
	email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
	password_hash: Mapped[str] = mapped_column(String(128))
	salt: Mapped[str] = mapped_column(String(32))
	picture: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)

	codes: Mapped[list["OAuthCode"]] = relationship("OAuthCode", back_populates="user", cascade="all, delete-orphan")


class OAuthCode(Base):
	__tablename__ = "oauth_codes"
	__table_args__ = (
		UniqueConstraint("code", name="uq_oauth_code_code"),
	)

	id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
	code: Mapped[str] = mapped_column(String(128), unique=True, index=True)
	client_id: Mapped[str] = mapped_column(String(64), index=True)
	created_at: Mapped[int] = mapped_column(BigInteger)
	user_id: Mapped[int] = mapped_column(ForeignKey("auth_users.id", ondelete="CASCADE"))

	user: Mapped[AuthUser] = relationship("AuthUser", back_populates="codes") 