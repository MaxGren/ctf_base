import time
from typing import Dict, Optional

from fastapi import Request
from fastapi.responses import HTMLResponse
import hashlib

from .config import APP_NAME


def get_current_user(request: Request) -> Optional[Dict]:
	user = request.session.get("user")
	if not user:
		return None
	return user

def hash_password(password: str, salt: str) -> str:
	return hashlib.sha256(f"{salt}:{password}".encode("utf-8")).hexdigest()

def set_flash(request: Request, text: str, tone: str = "info") -> None:
	request.session["_flash"] = {"text": text, "tone": tone}

def pop_flash(request: Request) -> Optional[Dict[str, str]]:
	return request.session.pop("_flash", None)

def render_page(request: Request, body: str, title: str = APP_NAME) -> HTMLResponse:
	user = get_current_user(request)
	flash = pop_flash(request)
	css = """
	* , *::before, *::after { box-sizing: border-box }
	body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; background:#0f0f10; color:#e6e6e6; margin:0 }
	.header { display:flex; align-items:center; justify-content:space-between; padding:12px 16px; background:#121214; border-bottom:1px solid #1e1e22; position:sticky; top:0; z-index:10 }
	.brand { display:flex; align-items:center; gap:10px; font-weight:800; letter-spacing:.2px }
	.logo { width:30px; height:30px; display:grid; place-items:center; background:#222229; border:1px solid #2c2c33; border-radius:8px }
	.nav { display:flex; align-items:center; gap:8px }
	.container { max-width:960px; margin:0 auto; padding:16px }
	.hero { max-width:720px; margin: 0 auto 16px auto }
	.card { background:#141417; border:1px solid #22222a; border-radius:12px; padding:16px }
	.card.center { max-width:420px; margin:24px auto }
	.muted { color:#9aa0a6 }
	.input { width:100%; background:#0f0f12; border:1px solid #2a2a33; color:#e6e6e6; border-radius:8px; padding:10px 12px }
	.label { display:block; font-size:13px; margin:6px 0 6px 2px; color:#b7bdc6 }
	.row { display:flex; gap:12px }
	.grid { display:grid; gap:10px }
	.button { cursor:pointer; border:1px solid #2a2a33; background:#23232a; color:#e6e6e6; border-radius:8px; padding:10px 14px; font-weight:600 }
	.button.primary { background:#3b82f6; border-color:#3b82f6; color:white }
	.button.warn { background:#b45309; border-color:#b45309; color:white }
	.badge { display:inline-block; padding:2px 8px; border-radius:999px; font-size:12px; background:#23232a; border:1px solid #2a2a33 }
	.flash { padding:10px 12px; border-radius:10px; border:1px solid #2a2a33; background:#1a1a1f; margin:0 0 12px 0 }
	.flash.info { border-color:#264f78; background:#0f1b2b }
	.flash.ok { border-color:#1f6f3a; background:#0d2a1b }
	.flash.err { border-color:#7f1d1d; background:#2a0d0d }
	.footer { padding:16px; color:#9aa0a6; text-align:center }
	a { color:#93c5fd; text-decoration:none }
	.link { color:#93c5fd }
	.avatar { width:28px; height:28px; border-radius:999px; overflow:hidden; display:grid; place-items:center; background:#222229; border:1px solid #2c2c33 }
	.avatar img { width:100%; height:100%; object-fit:cover }
	input, button, select, textarea { max-width:100% }
	"""
	flash_html = ""
	if flash:
		cls = "info" if flash["tone"] == "info" else ("ok" if flash["tone"] in ("ok","success") else "err")
		flash_html = f"<div class=flash {'' if cls=='info' else cls}>{flash['text']}</div>"
	auth_html = ""
	if user:
		pic = user.get("picture")
		avatar = f"<img src=\"{pic}\" alt=\"{user['username']}\">" if pic else "🦊"
		auth_html = f"""
			<div class=nav>
				<span class=avatar>{avatar}</span>
				<span class=badge>@{user['username']}</span>
				<a class=button href="/profile">Профиль</a>
				<form method=post action="/logout" style="margin:0"><button class=\"button\" type=submit>Выйти</button></form>
			</div>
		"""
	else:
		auth_html = """
			<div class=nav>
				<a class=button href="/login">Войти</a>
				<a class="button primary" href="/register">Создать профиль</a>
			</div>
		"""
	html = f"""
	<!doctype html>
	<html lang=ru>
	<head>
		<meta charset=utf-8>
		<meta name=viewport content="width=device-width, initial-scale=1">
		<title>{title}</title>
		<style>{css}</style>
	</head>
	<body>
		<header class="header">
			<a href="/" style="text-decoration: none; color: inherit;">
				<div class="brand"><div class="logo"><span>Ш</span></div><div>{APP_NAME}</div></div>
			</a>
			{auth_html}
		</header>
		<main class="container">
			<div class="hero">
				{flash_html}
			</div>
			{body}
		</main>
		<footer class="footer">© {time.strftime('%Y')} {APP_NAME}</footer>
	</body>
	</html>
	"""
	return HTMLResponse(html) 