import time
import secrets
from typing import Dict

from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import RedirectResponse, JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, insert, delete

from .helpers import render_page, get_current_user
from .config import COOKIE_DOMAIN, APP_NAME, ALLOWED_CLIENTS
from .models import OAuthCode, AuthUser
from .db import get_session

router = APIRouter()


@router.get("/oauth/authorize")
async def oauth_authorize(request: Request, client_id: str, redirect_uri: str, response_type: str = "code", scope: str = "basic", state: str = "", next: str = "", session: AsyncSession = Depends(get_session)):
	if client_id not in ALLOWED_CLIENTS:
		return render_page(request, "<div class=card><p>Неизвестный клиент</p></div>", title="Ошибка")
	if response_type != "code":
		return render_page(request, "<div class=card><p>Неподдерживаемый response_type</p></div>", title="Ошибка")

	user = get_current_user(request)
	if not user:
		from urllib.parse import quote
		proto = (request.headers.get("x-forwarded-proto") or "http").lower()
		host = request.headers.get("x-forwarded-host") or request.headers.get("host") or request.url.netloc
		path_qs = request.url.path
		if request.url.query:
			path_qs += f"?{request.url.query}"
		next_url = quote(f"{proto}://{host}{path_qs}", safe='')
		return RedirectResponse(url=f"/login?next={next_url}", status_code=302)

	res_user = await session.execute(select(AuthUser).where(AuthUser.id == user["id"]))
	db_user = res_user.scalar_one_or_none()
	if not db_user:
		request.session.clear()
		from urllib.parse import quote
		proto = (request.headers.get("x-forwarded-proto") or "http").lower()
		host = request.headers.get("x-forwarded-host") or request.headers.get("host") or request.url.netloc
		path_qs = request.url.path
		if request.url.query:
			path_qs += f"?{request.url.query}"
		next_url = quote(f"{proto}://{host}{path_qs}", safe='')
		return RedirectResponse(url=f"/login?next={next_url}", status_code=302)

	code = secrets.token_urlsafe(24)
	await session.execute(insert(OAuthCode).values(
		code=code,
		client_id=client_id,
		created_at=int(time.time()),
		user_id=user["id"],
	))
	await session.commit()
	if not redirect_uri:
		return render_page(request, "<div class=card><p>Не указан redirect_uri</p></div>", title="Ошибка")
	sep = '&' if ('?' in redirect_uri) else '?'
	redirect_scheme = redirect_uri.split("://", 1)[0]
	redirect_host = redirect_uri.split("://", 1)[1].split("/", 1)[0].split(":", 1)[0]
	print(redirect_scheme, redirect_host, flush=True)	
	if redirect_host.endswith(COOKIE_DOMAIN):
		callback_url = f"{redirect_uri}{sep}code={code}&state={state}"
	else:
		return render_page(request, "<div class=card><p>Внешний redirect_uri не разрешен</p></div>", title="Ошибка")

	from html import escape
	import json
	from string import Template
	target_after = next or '/'
	target_json = json.dumps(target_after)
	tpl = Template("""
	<div class="card">
		<h2 style="margin-top:0">${app_name}: переход к приложению</h2>
		<p class="muted">Через <span id="seconds">5</span> секунд вы будете перенаправлены.<br>Если не произошло автоматически, <a class="link" id="continueLink" href="${target_href}" rel="noopener noreferrer">перейдите по ссылке</a>.</p>
		<iframe sandbox="allow-scripts" style="width:100%;height:320px;border:1px solid #e5e7eb;border-radius:8px" srcdoc="
			<!DOCTYPE html>
			<html>
				<head></head>
				<meta charset='UTF-8'>
				<base href='about:srcdoc'>
				<title>ШакалАутх переход</title>
				</head>
				<body>
					<p style='font-family:system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, Arial; color:#374151'>Ожидание подтверждения входа…</p>
					<script>document.location.replace('${callback_url}');</script>
				</body>
			</html>">
		</iframe>
	</div>
	<script>
	(function(){
		var total = 5;
		var label = document.getElementById('seconds');
		var link = document.getElementById('continueLink');
		function tick(){
			total -= 1;
			if(label){ label.textContent = String(total); }
			if(total <= 0){
				var target = ${target_json};
				try { window.location.href = target; } catch(e) { if(link){ link.href = target; } }
				return;
			}
			setTimeout(tick, 1000);
		}
		setTimeout(tick, 1000);
	})();
	</script>
	""")
	preview_html = tpl.safe_substitute(app_name=APP_NAME, target_href=escape(target_after), callback_url=escape(callback_url), target_json=target_json)
	return render_page(request, preview_html, title=f"{APP_NAME} — возврат к приложению")


@router.post("/oauth/approve")
async def oauth_approve(request: Request, session: AsyncSession = Depends(get_session)):
	user = get_current_user(request)
	redirect_uri = request.session.get("pending_redirect_uri")
	client_id = request.session.get("pending_client_id")
	state = request.session.get("pending_state", "")

	if not user or not redirect_uri or client_id not in ALLOWED_CLIENTS:
		return render_page(request, "<div class=card><p>Невалидная сессия подтверждения</p></div>", title="Ошибка")

	res_user = await session.execute(select(AuthUser).where(AuthUser.id == user["id"]))
	db_user = res_user.scalar_one_or_none()
	if not db_user:
		request.session.clear()
		return render_page(request, "<div class=card><p>Сессия истекла. Войдите заново.</p></div>", title="Ошибка")

	code = secrets.token_urlsafe(24)
	await session.execute(insert(OAuthCode).values(
		code=code,
		client_id=client_id,
		created_at=int(time.time()),
		user_id=user["id"],
	))
	await session.commit()

	request.session.pop("pending_redirect_uri", None)
	request.session.pop("pending_client_id", None)
	request.session.pop("pending_state", None)

	sep = '&' if ('?' in redirect_uri) else '?'
	return RedirectResponse(url=f"{redirect_uri}{sep}code={code}&state={state}", status_code=302)


@router.post("/oauth/token")
async def oauth_token(grant_type: str = Form(...), client_id: str = Form(...), code: str = Form(...), redirect_uri: str = Form(...), session: AsyncSession = Depends(get_session)):
	if grant_type != "authorization_code":
		return JSONResponse({"error": "unsupported_grant_type"}, status_code=400)
	if client_id not in ALLOWED_CLIENTS:
		return JSONResponse({"error": "invalid_client"}, status_code=400)
	res = await session.execute(select(OAuthCode).where(OAuthCode.code == code))
	payload = res.scalar_one_or_none()
	if not payload:
		return JSONResponse({"error": "invalid_code"}, status_code=400)
	if payload.client_id != client_id:
		return JSONResponse({"error": "invalid_request"}, status_code=400)

	user_res = await session.execute(select(AuthUser).where(AuthUser.id == payload.user_id))
	db_user = user_res.scalar_one_or_none()
	await session.execute(delete(OAuthCode).where(OAuthCode.id == payload.id))
	await session.commit()

	if not db_user:
		return JSONResponse({"error": "invalid_user"}, status_code=400)

	access_token = secrets.token_urlsafe(24)
	return JSONResponse({
		"access_token": access_token,
		"token_type": "bearer",
		"expires_in": 3600,
		"user": {
			"id": db_user.id,
			"username": db_user.username,
			"name": db_user.name or db_user.username,
			"email": db_user.email,
			"picture": db_user.picture,
		},
	}) 