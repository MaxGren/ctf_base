import os
import secrets
import time
from typing import Dict, Optional

from fastapi import FastAPI, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from starlette.middleware.sessions import SessionMiddleware
import hashlib
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, insert

from .config import APP_NAME, SESSION_SECRET
from . import pages_routes, oauth_routes
from .db import init_db, get_session, SessionLocal
from .models import AuthUser

app = FastAPI(title=APP_NAME)
app.add_middleware(
	SessionMiddleware,
	secret_key=SESSION_SECRET,
	same_site="None",
	https_only=True,
	session_cookie="shakalauth_session",
)

app.include_router(pages_routes.router)
app.include_router(oauth_routes.router)


@app.on_event("startup")
async def on_startup():
	await init_db()
	_admin_username = os.getenv("AUTH_ADMIN_USERNAME") or os.getenv("ADMIN_USERNAME")
	_admin_password = os.getenv("AUTH_ADMIN_PASSWORD") or os.getenv("ADMIN_PASSWORD")
	_admin_email = os.getenv("AUTH_ADMIN_EMAIL") or None
	if _admin_username and _admin_password:
		async with SessionLocal() as session:
			res = await session.execute(select(AuthUser).where(AuthUser.username == _admin_username))
			existing = res.scalar_one_or_none()
			if not existing:
				from .helpers import hash_password
				salt = secrets.token_hex(8)
				pwd_hash = hash_password(_admin_password, salt)
				await session.execute(insert(AuthUser).values(
					username=_admin_username,
					name=_admin_username,
					email=_admin_email,
					password_hash=pwd_hash,
					salt=salt,
					picture=None,
				))
				await session.commit() 