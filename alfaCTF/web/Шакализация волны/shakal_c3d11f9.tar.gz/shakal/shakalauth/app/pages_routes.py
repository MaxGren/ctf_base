from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import RedirectResponse
import secrets
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, insert

from .helpers import render_page, set_flash, get_current_user, hash_password
from .config import APP_NAME
from .db import get_session
from .models import AuthUser

router = APIRouter()


@router.get("/")
async def index(request: Request):
	user = get_current_user(request)
	if user:
		body = f"""
		<div class=card>
			<h2 style="margin-top:0">Вы вошли как {user['name'] or user['username']}</h2>
			<p class=muted>Теперь вы можете авторизоваться в приложении ШакалТВ через OAuth.</p>
			<div class=row>
				<a class="button" href="/profile">Перейти в профиль</a>
			</div>
		</div>
		"""
	else:
		body = f"""
		<div class="card center">
			<h2 style="margin-top:0">Добро пожаловать в {APP_NAME}</h2>
			<div class=row>
				<a class="button primary" href="/register">Создать профиль</a>
				<a class="button" href="/login">Войти</a>
			</div>
			<p class=muted style="margin-top:10px">Используйте единый профиль для входа в ШакалТВ.</p>
		</div>
		"""
	return render_page(request, body)


@router.get("/register")
async def register_form(request: Request):
	body = """
	<div class="card center">
		<h2 style="margin-top:0">Создать профиль</h2>
		<form method=post action="/register" class=grid>
			<label class=label>Логин</label>
			<input class=input name=username placeholder="Логин" minlength=9 required>
			<label class=label>Email (необязательно)</label>
			<input class=input type=email name=email placeholder="you@example.com">
			<label class=label>Пароль</label>
			<input class=input type=password name=password placeholder="Пароль" minlength=9 required>
			<label class=label>Повторите пароль</label>
			<input class=input type=password name=confirm placeholder="Повторите пароль" minlength=9 required>
			<button class="button primary" type=submit>Зарегистрироваться</button>
		</form>
		<p class=muted>Уже есть профиль? <a class=link href="/login">Войти</a></p>
	</div>
	"""
	return render_page(request, body, title=f"Регистрация — {APP_NAME}")


@router.post("/register")
async def register_post(request: Request, username: str = Form(...), password: str = Form(...), confirm: str = Form(...), email: str = Form(None), session: AsyncSession = Depends(get_session)):
	if len(username) < 9:
		set_flash(request, "Логин слишком короткий (минимум 9)", tone="err")
		return RedirectResponse(url="/register", status_code=302)
	if len(password) < 9:
		set_flash(request, "Пароль слишком короткий (минимум 9)", tone="err")
		return RedirectResponse(url="/register", status_code=302)
	if password != confirm:
		set_flash(request, "Пароли не совпадают", tone="err")
		return RedirectResponse(url="/register", status_code=302)

	existing = await session.execute(select(AuthUser).where(AuthUser.username == username))
	if existing.scalar_one_or_none() is not None:
		set_flash(request, "Логин уже занят", tone="err")
		return RedirectResponse(url="/register", status_code=302)

	salt = secrets.token_hex(8)
	pwd_hash = hash_password(password, salt)
	await session.execute(insert(AuthUser).values(
		username=username,
		name=username,
		email=email,
		password_hash=pwd_hash,
		salt=salt,
		picture=None,
	))
	await session.commit()
	set_flash(request, "Профиль создан. Войдите, чтобы продолжить.", tone="ok")
	return RedirectResponse(url="/login", status_code=302)


@router.get("/login")
async def login_form(request: Request):
	next_param = request.query_params.get("next", "")
	body = f"""
	<div class="card center">
		<h2 style="margin-top:0">Войти</h2>
		<form method=post action="/login" class=grid>
			<input type=hidden name=next value="{next_param}">
			<label class=label>Логин</label>
			<input class=input name=username placeholder="Логин" required>
			<label class=label>Пароль</label>
			<input class=input type=password name=password placeholder="Пароль" required>
			<button class="button primary" type=submit>Войти</button>
		</form>
		<p class=muted>Нет профиля? <a class=link href="/register">Создайте</a></p>
	</div>
	"""
	return render_page(request, body, title=f"Вход — {APP_NAME}")


@router.post("/login")
async def login_post(request: Request, username: str = Form(...), password: str = Form(...), next: str = Form(""), session: AsyncSession = Depends(get_session)):
	res = await session.execute(select(AuthUser).where(AuthUser.username == username))
	user = res.scalar_one_or_none()
	if not user or user.password_hash != hash_password(password, user.salt):
		set_flash(request, "Неверные логин или пароль", tone="err")
		next_q = f"?next={next}" if next else ""
		return RedirectResponse(url=f"/login{next_q}", status_code=302)
	request.session["username"] = username
	request.session["user"] = {
		"id": user.id,
		"username": user.username,
		"name": user.name,
		"email": user.email,
		"picture": user.picture,
	}
	set_flash(request, f"Добро пожаловать, {username}!", tone="ok")
	redirect_to = next or "/"
	return RedirectResponse(url=redirect_to, status_code=302)


@router.post("/logout")
async def logout_post(request: Request):
	request.session.clear()
	set_flash(request, "Вы вышли из аккаунта", tone="info")
	return RedirectResponse(url="/", status_code=302)	


@router.get("/logout")
async def logout_get(request: Request):
	return await logout_post(request)


@router.get("/profile")
async def profile_form(request: Request):
	user = get_current_user(request)
	if not user:
		set_flash(request, "Войдите, чтобы открыть профиль", tone="err")
		return RedirectResponse(url="/login", status_code=302)
	body = f"""
	<div class=card>
		<h2 style="margin-top:0">Профиль</h2>
		<form method=post action="/profile" class=grid>
			<label class=label>Имя</label>
			<input class=input name=name value="{user.get('name') or ''}" placeholder="Ваше имя">
			<label class=label>Email</label>
			<input class=input type=email name=email value="{user.get('email') or ''}" placeholder="you@example.com">
			<label class=label>Аватар (URL)</label>
			<input class=input name=picture value="{user.get('picture') or ''}" placeholder="https://...">
			<hr style="border:none;border-top:1px solid #22222a;margin:8px 0" />
			<label class=label>Сменить пароль (необязательно)</label>
			<input class=input type=password name=old_password placeholder="Текущий пароль">
			<input class=input type=password name=new_password placeholder="Новый пароль (мин. 9)" minlength=9>
			<input class=input type=password name=confirm_new placeholder="Повторите новый пароль" minlength=9>
			<div class=row>
				<button class="button primary" type=submit>Сохранить</button>
				<a class=button href="/">Отмена</a>
			</div>
		</form>
	</div>
	"""
	return render_page(request, body, title=f"Профиль — {APP_NAME}")


@router.post("/profile")
async def profile_post(request: Request, name: str = Form(""), email: str = Form(""), picture: str = Form(""), old_password: str = Form(""), new_password: str = Form(""), confirm_new: str = Form(""), session: AsyncSession = Depends(get_session)):
	user_sess = get_current_user(request)
	if not user_sess:
		set_flash(request, "Сессия истекла. Войдите заново.", tone="err")
		return RedirectResponse(url="/login", status_code=302)
	res = await session.execute(select(AuthUser).where(AuthUser.username == user_sess["username"]))
	db_user = res.scalar_one_or_none()
	if not db_user:
		set_flash(request, "Профиль не найден.", tone="err")
		return RedirectResponse(url="/login", status_code=302)

	db_user.name = name or db_user.name
	db_user.email = email or None
	db_user.picture = picture or None
	if new_password or old_password or confirm_new:
		if len(new_password) < 9:
			set_flash(request, "Новый пароль слишком короткий (минимум 9)", tone="err")
			return RedirectResponse(url="/profile", status_code=302)
		if new_password != confirm_new:
			set_flash(request, "Новые пароли не совпадают", tone="err")
			return RedirectResponse(url="/profile", status_code=302)
		if db_user.password_hash != hash_password(old_password, db_user.salt):
			set_flash(request, "Текущий пароль неверен", tone="err")
			return RedirectResponse(url="/profile", status_code=302)
		salt = secrets.token_hex(8)
		db_user.salt = salt
		db_user.password_hash = hash_password(new_password, salt)

	await session.commit()
	request.session["user"] = {
		"id": db_user.id,
		"username": db_user.username,
		"name": db_user.name,
		"email": db_user.email,
		"picture": db_user.picture,
	}
	set_flash(request, "Профиль обновлён", tone="ok")
	return RedirectResponse(url="/profile", status_code=302) 
