from flask import render_template, request, redirect, url_for, session, flash, jsonify
import secrets
from datetime import datetime
from functools import wraps

from models import MEME_LOOKUP
from database import get_user_data, set_user_data, get_meme_votes, increment_meme_vote, drop_votes
from services import (
    get_contest_countdown, generate_captcha, get_meme_title, 
    check_autowin_status_with_votes, build_memes_with_votes, 
    no_votes_exist
)
from utils import verify_captcha


def require_auth(f):
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function


def index():
    try:
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return redirect(url_for('voting'))
    except Exception:
        session.clear()
        return redirect(url_for('login'))


def login():
    if request.method == 'POST':
        passport = request.form.get('passport')
        if passport:
            if len(passport) > 14:
                return render_template('login.html', error='Номер паспорта не может быть длиннее 14 символов')
            
            user_id = secrets.token_hex(16)
            
            session.update({
                'user_id': user_id,
                'passport': passport
            })
            session.permanent = True
            session.modified = True
            
            user_data = {
                'passport': passport,
                'has_voted': False
            }
            
            set_user_data(user_id, user_data)
            return redirect(url_for('voting'))
        
        return render_template('login.html', error='Введите паспорт')
    
    return render_template('login.html')


def logout():
    try:
        session.clear()
        flash('Вы вышли из системы', 'info')
    except Exception:
        pass
    return redirect(url_for('login'))


@require_auth
def voting():
    user_id = session['user_id']
    votes = get_meme_votes()
    user_data = get_user_data(user_id)
    user_has_voted = user_data and user_data.get('has_voted', False)
    user_vote_data = None
    
    if user_has_voted and user_data and 'voted_for' in user_data:
        user_vote_data = {'meme_id': user_data['voted_for']}
    
    captcha_text, captcha_b64 = generate_captcha()
    session['captcha_text'] = captcha_text
    
    votes = get_meme_votes()
    
    autowin_status = check_autowin_status_with_votes(votes)
    if autowin_status['achieved']:
        return redirect(url_for('results'))
    
    memes_with_votes = build_memes_with_votes(votes)
    
    return render_template('voting.html', 
                         memes=memes_with_votes, 
                         captcha_image=captcha_b64,
                         user_has_voted=user_has_voted,
                         user_vote_data=user_vote_data,
                         countdown=get_contest_countdown())


@require_auth
def results():
    votes = get_meme_votes()
    
    memes_with_votes = build_memes_with_votes(votes)
    sorted_memes = sorted(memes_with_votes, key=lambda x: x['votes'], reverse=True)
    
    autowin_status = check_autowin_status_with_votes(votes)
    if autowin_status['achieved'] and autowin_status['winner_id'] == 6:
        flag = "alfa{XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX}"
        autowin_status['flag'] = flag
    
    return render_template('results.html', 
                         memes=sorted_memes, 
                         autowin_status=autowin_status, 
                         countdown=get_contest_countdown())


def api_submit_vote():
    if 'user_id' not in session:
        return jsonify({'error': 'Не авторизован'}), 401
    
    votes = get_meme_votes()
    autowin_status = check_autowin_status_with_votes(votes)
    if autowin_status['achieved']:
        winner_title = autowin_status['winner_title']
        winner_votes = autowin_status['winner_votes']
        return jsonify({
            'success': False, 
            'error': f'Голосование завершено! Мем "{winner_title}" достиг {winner_votes} голосов и победил!'
        }), 400
    
    user_id = session['user_id']
    meme_id = request.json.get('meme_id')
    captcha_input = str(request.json.get('captcha_input')).upper()
    
    if not meme_id or not str(meme_id).isdigit():
        return jsonify({'success': False, 'error': 'Неверный ID мема'}), 400
    
    meme_id = int(meme_id)
    
    if meme_id not in MEME_LOOKUP:
        return jsonify({'success': False, 'error': 'Мем не найден'}), 404
    
    user_data = get_user_data(user_id)
    
    if user_data and user_data.get('has_voted', False):
        voted_meme_id = user_data.get('voted_for')
        voted_meme_title = get_meme_title(voted_meme_id) if voted_meme_id else None
        error_msg = f'Вы уже проголосовали за "{voted_meme_title}"!' if voted_meme_title else 'Вы уже проголосовали!'
        return jsonify({'success': False, 'error': error_msg}), 400
    
    if not captcha_input:
        return jsonify({'success': False, 'error': 'Требуется ввод кода'}), 400
    
    session_captcha = str(session.get('captcha_text')).upper()
    if not session_captcha:
        return jsonify({'success': False, 'error': 'Код не найдена в сессии. Пожалуйста, обновите страницу.'}), 400
    
    if not verify_captcha(captcha_input, session_captcha):
        new_captcha_text, new_captcha_b64 = generate_captcha()
        session['captcha_text'] = new_captcha_text
        
        return jsonify({
            'success': False, 
            'error': 'Неправильный код',
            'new_captcha_image': new_captcha_b64
        }), 400
    
    session.pop('captcha_text', None)
    
    new_votes = increment_meme_vote(meme_id)
    if new_votes is None:
        return jsonify({'success': False, 'error': 'Не удалось записать голос'}), 500
    
    if not user_data:
        user_data = {
            'passport': 'unknown',
            'has_voted': False
        }
    
    user_data['has_voted'] = True
    user_data['voted_for'] = meme_id
    set_user_data(user_id, user_data)
    
    return jsonify({
        'success': True, 
        'message': f'Голос успешно записан!',
        'new_votes': new_votes
    })


def api_drop_votes():
    if 'user_id' not in session:
        return jsonify({'error': 'Не авторизован'}), 401
    
    success, message = drop_votes()
    
    if success:
        return jsonify({'success': True, 'message': message})
    else:
        return jsonify({'success': False, 'error': message}), 500


def health_check():
    try:
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500
