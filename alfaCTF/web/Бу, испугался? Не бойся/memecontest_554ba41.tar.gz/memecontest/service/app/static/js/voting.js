// Import shared utilities
import { 
    initializeCountdown, 
    showModal, 
    hideModal, 
    showErrorModal, 
    showInfoModal 
} from './utils.js';

let currentMemeId = null;
let currentMemeTitle = null;

function cleanupModalBackdrop() {
    console.log('Modal backdrop cleanup not needed - using backdrop: false');
}

function openVoteModal(memeId, memeTitle) {
    if (typeof userHasVoted !== 'undefined' && userHasVoted) {
        if (memeId === userVoteDataMemeId) {
            showInfoModal('Уже проголосовали', 'Вы уже проголосовали за этот мем!');
        } else {
            showInfoModal('Уже проголосовали', 'Вы уже проголосовали за другой мем.');
        }
        return;
    }
    
    currentMemeId = memeId;
    currentMemeTitle = memeTitle;
    
    document.getElementById('memeTitle').textContent = memeTitle;
    document.getElementById('passCaptchaBtn').style.display = 'none';
    
    document.getElementById('captchaInput').value = '';
    
    showModal('voteModal', {
        backdrop: false,
        keyboard: false,
        focus: true
    });
}

function checkCaptchaInput() {
    const captchaInput = document.getElementById('captchaInput');
    const passButton = document.getElementById('passCaptchaBtn');
    
    if (captchaInput.value.trim().length >= 6) {
        passButton.style.display = 'inline-block';
    } else {
        passButton.style.display = 'none';
    }
}

function passCaptcha() {
    const captchaInput = document.getElementById('captchaInput');
    const captchaValue = captchaInput.value.trim();
    
    if (!captchaValue || captchaValue.length < 6) {
        showErrorModal('Неполная капча', 'Пожалуйста, введите полный текст капчи!');
        return;
    }
    
    document.getElementById('passCaptchaBtn').style.display = 'none';
    document.getElementById('loadingSpinner').style.display = 'block';
    
    submitVoteWithCaptcha(captchaValue);
}

function showConfirmationModal() {
    showModal('confirmationModal');
}

function closeConfirmationModal() {
    hideModal('confirmationModal');
    
    setTimeout(() => {
        location.reload();
    }, 500);
}

function showAutowinModal(winner, message) {
    document.getElementById('autowinWinner').textContent = winner;
    document.getElementById('autowinMessage').textContent = message;
    
    showModal('autowinModal', {
        backdrop: 'static',
        keyboard: false
    });
}

function closeAutowinModal() {
    hideModal('autowinModal');
    
    setTimeout(() => {
        window.location.href = '/results';
    }, 500);
}

function submitVoteWithCaptcha(captchaValue) {
    fetch('/api/submit-vote', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            'meme_id': currentMemeId,
            'captcha_input': captchaValue
        })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('loadingSpinner').style.display = 'none';
        
        if (data.success) {
            hideModal('voteModal');
            showConfirmationModal();
        } else {
            if (data.new_captcha_image) {
                const captchaImg = document.getElementById('captchaImage');
                if (captchaImg) {
                    captchaImg.classList.add('captcha-image-update');
                    captchaImg.src = 'data:image/png;base64,' + data.new_captcha_image;
                    
                    setTimeout(() => {
                        captchaImg.classList.remove('captcha-image-update');
                    }, 500);
                }
                
                showErrorModal('Неправильный код', 'Код, который вы ввели, неверный. Пожалуйста, попробуйте снова.');
            } else {
                showErrorModal('Ошибка отправки голоса', data.error || 'Не удалось отправить голос. Пожалуйста, попробуйте снова.');
            }
            
            document.getElementById('captchaInput').value = '';
            document.getElementById('passCaptchaBtn').style.display = 'none';
        }
    })
    .catch(error => {
        console.error('Error in submitVoteWithCaptcha:', error);
        
        document.getElementById('loadingSpinner').style.display = 'none';
        showErrorModal('Ошибка отправки голоса', 'Произошла ошибка при отправке вашего голоса. Пожалуйста, попробуйте снова.');
    });
}

document.addEventListener('DOMContentLoaded', function() {
    const captchaInput = document.getElementById('captchaInput');
    if (captchaInput) {
        captchaInput.addEventListener('input', checkCaptchaInput);
    }
    
    initializeCountdown();
});

// Make functions globally available for inline onclick handlers
window.openVoteModal = openVoteModal;
window.passCaptcha = passCaptcha;
window.closeConfirmationModal = closeConfirmationModal;
window.showAutowinModal = showAutowinModal;
window.closeAutowinModal = closeAutowinModal;
window.showInfoModal = showInfoModal;