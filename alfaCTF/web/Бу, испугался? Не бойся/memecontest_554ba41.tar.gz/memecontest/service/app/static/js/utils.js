export function initializeCountdown() {
    const countdownElement = document.querySelector('.countdown-timer .h4');
    const statusElement = document.querySelector('.countdown-timer small');
    
    if (!countdownElement || !statusElement) return;
    
    let daysRemaining = 0, hoursRemaining = 0, minutesRemaining = 0;
    
    const countdownContainer = document.querySelector('.countdown-timer');
    if (countdownContainer) {
        const daysText = countdownContainer.querySelector('.h4')?.textContent;
        if (daysText && !isNaN(parseInt(daysText))) {
            daysRemaining = parseInt(daysText);
        }
    }
    
    let totalSeconds = (daysRemaining * 24 * 60 * 60) + (hoursRemaining * 60 * 60) + (minutesRemaining * 60);
    
    const countdownInterval = setInterval(function() {
        if (totalSeconds <= 0) {
            clearInterval(countdownInterval);
            countdownElement.textContent = 'ЗАВЕРШЕН';
            countdownElement.className = 'h4 text-danger mb-1';
            statusElement.textContent = 'Конкурс завершен';
            return;
        }
        
        const days = Math.floor(totalSeconds / (24 * 60 * 60));
        const hours = Math.floor((totalSeconds % (24 * 60 * 60)) / (60 * 60));
        const minutes = Math.floor((totalSeconds % (60 * 60)) / 60);
        
        if (days > 0) {
            countdownElement.textContent = days;
            statusElement.textContent = 'Дней осталось';
        } else if (hours > 0) {
            countdownElement.textContent = hours;
            statusElement.textContent = 'Часов осталось';
        } else {
            countdownElement.textContent = minutes;
            statusElement.textContent = 'Минут осталось';
        }
        
        totalSeconds -= 60;
    }, 60000);
}

export function createModal(modalId, options = {}) {
    const defaultOptions = {
        backdrop: false,
        keyboard: false,
        focus: true,
        ...options
    };
    
    return new bootstrap.Modal(document.getElementById(modalId), defaultOptions);
}

export function showModal(modalId, options = {}) {
    const modal = createModal(modalId, options);
    modal.show();
    return modal;
}

export function hideModal(modalId) {
    const modal = bootstrap.Modal.getInstance(document.getElementById(modalId));
    if (modal) {
        modal.hide();
    }
}

export function showErrorModal(title, message) {
    document.getElementById('errorTitle').textContent = title;
    document.getElementById('errorMessage').textContent = message;
    showModal('errorModal');
}

export function showInfoModal(title, message) {
    document.getElementById('infoTitle').textContent = title;
    document.getElementById('infoMessage').textContent = message;
    showModal('infoModal');
}

export function animateProgressBars() {
    const progressBars = document.querySelectorAll('.progress-bar');
    progressBars.forEach(bar => {
        const width = bar.style.width;
        bar.style.width = '0%';
        setTimeout(() => {
            bar.style.width = width;
        }, 500);
    });
}

export function setupAutoRefresh(intervalMs = 30000) {
    return setInterval(() => {
        location.reload();
    }, intervalMs);
}

// Make utility functions globally available for inline onclick handlers
window.showErrorModal = showErrorModal;
window.showInfoModal = showInfoModal;
