import { 
    setupAutoRefresh, 
    animateProgressBars, 
    initializeCountdown 
} from './utils.js';

setupAutoRefresh(30000);

document.addEventListener('DOMContentLoaded', function() {
    animateProgressBars();
    initializeCountdown();
});

function copyFlag() {
    const flagText = document.getElementById('flagText');
    if (!flagText) {
        console.log('No flag element found');
        return;
    }
    
    navigator.clipboard.writeText(flagText.textContent).then(function() {
        const copyStatus = document.getElementById('copyStatus');
        if (copyStatus) {
            copyStatus.style.display = 'inline-block';
            setTimeout(function() {
                copyStatus.style.display = 'none';
            }, 2000);
        }
    }, function(err) {
        console.error('Failed to copy flag: ', err);
    });
}

function dropVotes() {
    if (!confirm('Вы уверены, что хотите сбросить все голоса? Это действие нельзя отменить.')) {
        return;
    }
    
    const button = event.target.closest('button');
    const originalText = button.innerHTML;
    button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Сброс голосов...';
    button.disabled = true;
    
    fetch('/api/drop-table', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Все голоса успешно сброшены!');
            location.reload();
        } else {
            alert('Ошибка при сбросе голосов: ' + (data.error || 'Неизвестная ошибка'));
            button.innerHTML = originalText;
            button.disabled = false;
        }
    })
    .catch(error => {
        console.error('Error dropping votes:', error);
        alert('Произошла ошибка при сбросе голосов. Пожалуйста, попробуйте снова.');
        button.innerHTML = originalText;
        button.disabled = false;
    });
}

// Make functions globally available for inline onclick handlers
window.copyFlag = copyFlag;
window.dropVotes = dropVotes;
