import secrets
import string
import base64
from datetime import datetime, timedelta
from functools import lru_cache
from captcha.image import ImageCaptcha

from models import MEMES, CAPTCHA_LENGTH, AUTOWIN_THRESHOLD, CONTEST_DURATION_DAYS, MEME_LOOKUP
from database import get_meme_votes

captcha_generator = ImageCaptcha()


@lru_cache(maxsize=1)
def get_contest_countdown():
    contest_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    contest_end = contest_start + timedelta(days=CONTEST_DURATION_DAYS)
    now = datetime.now()
    time_remaining = contest_end - now
    
    russian_months = {
        1: 'января', 2: 'февраля', 3: 'марта', 4: 'апреля',
        5: 'мая', 6: 'июня', 7: 'июля', 8: 'августа',
        9: 'сентября', 10: 'октября', 11: 'ноября', 12: 'декабря'
    }
    
    if time_remaining.total_seconds() <= 0:
        return {
            'status': 'ended',
            'message': 'Конкурс мемов 2025 года закончился!',
            'end_date': contest_end.strftime('%B %d, %Y'),
            'end_date_ru': f"{contest_end.day} {russian_months[contest_end.month]} {contest_end.year} года",
            'days_remaining': 0,
            'hours_remaining': 0,
            'minutes_remaining': 0
        }
    
    days_remaining = time_remaining.days
    hours_remaining = time_remaining.seconds // 3600
    minutes_remaining = (time_remaining.seconds % 3600) // 60
    
    return {
        'status': 'running',
        'message': f'Конкурс мемов 2025 года заканчивается через {days_remaining} дней!',
        'end_date': contest_end.strftime('%B %d, %Y'),
        'end_date_ru': f"{contest_end.day} {russian_months[contest_end.month]} {contest_end.year} года",
        'days_remaining': days_remaining,
        'hours_remaining': hours_remaining,
        'minutes_remaining': minutes_remaining
    }


def generate_captcha():
    captcha_text = ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(CAPTCHA_LENGTH))
    image_data = captcha_generator.generate(captcha_text)
    captcha_b64 = base64.b64encode(image_data.getvalue()).decode('utf-8')
    return captcha_text, captcha_b64


def get_meme_title(meme_id):
    meme = MEME_LOOKUP.get(meme_id)
    return meme['title'] if meme else None


def check_autowin_status_with_votes(votes):
    for meme in MEMES:
        if votes.get(meme['id'], 0) >= AUTOWIN_THRESHOLD:
            return {
                'achieved': True,
                'winner_id': meme['id'],
                'winner_title': meme['title'],
                'winner_votes': votes.get(meme['id'], 0)
            }
    return {'achieved': False}


def no_votes_exist(votes):
    return all(vote_count == 0 for vote_count in votes.values())


def build_memes_with_votes(votes):
    return [{**meme, 'votes': votes.get(meme['id'], 0)} for meme in MEMES]


