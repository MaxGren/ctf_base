from models import REDIS_PREFIX


def get_redis_key(key_type, identifier=None):
    return f"{REDIS_PREFIX}{key_type}:{identifier}" if identifier else f"{REDIS_PREFIX}{key_type}"


def verify_captcha(user_input, session_captcha):
    return user_input == session_captcha if user_input and session_captcha else False
