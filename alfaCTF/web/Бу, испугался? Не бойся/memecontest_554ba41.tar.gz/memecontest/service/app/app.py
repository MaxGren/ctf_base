import gevent.monkey
gevent.monkey.patch_all()

from flask import Flask
from flask_session import Session
import os
import redis
from datetime import timedelta
from database import REDIS_HOST, REDIS_PORT, REDIS_PASSWORD, REDIS_DB
from routes import (
    index, login, logout, voting, results, api_submit_vote, 
    api_drop_votes, health_check
)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY')

app.config.update({
    'SESSION_TYPE': 'redis',
    'REDIS_HOST': REDIS_HOST,
    'REDIS_PORT': REDIS_PORT,
    'REDIS_DB': REDIS_DB,
    'REDIS_PASSWORD': REDIS_PASSWORD,
    'PERMANENT_SESSION_LIFETIME': timedelta(minutes=10),
    'SESSION_COOKIE_NAME': 'memecontest_session',
    'SESSION_COOKIE_SECURE': False,
    'SESSION_COOKIE_HTTPONLY': True,
    'SESSION_COOKIE_SAMESITE': 'Lax',
    'SESSION_COOKIE_PATH': '/',
    'SESSION_COOKIE_DOMAIN': None,
    'SESSION_KEY_PREFIX': 'memecontest_session:',
    'SESSION_REFRESH_EACH_REQUEST': False
})

session_redis = redis.Redis(
    host=REDIS_HOST, port=REDIS_PORT, password=REDIS_PASSWORD, db=REDIS_DB,
    decode_responses=False, encoding='utf-8', encoding_errors='replace',
    retry_on_timeout=True, socket_keepalive=True, socket_keepalive_options={},
    socket_connect_timeout=5, socket_timeout=5, health_check_interval=5
)
app.config['SESSION_REDIS'] = session_redis

Session(app)

try:
    if hasattr(app.session_interface, 'key_prefix'):
        app.session_interface.key_prefix = 'memecontest_session:'
except Exception:
    pass

# Register routes
app.route('/')(index)
app.route('/login', methods=['GET', 'POST'])(login)
app.route('/logout')(logout)
app.route('/golosovanie')(voting)
app.route('/results')(results)
app.route('/api/submit-vote', methods=['POST'])(api_submit_vote)
app.route('/api/drop-table', methods=['POST'])(api_drop_votes)
app.route('/health')(health_check)


@app.before_request
def before_request():
    pass


if __name__ == '__main__':
    try:
        flask_session_keys = session_redis.keys('flask_session:*')
        if flask_session_keys:
            session_redis.delete(*flask_session_keys)
    except Exception:
        pass
    
    app.config.update({
        'MAX_CONTENT_LENGTH': 16 * 1024 * 1024,
        'SEND_FILE_MAX_AGE_DEFAULT': 0,
        'PROPAGATE_EXCEPTIONS': True
    })
    
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
