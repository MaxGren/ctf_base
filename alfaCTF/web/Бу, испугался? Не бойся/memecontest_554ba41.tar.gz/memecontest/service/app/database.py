import os
import json
import redis
import random
from models import MEMES, REDIS_PREFIX
from utils import get_redis_key

# Redis configuration
REDIS_HOST = os.environ.get('REDIS_HOST')
REDIS_PORT = int(os.environ.get('REDIS_PORT'))
REDIS_PASSWORD = os.environ.get('REDIS_PASSWORD', None)
REDIS_DB = 0

REDIS_POOL = redis.ConnectionPool(
    host=REDIS_HOST, port=REDIS_PORT, password=REDIS_PASSWORD, db=REDIS_DB,
    decode_responses=True, max_connections=10000, retry_on_timeout=True,
    socket_keepalive=True, socket_keepalive_options={}, health_check_interval=5,
    encoding='utf-8', encoding_errors='replace', socket_connect_timeout=5, socket_timeout=5
)

try:
    redis_client = redis.Redis(connection_pool=REDIS_POOL)
    redis_client.ping()
except Exception:
    redis_client = None


def get_meme_votes():
    if not redis_client:
        return {meme['id']: 0 for meme in MEMES}
    
    try:
        pipe = redis_client.pipeline(transaction=False)
        for meme in MEMES:
            pipe.get(get_redis_key('votes', meme['id']))
        
        results = pipe.execute()
        return {meme['id']: int(results[i] or 0) for i, meme in enumerate(MEMES)}
    except redis.RedisError:
        return {meme['id']: 0 for meme in MEMES}


def increment_meme_vote(meme_id):
    if not redis_client:
        return None
    try:
        return redis_client.incr(get_redis_key('votes', meme_id))
    except redis.RedisError:
        return None


def get_user_data(user_id):
    if not redis_client:
        return None
    try:
        user_data = redis_client.get(get_redis_key('users', user_id))
        return json.loads(user_data) if user_data else None
    except (redis.RedisError, json.JSONDecodeError, UnicodeDecodeError):
        return None


def set_user_data(user_id, user_data):
    if redis_client:
        try:
            redis_client.setex(get_redis_key('users', user_id), 86400, json.dumps(user_data))
        except (redis.RedisError, TypeError):
            raise


def drop_votes():
    if not redis_client:
        return False, "Redis недоступен"
    
    try:
        pattern = f"{REDIS_PREFIX}*"
        keys = redis_client.keys(pattern)
        
        if not keys:
            return True, "Нет данных для сброса"
        
        redis_client.delete(*keys)
        return True, f"Удалено {len(keys)} ключей"
        
    except Exception as e:
        return False, f"Ошибка при сбросе данных: {str(e)}"


