import io
import tarfile
import docker

client = docker.from_env()

def ensure_container(user, reload_on_create=False):
    name = f'caddy-user-{user.id}'
    try:
        return client.containers.get(name)
    except docker.errors.NotFound:
        container = client.containers.run(
            'caddy',
            name=name,
            detach=True,
            labels={
                'traefik.enable': 'true',
                f'traefik.http.routers.user{user.id}.rule': f'HostRegexp(`^.+-{user.id}--`)',
                f'traefik.http.services.user{user.id}.loadbalancer.server.port': '80',
            },
            network="stormcloud_default",
            pids_limit=50,
            cpu_count=1,
            cpu_percent=10,
            mem_limit="32M",
            restart_policy={"Name": "always"}
        )
        if reload_on_create:
            reload_for_user(user, container)
        return container

def delete_container(user):
    name = f'caddy-user-{user.id}'
    try:
        container = client.containers.get(name)
        container.remove(force=True)
    except docker.errors.NotFound:
        pass

def render_config(user):
    return "{\n\tauto_https off\n}\n\n:80 {" + "".join([f"""\n\t@p{p.id} expression {{host}}.startsWith('{p.name}-{user.id}--')\n\trespond @p{p.id} 200 {{\n\t\tbody "This is an automatically generated project placeholder.\nProject ID: {p.id}\nEnvironment Variables:\n{p.secrets}"\n\t}}""" for p in list(user.projects)]) + """\n\trespond "No such project!" 404\n}\n"""


def reload_for_user(user, container):
    config = render_config(user)
    tarstream = io.BytesIO()
    with tarfile.open(fileobj=tarstream, mode='w') as tar:
        data = config.encode()
        tarinfo = tarfile.TarInfo('Caddyfile')
        tarinfo.size = len(data)
        tar.addfile(tarinfo, io.BytesIO(data))
    tarstream.seek(0)
    container.put_archive('/etc/caddy', tarstream.getvalue())
    return container.exec_run(['caddy', 'reload', '--config', '/etc/caddy/Caddyfile']).output
