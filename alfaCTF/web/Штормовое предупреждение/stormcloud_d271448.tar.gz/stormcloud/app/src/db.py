from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime, Boolean, create_engine, event
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from datetime import datetime
import random
import string
import os

DATABASE_URL = 'postgresql://postgres:notsecret@db/app'
FLAG = os.environ.get("FLAG", "flag{notaflag}")

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String, unique=True, nullable=False)
    password = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    is_premium = Column(Boolean, default=False, nullable=False)
    projects = relationship('Project', back_populates='user')

    def __repr__(self):
        return f"<User(id={self.id}, username={self.username}, is_premium={self.is_premium})>"

class Project(Base):
    __tablename__ = 'projects'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    secrets = Column(Text)
    user_id = Column(Integer, ForeignKey('users.id'))
    user = relationship('User', back_populates='projects')

    def __repr__(self):
        return f"<Project(id={self.id}, name={self.name})>"

def randstr():
    return ''.join(random.choices(string.ascii_lowercase, k=10))

@event.listens_for(User.__table__, "after_create")
def after_create(target, connection, **kw):
    connection.execute(target.insert(), [{'id': 0, 'username': randstr(), 'password': randstr(), 'created_at': datetime.fromtimestamp(0), 'is_premium': True}])

@event.listens_for(Project.__table__, "after_create")
def after_create(target, connection, **kw):
    connection.execute(target.insert(), [{'id': 0, 'name': randstr(), 'secrets': 'FLAG=' + FLAG, 'user_id': 0}])