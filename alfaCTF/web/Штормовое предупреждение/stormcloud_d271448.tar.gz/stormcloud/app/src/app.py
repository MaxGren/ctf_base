from flask import Flask, request, redirect, render_template, session, url_for
from werkzeug.security import generate_password_hash
import socket
import os
from datetime import datetime, timedelta

from db import Base, User, Project, SessionLocal, engine
from contextlib import contextmanager


@contextmanager
def get_db():
    """Provide a transactional scope around a series of operations."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
import caddy

app = Flask(__name__)
app.secret_key = os.environ["SESSION_SECRET"]

Base.metadata.create_all(bind=engine)

class AuthenticationRequired(Exception):
    pass


@contextmanager
def ensure_user():
    if 'user_id' not in session:
        raise AuthenticationRequired()
    db = SessionLocal()
    try:
        user = db.query(User).get(session['user_id'])
        if not user:
            session.clear()
            raise AuthenticationRequired()
        yield db, user
    finally:
        db.close()

@app.errorhandler(AuthenticationRequired)
def auth_required(e):
    return redirect(url_for('index'))

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('register'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        with get_db() as db:
            username = request.form['username']
            password = generate_password_hash(request.form['password'])
            user = User(username=username, password=password)
            db.add(user)
            db.commit()
            session['user_id'] = user.id
            caddy.ensure_container(user)
        return redirect(url_for('dashboard'))
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    with ensure_user() as (db, user):
        if len(user.projects) > 0:
            caddy.ensure_container(user, reload_on_create=True)
        remaining = int((user.created_at + timedelta(minutes=10) - datetime.utcnow()).total_seconds() // 60)
        if remaining < 0:
            remaining = 0
        projects = list(user.projects)
    return render_template('dashboard.html', projects=projects, user=user, host=request.host, msg=request.args.get("msg"), remaining=remaining)

@app.route('/project/create', methods=['POST'])
def create_project():
    with ensure_user() as (db, user):
        name = request.form['name']
        secrets = request.form.get('secrets', '')
        project = Project(name=name, secrets=secrets, user=user)
        db.add(project)
        db.commit()
        try:
            container = caddy.ensure_container(user)
            msg = caddy.reload_for_user(user, container)
        except Exception as e:
            msg = "Failed to reload caddy: " + str(e)
    return redirect(url_for('dashboard', msg=msg))

@app.route('/project/remove/<int:pid>', methods=['POST'])
def remove_project(pid):
    with ensure_user() as (db, user):
        proj = db.query(Project).get(pid)
        if proj and proj.user_id == user.id:
            db.delete(proj)
            db.commit()
            container = caddy.ensure_container(user)
            msg = caddy.reload_for_user(user, container)
            return redirect(url_for('dashboard', msg=msg))
    return redirect(url_for('dashboard'))

@app.route('/cleanup')
def cleanup_users():
    if request.remote_addr == socket.gethostbyname("traefik"):
        return "Unauthorized"
    with get_db() as db:
        limit = datetime.utcnow() - timedelta(minutes=10)
        old_users = db.query(User).filter(User.created_at < limit).all()
        logs = []
        for u in old_users:
            projects = list(u.projects)
            if not u.is_premium:
                caddy.delete_container(u)
                for p in projects:
                    db.delete(p)
                db.delete(u)
                logs.append(f"Removed: {u}, {projects}")
            else:
                caddy.ensure_container(u, reload_on_create=True)
                logs.append(f"Kept: {u}, {projects}")
        db.commit()
    return "\n".join(logs), 200, {'Content-Type': 'text/plain'}

if __name__ == '__main__':
    app.run(host='0.0.0.0')
