import os
import requests
from fastapi import FastAPI, File, UploadFile, Request, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.templating import Jinja2Templates
import aiofiles

app = FastAPI(title="BrokenBot", description="BrokenBot Firmware Upload System", openapi_url=None, docs_url=None, redoc_url=None)

UPLOAD_FOLDER = 'uploads'
MAX_CONTENT_LENGTH = 16 * 1024 * 1024
VALIDATOR_URL = os.getenv('VALIDATOR_URL', 'http://validator:5001')
EXECUTOR_URL = os.getenv('EXECUTOR_URL', 'http://executor:5002')

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

templates = Jinja2Templates(directory="templates")


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/health")
async def health():
    try:
        validator_health = requests.get(f"{VALIDATOR_URL}/health", timeout=5)
        validator_status = validator_health.json() if validator_health.status_code == 200 else {'status': 'unhealthy'}

        executor_health = requests.get(f"{EXECUTOR_URL}/health", timeout=5)
        executor_status = executor_health.json() if executor_health.status_code == 200 else {'status': 'unhealthy'}

        return {
            'web_interface': {'status': 'healthy'},
            'validator': validator_status,
            'executor': executor_status
        }
    except Exception as e:
        return {
            'web_interface': {'status': 'healthy'},
            'validator': {'status': 'error', 'message': str(e)},
            'executor': {'status': 'error', 'message': str(e)}
        }


@app.get("/download_sample")
async def download_sample():
    jar_path = "sample_firmware/BrokenBot.jar"
    if os.path.exists(jar_path):
        return FileResponse(jar_path, filename='brokenbot_sample.jar')
    else:
        raise HTTPException(status_code=404, detail="Sample file not found")


@app.post("/upload")
async def upload_firmware(file: UploadFile = File(...), request: Request = None):
    if not file.filename:
        raise HTTPException(status_code=400, detail="Файл не выбран")

    if not file.filename.endswith('.jar'):
        raise HTTPException(status_code=400, detail="Поддерживаются только JAR файлы")

    file_content = await file.read()
    file_size = len(file_content)
    if file_size > MAX_CONTENT_LENGTH:
        raise HTTPException(status_code=413, detail="Файл слишком большой")

    filename = file.filename
    filepath = os.path.join(UPLOAD_FOLDER, filename)

    async with aiofiles.open(filepath, 'wb') as f:
        await f.write(file_content)

    try:
        with open(filepath, 'rb') as f:
            files = {'file': (filename, f, 'application/java-archive')}
            response = requests.post(f"{VALIDATOR_URL}/validate", files=files)

        if response.status_code != 200:
            raise HTTPException(status_code=500, detail="Ошибка валидации")

        validation_result = response.json()

        if not validation_result.get('success'):
            return validation_result

        validated_filename = validation_result.get('validated_file')

        if validated_filename:
            execution_response = requests.get(f"{EXECUTOR_URL}/execute/{validated_filename}")

            if execution_response.status_code == 200:
                return execution_response.json()
            else:
                raise HTTPException(status_code=500, detail="Ошибка выполнения")

        raise HTTPException(status_code=500, detail="Неизвестная ошибка")

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка обработки: {str(e)}")
    finally:
        if os.path.exists(filepath):
            os.remove(filepath)


@app.get("/validated_files")
async def list_validated_files():
    try:
        response = requests.get(f"{EXECUTOR_URL}/list_validated")
        return response.json()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка получения списка: {str(e)}")