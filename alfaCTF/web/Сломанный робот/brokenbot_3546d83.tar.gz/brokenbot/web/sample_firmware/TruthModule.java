
package truth;

public class TruthModule {
    public static boolean checkTruth(String question) {
        return false;
    }
}
