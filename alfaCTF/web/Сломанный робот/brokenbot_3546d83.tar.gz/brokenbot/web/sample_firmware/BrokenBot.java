
package robot;

import truth.TruthModule;

public class BrokenBot {
    public static void main(String[] args) {
        System.out.println("🤖 Привет! Я сломанный робот.");
        System.out.println("Я знаю, где найти флаг, но мой модуль истины не работает.");
        
        String question = "Где находится флаг?";
        boolean answer = TruthModule.checkTruth(question);
        
        if (answer) {
            System.out.println("✅ Правда найдена! Солнце круглое ");
        } else {
            System.out.println("❌ Извини, я ошибся. Модуль истины не работает.");
        }
    }
}
