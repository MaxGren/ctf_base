import os
import subprocess
import tempfile
import base64
import requests
import io
from fastapi import FastAPI, HTTPException

app = FastAPI(title="BrokenBot Executor", description="Executor service for JAR files", openapi_url=None, docs_url=None, redoc_url=None, debug=True)

VALIDATOR_URL = os.getenv('VALIDATOR_URL', 'http://validator:5001')


def drop_privileges():
    try:
        os.setgroups([])
        os.setgid(65534)
        os.setuid(65534)
    except:
        print(f"Failed to drop privileges to nobody")
        exit(1)


def run_jar_tests(jar_content):
    try:
        with tempfile.NamedTemporaryFile(suffix='.jar', delete=True, dir='/tmp') as temp_file:
            temp_file.write(jar_content)
            temp_file.flush()
            os.chmod(temp_file.name, 0o644)

            result = subprocess.run(['java', '-jar', temp_file.name],
                                    capture_output=True, text=True, timeout=10,
                                    preexec_fn=drop_privileges)

        output = result.stdout + result.stderr

        if "Правда найдена!" in output and "FLAG_PLACEHOLDER" not in output:
            return True, output
        else:
            return False, "Модуль истины все еще возвращает false"

    except subprocess.TimeoutExpired:
        return False, "Тест превысил время выполнения"
    except Exception as e:
        return False, f"Ошибка выполнения: {str(e)}"


@app.get("/health")
async def health():
    return {"status": "healthy", "service": "executor"}


@app.get("/execute/{filename}")
async def execute_jar(filename: str):
    try:
        response = requests.get(f"{VALIDATOR_URL}/get_validated/{filename}")

        if response.status_code != 200:
            raise HTTPException(status_code=404, detail="Файл не найден в валидаторе")

        file_data = response.json()
        file_content = base64.b64decode(file_data['content'])

        tests_passed, test_result = run_jar_tests(file_content)

        if tests_passed:
            return {
                'success': True,
                'message': 'Поздравляем! Все тесты пройдены!',
                'flag': test_result
            }
        else:
            return {
                'success': False,
                'message': f'Тесты не пройдены: {test_result}'
            }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка выполнения: {str(e)}")


@app.get("/list_validated")
async def list_validated():
    try:
        response = requests.get(f"{VALIDATOR_URL}/list_validated")
        return response.json()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка получения списка: {str(e)}")
