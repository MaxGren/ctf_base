import os
import shutil
import base64

import uvicorn
from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from pyjarsigner import JarVerifier

app = FastAPI(title="BrokenBot Validator", description="Validator service for JAR files", openapi_url=None, docs_url=None, redoc_url=None)

UPLOAD_FOLDER = 'uploads'
VALIDATED_FOLDER = 'validated'
MAX_CONTENT_LENGTH = 16 * 1024 * 1024


EXPECTED_FINGERPRINT = os.getenv('EXPECTED_FINGERPRINT', '861d21eb090cabc0398ca746d1f8e703d1b9638998d930859fc16484f1dc03eb')

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(VALIDATED_FOLDER, exist_ok=True)


def check_jar_signature(jar_path):
    verifier = JarVerifier()
    result = verifier.verify_jar(jar_path)
    return result.is_valid, result.signatures, result.signer_cert_fingerprints

@app.get("/health")
async def health():
    return {"status": "healthy", "service": "validator"}


@app.post("/validate")
async def validate_jar(
        file: UploadFile = File(...)
):
    if not file.filename:
        raise HTTPException(status_code=400, detail="Файл не выбран")

    if not file.filename.endswith('.jar'):
        raise HTTPException(status_code=400, detail="Поддерживаются только JAR файлы")

    file_content = await file.read()
    file_size = len(file_content)
    if file_size > MAX_CONTENT_LENGTH:
        raise HTTPException(status_code=413, detail="Файл слишком большой")

    filename = file.filename
    filepath = os.path.join(UPLOAD_FOLDER, filename)

    try:
        with open(filepath, 'wb') as f:
            f.write(file_content)

        is_signed, signatures, fingerprints = check_jar_signature(filepath)

        if not is_signed:
            return {
                'success': False,
                'message': f'Проверка подписи не пройдена: JAR файл не подписан или подпись недействительна'
            }


        if not fingerprints:
            return {
                'success': False,
                'message': 'Не удалось извлечь отпечаток сертификата подписчика'
            }

        actual_fingerprint = fingerprints[0]
        if actual_fingerprint != EXPECTED_FINGERPRINT:
            return {
                'success': False,
                'message': f'Отпечаток сертификата не совпадает. Ожидается: {EXPECTED_FINGERPRINT}, получено: {actual_fingerprint}'
            }

        validated_path = os.path.join(VALIDATED_FOLDER, filename)
        shutil.move(filepath, validated_path)

        return {
            'success': True,
            'message': 'JAR файл прошел валидацию и проверку подписи',
            'validated_file': filename,
            'fingerprint': actual_fingerprint
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка обработки: {str(e)}")
    finally:
        if os.path.exists(filepath):
            os.remove(filepath)


@app.get("/list_validated")
async def list_validated():
    try:
        files = os.listdir(VALIDATED_FOLDER)
        return {
            'validated_files': files
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка получения списка: {str(e)}")


@app.get("/get_validated/{filename}")
async def get_validated_file(filename: str):
    try:
        filepath = os.path.join(VALIDATED_FOLDER, filename)
        if not os.path.exists(filepath):
            raise HTTPException(status_code=404, detail="Файл не найден")

        with open(filepath, 'rb') as f:
            file_content = f.read()

        return {
            'filename': filename,
            'content': base64.b64encode(file_content).decode('utf-8')
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка получения файла: {str(e)}")

if __name__ == '__main__':
    uvicorn.run(app, host='0.0.0.0', port=8000)