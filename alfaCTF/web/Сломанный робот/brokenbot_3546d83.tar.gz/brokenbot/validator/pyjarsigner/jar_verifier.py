#!/usr/bin/env python3
"""
JAR Verifier - Python implementation of JAR signature verification
Based on OpenJDK's JarSigner functionality
"""

import os
import sys
import zipfile
import hashlib
import base64
import struct
import subprocess
import tempfile
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from pathlib import Path
import logging


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class JarVerifierException(Exception):
    
    pass


@dataclass
class SignatureInfo:
    
    signature_file: str
    signature_block_file: str
    signer_certificate: Optional[bytes] = None
    signer_fingerprint_sha256: Optional[str] = None
    signature_algorithm: Optional[str] = None
    digest_algorithm: Optional[str] = None
    manifest_digest: Optional[bytes] = None
    signature_bytes: Optional[bytes] = None


@dataclass
class VerificationResult:
    
    is_valid: bool
    errors: List[str]
    warnings: List[str]
    signatures: List[SignatureInfo]
    manifest_entries: Dict[str, Dict[str, str]]
    signer_cert_fingerprints: List[str] = None  


class JarVerifier:
    
    def __init__(self):
        self.manifest_name = "META-INF/MANIFEST.MF"
        self.signature_suffix = ".SF"
        self.signature_block_suffix = ".RSA"
        self.signature_block_suffix_ec = ".EC"
        self.signature_block_suffix_dsa = ".DSA"
        
    def verify_jar(self, jar_path: str, verbose: bool = False) -> VerificationResult:
        errors = []
        warnings = []
        signatures = []
        manifest_entries = {}
        
        try:
            if not os.path.exists(jar_path):
                raise JarVerifierException(f"JAR file not found: {jar_path}")
            
            if verbose:
                logger.info(f"Verifying JAR file: {jar_path}")
            
            with zipfile.ZipFile(jar_path, 'r') as jar:
                
                if not self._is_jar_signed(jar):
                    
                    return VerificationResult(
                        is_valid=False,
                        errors=["JAR file is not signed"],
                        warnings=[],
                        signatures=[],
                        manifest_entries={},
                        signer_cert_fingerprints=[]
                    )
                
                
                
                manifest_bytes = self._read_manifest_bytes(jar)
                manifest_entries = self._parse_manifest(manifest_bytes.decode('utf-8', errors='replace'))
                if verbose:
                    logger.info(f"Found {len(manifest_entries)} manifest entries")
                    logger.info(f"Manifest entries: {list(manifest_entries.keys())}")
                
                
                signature_files = self._find_signature_files(jar)
                if verbose:
                    logger.info(f"Found {len(signature_files)} signature files")
                
                
                for sig_file in signature_files:
                    try:
                        sig_info = self._verify_signature(jar, sig_file, manifest_entries, manifest_bytes)
                        signatures.append(sig_info)
                    except Exception as e:
                        errors.append(f"Signature verification failed for {sig_file}: {str(e)}")
                
                
                manifest_errors = self._verify_manifest_integrity(jar, manifest_entries)
                errors.extend(manifest_errors)
                
                
                
                unsigned_errors = self._check_unsigned_entries_errors(jar, manifest_entries)
                errors.extend(unsigned_errors)
            
            is_valid = len(errors) == 0
            
            if verbose:
                if is_valid:
                    logger.info("JAR verification completed successfully")
                else:
                    logger.error(f"JAR verification failed with {len(errors)} errors")
            
            return VerificationResult(
                is_valid=is_valid,
                errors=errors,
                warnings=warnings,
                signatures=signatures,
                manifest_entries=manifest_entries,
                signer_cert_fingerprints=[s.signer_fingerprint_sha256 for s in signatures if s.signer_fingerprint_sha256]
            )
            
        except Exception as e:
            raise JarVerifierException(f"JAR verification failed: {str(e)}")
    
    def _normalize_name(self, n: str) -> str:
        
        if n.startswith("./"):
            n = n[2:]
        if n.startswith("/"):
            n = n[1:]
        return n

    def _is_signing_related(self, name: str) -> bool:
        u = name.upper()
        if u == "META-INF/MANIFEST.MF":
            return True
        if u.startswith("META-INF/"):
            if u.endswith(".SF"):
                return True
            if u.endswith(".RSA") or u.endswith(".DSA") or u.endswith(".EC"):
                return True
            if u.startswith("META-INF/SIG-"):
                return True
        return False

    def _lookup_jar_entry(self, jar: zipfile.ZipFile, name: str) -> Optional[str]:
        
        
        try:
            jar.getinfo(name)
            return name
        except KeyError:
            pass
        
        for candidate in ("./" + name, "/" + name):
            try:
                jar.getinfo(candidate)
                return candidate
            except KeyError:
                continue
        
        target = self._normalize_name(name)
        for candidate in jar.namelist():
            if self._normalize_name(candidate) == target:
                return candidate
        return None
    
    def _is_jar_signed(self, jar: zipfile.ZipFile) -> bool:
        
        try:
            
            jar.getinfo(self.manifest_name)
            
            
            for name in jar.namelist():
                if name.upper().startswith("META-INF/") and name.upper().endswith(self.signature_suffix):
                    return True
            return False
        except KeyError:
            return False

    def _read_manifest_bytes(self, jar: zipfile.ZipFile) -> bytes:
        
        
        try:
            return jar.read(self.manifest_name)
        except Exception as e:
            raise JarVerifierException(f"Failed to read manifest: {str(e)}")
    
    def _parse_manifest(self, manifest_data: str) -> Dict[str, Dict[str, str]]:
        
        entries = {}
        current_entry = None
        current_attrs = {}
        
        lines = manifest_data.split('\n')
        i = 0
        
        while i < len(lines):
            line = lines[i].rstrip('\r\n')
            
            if not line:
                
                if current_entry and current_attrs:
                    entries[current_entry] = current_attrs
                    current_attrs = {}
                current_entry = None
            elif line.startswith(' '):
                
                if current_entry:
                    
                    last_key = list(current_attrs.keys())[-1]
                    current_attrs[last_key] += line[1:]
            else:
                
                if ':' in line:
                    key, value = line.split(':', 1)
                    key = key.rstrip()
                    value = value.lstrip()
                    
                    if key == "Name":
                        
                        if current_entry and current_attrs:
                            entries[current_entry] = current_attrs
                        
                        current_entry = self._normalize_name(value)
                        current_attrs = {}
                    elif current_entry is None:
                        
                        current_entry = key
                        current_attrs[key] = value
                    else:
                        
                        current_attrs[key] = value
            
            i += 1
        
        
        if current_entry and current_attrs:
            entries[current_entry] = current_attrs
        
        return entries
    
    def _find_signature_files(self, jar: zipfile.ZipFile) -> List[str]:
        
        signature_files = []
        
        for name in jar.namelist():
            if name.upper().startswith("META-INF/") and name.upper().endswith(self.signature_suffix):
                signature_files.append(name)
        
        return signature_files
    
    def _verify_signature(self, jar: zipfile.ZipFile, sig_file: str, 
                         manifest_entries: Dict[str, Dict[str, str]],
                         manifest_bytes: bytes) -> SignatureInfo:
        
        try:
            
            sig_raw = jar.read(sig_file)
            
            
            base_name = sig_file[:-len(self.signature_suffix)]
            block_file = None
            
            for suffix in [self.signature_block_suffix, self.signature_block_suffix_ec, 
                          self.signature_block_suffix_dsa]:
                potential_block = base_name + suffix
                try:
                    jar.getinfo(potential_block)
                    block_file = potential_block
                    break
                except KeyError:
                    continue
            
            if not block_file:
                raise JarVerifierException(f"No signature block file found for {sig_file}")
            
            
            block_data = jar.read(block_file)
            
            
            sig_info, sf_manifest_digests, sf_mainattrs_digests, sf_entry_digests = self._parse_signature_file(sig_raw, manifest_bytes)
            sig_info.signature_file = sig_file
            sig_info.signature_block_file = block_file
            
            
            
            if len(block_data) == 0:
                raise JarVerifierException(f"Empty signature block file: {block_file}")
            if not self._looks_like_pkcs7_signed_data(block_data):
                raise JarVerifierException(
                    f"Malformed signature block (not PKCS#7 SignedData): {block_file}"
                )

            
            
            if not self._openssl_cms_verify(block_data, sig_raw):
                raise JarVerifierException(
                    f"Cannot verify signature block content against {sig_file}"
                )

            
            try:
                algs = self._extract_cms_algs(block_data)
                self._enforce_algorithm_constraints(algs)
            except JarVerifierException as e:
                raise
            except Exception:
                
                pass

            
            man = manifest_bytes
            eol = b"\r\n" if b"\r\n" in man else b"\n"
            
            parts = man.split(eol + b"" + eol, 1)
            if len(parts) == 1:
                man_main, man_rest = parts[0], b""
            else:
                man_main, man_rest = parts

            def digest_ok(alg: str, data: bytes, expected: bytes) -> bool:
                hname = self._hash_algo(alg)
                h = hashlib.new(hname)
                h.update(data)
                return h.digest() == expected

            
            for alg, exp in sf_mainattrs_digests.items():
                if not digest_ok(alg, man_main + eol + eol, exp):
                    raise JarVerifierException("Manifest main attributes digest mismatch")

            
            for alg, exp in sf_manifest_digests.items():
                if not digest_ok(alg, man, exp):
                    raise JarVerifierException("Manifest digest mismatch")

            
            man_sections: Dict[str, bytes] = {}
            if man_rest:
                for sec in man_rest.split(eol + b"" + eol):
                    if not sec.strip():
                        continue
                    
                    lines = sec.split(eol)
                    name_val_bytes = b""
                    got_name = False
                    for raw in lines:
                        if raw.startswith(b"Name:") and not got_name:
                            
                            _, v = raw.split(b":", 1)
                            name_val_bytes = v.strip()
                            got_name = True
                        elif raw.startswith(b" ") and got_name and name_val_bytes is not None:
                            name_val_bytes += raw[1:]
                        elif got_name:
                            
                            break
                    if got_name:
                        try:
                            name = name_val_bytes.decode('utf-8', errors='replace')
                        except Exception:
                            continue
                        man_sections[self._normalize_name(name)] = sec

            
            for name, digmap in sf_entry_digests.items():
                norm = self._normalize_name(name)
                if norm not in man_sections:
                    raise JarVerifierException(f"SF references unknown manifest entry: {name}")
                sec_bytes = man_sections[norm]
                
                for alg, exp in digmap.items():
                    
                    if not digest_ok(alg, sec_bytes + eol + eol, exp):
                        raise JarVerifierException(f"SF digest mismatch for entry {name}")

            
            
            if not sf_manifest_digests:
                covered = {self._normalize_name(n) for n in sf_entry_digests.keys()}
                required = {n for n in man_sections.keys() if not self._is_signing_related(n)}
                if covered != required:
                    missing = sorted(required - covered)
                    extra = sorted(covered - required)
                    detail = []
                    if missing:
                        detail.append("missing: " + ", ".join(missing))
                    if extra:
                        detail.append("unexpected: " + ", ".join(extra))
                    raise JarVerifierException(
                        "Signature file does not cover entire manifest; " + "; ".join(detail)
                    )

            
            signer_der = self._extract_signer_cert_from_block(block_data)
            if signer_der:
                sig_info.signer_certificate = signer_der
                fp = hashlib.sha256(signer_der).hexdigest()
                sig_info.signer_fingerprint_sha256 = fp

            return sig_info
            
        except Exception as e:
            raise JarVerifierException(f"Signature verification failed: {str(e)}")
    
    def _parse_signature_file(self, sig_data: bytes, manifest_bytes: bytes) -> Tuple[SignatureInfo, Dict[str, bytes], Dict[str, bytes], Dict[str, Dict[str, bytes]]]:
        
        
        sig_info = SignatureInfo("", "")

        sf = sig_data
        eol = b"\r\n" if b"\r\n" in sf else b"\n"
        
        parts = sf.split(eol + b"" + eol, 1)
        if len(parts) == 1:
            main_part, rest = parts[0], b""
        else:
            main_part, rest = parts

        def parse_attrs(block: bytes) -> Dict[str, str]:
            out: Dict[str, str] = {}
            last_key: Optional[str] = None
            for raw_line in block.split(eol):
                line = raw_line.rstrip(b"\r\n")
                if not line:
                    continue
                if line.startswith(b" ") and last_key is not None:
                    out[last_key] = out[last_key] + line[1:].decode('utf-8', errors='replace')
                    continue
                if b":" in line:
                    k, v = line.split(b":", 1)
                    key = k.decode('utf-8', errors='replace').strip()
                    val = v.decode('utf-8', errors='replace').strip()
                    out[key] = val
                    last_key = key
            return out

        
        main_attrs = parse_attrs(main_part)
        manifest_digests: Dict[str, bytes] = {}
        mainattrs_digests: Dict[str, bytes] = {}
        for k, v in main_attrs.items():
            if k.endswith("-Digest-Manifest") and len(k.split("-")) >= 2:
                alg = k[: k.rfind("-Digest-Manifest")]
                try:
                    manifest_digests[alg.upper()] = base64.b64decode(v)
                except Exception:
                    pass
            elif k.endswith("-Digest-Manifest-Main-Attributes") and len(k.split("-")) >= 2:
                alg = k[: k.rfind("-Digest-Manifest-Main-Attributes")]
                try:
                    mainattrs_digests[alg.upper()] = base64.b64decode(v)
                except Exception:
                    pass

        
        entry_digests: Dict[str, Dict[str, bytes]] = {}
        if rest:
            for sec in rest.split(eol + b"" + eol):
                if not sec.strip():
                    continue
                attrs = parse_attrs(sec)
                if 'Name' not in attrs:
                    
                    continue
                name = attrs['Name']
                digests: Dict[str, bytes] = {}
                for kk, vv in attrs.items():
                    if kk.endswith("-Digest"):
                        alg = kk[: kk.rfind("-Digest")]
                        try:
                            digests[alg.upper()] = base64.b64decode(vv)
                        except Exception:
                            continue
                entry_digests[name] = digests

        return sig_info, manifest_digests, mainattrs_digests, entry_digests

    def _looks_like_pkcs7_signed_data(self, data: bytes) -> bool:
        if not data or data[0] != 0x30:
            return False
        signed_data_oid = b"\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x07\x02"
        return signed_data_oid in data

    def _extract_cms_algs(self, block_der: bytes) -> Dict[str, Any]:
        out: Dict[str, Any] = {
            "digest_algs": set(),
            "sig_algs": set(),
            "pubkey_algo": None,
            "pubkey_bits": None,
            "cert_not_before": None,
            "cert_not_after": None,
        }
        try:
            with tempfile.NamedTemporaryFile(delete=False) as f_block:
                f_block.write(block_der)
                f_block.flush()
                
                cmd = ["openssl", "cms", "-cmsout", "-print", "-inform", "DER", "-in", f_block.name]
                p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                if p.returncode == 0:
                    txt = p.stdout
                    ctx = None  
                    for line in txt.splitlines():
                        ls = line.strip()
                        lsl = ls.lower()
                        if lsl.startswith("digestalgorithms:") or lsl.startswith("digestalgorithm:"):
                            ctx = "DIGEST"
                            
                            continue
                        if lsl.startswith("signaturealgorithm:"):
                            ctx = "SIGNATURE"
                            continue
                        if lsl.startswith("algorithm:"):
                            try:
                                val = ls.split(":", 1)[1].strip()
                            except Exception:
                                val = ""
                            if ctx == "DIGEST" and val:
                                out["digest_algs"].add(val.upper())
                            if ctx == "SIGNATURE" and val:
                                out["sig_algs"].add(val.upper())
                        
                        if lsl.startswith("signedattrs:") or lsl.startswith("signature:") or lsl.startswith("certificates:"):
                            ctx = None
                
                signer_der = self._extract_signer_cert_from_block(block_der)
                if signer_der:
                    with tempfile.NamedTemporaryFile(delete=False) as f_cert:
                        f_cert.write(signer_der)
                        f_cert.flush()
                        
                        p2 = subprocess.run(["openssl", "x509", "-noout", "-text", "-inform", "DER", "-in", f_cert.name],
                                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                        if p2.returncode == 0:
                            t = p2.stdout
                            algo = None
                            bits = None
                            for line in t.splitlines():
                                ls = line.strip()
                                if ls.startswith("Public Key Algorithm:"):
                                    algo = ls.split(":", 1)[1].strip().upper()
                                if ls.startswith("Public-Key:") and "(" in ls and ")" in ls:
                                    
                                    try:
                                        bstr = ls.split("(", 1)[1].split(" ", 1)[0]
                                        bits = int(bstr)
                                    except Exception:
                                        pass
                                if ls.startswith("Not Before:"):
                                    out["cert_not_before"] = ls.split(":", 1)[1].strip()
                                if ls.startswith("Not After :"):
                                    out["cert_not_after"] = ls.split(":", 1)[1].strip()
                            if algo:
                                out["pubkey_algo"] = algo
                            if bits:
                                out["pubkey_bits"] = bits
        except FileNotFoundError:
            return out
        except Exception:
            return out
        return out

    def _enforce_algorithm_constraints(self, algs: Dict[str, Any]) -> None:
        digest_algs = {a for a in algs.get("digest_algs", set())}
        sig_algs = {a for a in algs.get("sig_algs", set())}
        pubkey_algo = (algs.get("pubkey_algo") or "").upper()
        pubkey_bits = algs.get("pubkey_bits")

        disabled_digests = {"MD5", "MD2", "SHA1"}
        if any(any(d in a for d in disabled_digests) for a in digest_algs):
            raise JarVerifierException("Disabled or legacy digest algorithm used in signature")
        if any("MD5" in a or "DSA" in a for a in sig_algs):
            raise JarVerifierException("Disabled or legacy signature algorithm used (MD5/DSA)")

        
        if pubkey_algo.startswith("RSA") and isinstance(pubkey_bits, int) and pubkey_bits < 1024:
            raise JarVerifierException("RSA key size too small (<1024 bits)")
        if pubkey_algo.startswith("DSA"):
            
            raise JarVerifierException("DSA keys are disabled for jar signatures")

    def _openssl_cms_verify(self, block_der: bytes, sf_bytes: bytes) -> bool:
        try:
            with tempfile.NamedTemporaryFile(delete=False) as f_block, \
                 tempfile.NamedTemporaryFile(delete=False) as f_sf, \
                 tempfile.NamedTemporaryFile(delete=False) as f_out:
                f_block.write(block_der)
                f_block.flush()
                f_sf.write(sf_bytes)
                f_sf.flush()
                
                
                
                cmd = [
                    "openssl", "cms", "-verify",
                    "-inform", "DER",
                    "-in", f_block.name,
                    "-content", f_sf.name,
                    "-noverify",
                    "-out", f_out.name
                ]
                proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                return proc.returncode == 0
        except FileNotFoundError:
            
            return len(block_der) > 0
        except Exception:
            return False

    def _extract_signer_cert_from_block(self, block_der: bytes) -> Optional[bytes]:
        try:
            with tempfile.NamedTemporaryFile(delete=False) as f_block:
                f_block.write(block_der)
                f_block.flush()
                
                cmd = [
                    "openssl", "pkcs7", "-inform", "DER",
                    "-in", f_block.name,
                    "-print_certs",
                ]
                proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                if proc.returncode != 0:
                    return None
                pem_bundle = proc.stdout.decode('utf-8', errors='replace')
                
                begin = "-----BEGIN CERTIFICATE-----"
                end = "-----END CERTIFICATE-----"
                if begin in pem_bundle and end in pem_bundle:
                    first = pem_bundle.split(begin, 1)[1]
                    base64_part = first.split(end, 1)[0]
                    b64 = "".join(base64_part.strip().splitlines())
                    import base64 as _b64
                    return _b64.b64decode(b64)
                return None
        except FileNotFoundError:
            return None
        except Exception:
            return None
    
    def _hash_algo(self, alg: str):
        a = alg.strip().upper().replace('_', '-').replace('/', '-')
        mapping = {
            'SHA-1': 'sha1', 'SHA1': 'sha1',
            'SHA-224': 'sha224', 'SHA224': 'sha224',
            'SHA-256': 'sha256', 'SHA256': 'sha256',
            'SHA-384': 'sha384', 'SHA384': 'sha384',
            'SHA-512': 'sha512', 'SHA512': 'sha512',
            'MD5': 'md5',
        }
        name = mapping.get(a)
        if not name:
            
            name = a.lower().replace('-', '')
        try:
            hashlib.new(name)
            return name
        except Exception:
            raise JarVerifierException(f"Unsupported digest algorithm: {alg}")
    
    def _verify_manifest_integrity(self, jar: zipfile.ZipFile, 
                                 manifest_entries: Dict[str, Dict[str, str]]) -> List[str]:
        
        errors = []
        
        for entry_name, entry_attrs in manifest_entries.items():
            if entry_name == 'Manifest-Version':
                continue  
            
            
            actual_name = self._lookup_jar_entry(jar, entry_name)
            if actual_name is None:
                errors.append(f"Manifest entry references non-existent file: {entry_name}")
                continue
            
            
            
            digest_keys = [k for k in entry_attrs.keys() if k.endswith('-Digest')]
            if not digest_keys:
                errors.append(f"Manifest entry missing digest: {entry_name}")
                continue
            try:
                data = jar.read(actual_name)
            except Exception as e:
                errors.append(f"Failed to read entry {entry_name}: {e}")
                continue
            mismatch = True
            for k in digest_keys:
                alg = k[: k.rfind('-Digest')]
                try:
                    hname = self._hash_algo(alg)
                    h = hashlib.new(hname)
                    h.update(data)
                    actual_b64 = base64.b64encode(h.digest()).decode('ascii')
                    expected_b64 = entry_attrs[k]
                    if actual_b64 == expected_b64:
                        mismatch = False
                        break
                except JarVerifierException:
                    
                    continue
            if mismatch:
                errors.append(f"Digest mismatch for {entry_name}")

        return errors

    def _check_unsigned_entries_errors(self, jar: zipfile.ZipFile, 
                              manifest_entries: Dict[str, Dict[str, str]]) -> List[str]:
        
        errors: List[str] = []
        
        covered = {self._normalize_name(n) for n in manifest_entries.keys() if n != 'Manifest-Version'}
        for name in jar.namelist():
            
            try:
                info = jar.getinfo(name)
                if (name.endswith('/') or getattr(info, 'is_dir', lambda: False)()) and info.file_size and info.file_size > 0:
                    errors.append(f"Directory entry has non-zero size: {name}")
            except KeyError:
                pass

            if self._is_signing_related(name):
                continue
            if name.endswith('/'):
                
                continue
            if self._normalize_name(name) not in covered:
                errors.append(f"Unsigned entry found: {name}")
        return errors


def main():
    
    if len(sys.argv) < 2:
        print("Usage: python jar_verifier.py <jar_file> [--verbose]")
        sys.exit(1)
    
    jar_path = sys.argv[1]
    verbose = "--verbose" in sys.argv
    
    verifier = JarVerifier()
    
    try:
        result = verifier.verify_jar(jar_path, verbose)
        
        print(f"\nJAR Verification Result: {'PASS' if result.is_valid else 'FAIL'}")
        
        if result.errors:
            print(f"\nErrors ({len(result.errors)}):")
            for error in result.errors:
                print(f"  - {error}")
        
        if result.warnings:
            print(f"\nWarnings ({len(result.warnings)}):")
            for warning in result.warnings:
                print(f"  - {warning}")
        
        if result.signatures:
            print(f"\nSignatures ({len(result.signatures)}):")
            for sig in result.signatures:
                print(f"  - {sig.signature_file} -> {sig.signature_block_file}")
        if result.is_valid and result.signer_cert_fingerprints:
            print("\nSigner certificate SHA-256 fingerprints:")
            for fp in result.signer_cert_fingerprints:
                print(f"  - {fp}")
        
        sys.exit(0 if result.is_valid else 1)
        
    except JarVerifierException as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()