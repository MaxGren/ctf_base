import json
import uuid
import logging
from fastapi import FastAPI, WebSocket, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import redis
import asyncio
import uvicorn
import os

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
    ]
)

logger = logging.getLogger(__name__)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

host = os.getenv("REDIS_HOST")
port = os.getenv("REDIS_PORT")
redis_client = redis.Redis(host=host, port=port, db=0)

WEAPONS = {
    "fist": 1,
    "brass_knuckles": 5,
    "baseball_bat": 10
}

def create_new_game() -> str:
    game_id = str(uuid.uuid4())
    redis_client.set(f"{game_id}:hp", 100)
    redis_client.set(f"{game_id}:stamina", 5)
    logger.info(f"New game created with ID: {game_id}")
    return game_id

def validate_game_id(game_id: str) -> bool:
    try:
        uuid_obj = uuid.UUID(game_id)
        return uuid_obj.version == 4 and redis_client.exists(f"{game_id}:hp")
    except (ValueError, AttributeError):
        return False

def get_hp(game_id: str) -> int:
    hp = redis_client.get(f"{game_id}:hp")
    return int(hp)

def get_stamina(game_id: str) -> int:
    stamina = redis_client.get(f"{game_id}:stamina")
    return int(stamina)

def decrement_stamina(game_id: str) -> int:
    return redis_client.decr(f"{game_id}:stamina")

def decrement_hp(game_id: str, damage: int) -> int:
    return redis_client.decrby(f"{game_id}:hp", damage)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()

    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            logger.info(f"Received message: {message}")
            
            if message["type"] == "new_game":
                game_id = create_new_game()
                await websocket.send_json({
                    "type": "game_created",
                    "game_id": game_id,
                    "hp": 100,
                    "stamina": 5
                })
            
            elif message["type"] == "attack":
                try:
                    game_id = message["game_id"]
                    if not validate_game_id(game_id):
                        logger.error(f"Invalid game_id format: {game_id}")
                        raise ValueError("Invalid game ID")
                except (ValueError, AttributeError):
                    logger.error(f"Invalid game_id format: {game_id}")
                    await websocket.send_json({
                        "type": "error",
                        "message": "Invalid game ID"
                    })
                    continue

                weapon = message["weapon"]
                if weapon not in WEAPONS:
                    await websocket.send_json({
                        "type": "error",
                        "message": "Invalid weapon"
                    })
                    continue

                current_stamina = get_stamina(game_id)
                current_hp = get_hp(game_id)

                if current_hp <= 0:
                    flag = os.getenv("FLAG")
                    await websocket.send_json({
                    "type": "attack_result",
                    "hp": current_hp,
                    "stamina": current_stamina,
                    "damage": 0,
                    "is_game_over": flag
                    })
                    continue

                if current_stamina <= 0:
                    logger.warning(f"[{game_id}] No stamina remaining")
                    await websocket.send_json({
                        "type": "attack_result",
                        "hp": current_hp,
                        "stamina": current_stamina,
                        "damage": 0,
                        "is_game_over": False
                    })
                    continue
                
                
                logger.info(f"[{game_id}] Attack received - Game ID: {game_id}, Weapon: {weapon}")
                damage = WEAPONS[weapon]
                
                # Decrement stamina and HP
                new_stamina = decrement_stamina(game_id)
                new_hp = decrement_hp(game_id, damage)
                
                logger.info(f"[{game_id}] Attack processed - Damage: {damage}, New HP: {new_hp}, Stamina: {new_stamina}")

                flag = False
                if new_hp <= 0:
                    flag = os.getenv("FLAG")
                await websocket.send_json({
                    "type": "attack_result",
                    "hp": new_hp,
                    "stamina": new_stamina,
                    "damage": damage,
                    "is_game_over": flag
                })
    
    except Exception as e:
        logger.error(f"WebSocket error: {str(e)}", exc_info=True)
    finally:
        await websocket.close()

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000) 
