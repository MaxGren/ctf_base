import styled, { keyframes } from 'styled-components';

const sparkAnimation = keyframes`
  0% {
    transform: scale(0);
    opacity: 1;
  }
  100% {
    transform: scale(1);
    opacity: 0;
  }
`;

const shakeAnimation = keyframes`
  0%, 100% { transform: translate(0, 0) rotate(0deg); }
  25% { transform: translate(-5px, -5px) rotate(-2deg); }
  50% { transform: translate(5px, -5px) rotate(2deg); }
  75% { transform: translate(-5px, 5px) rotate(-2deg); }
`;

const damageNumberAnimation = keyframes`
  0% {
    transform: translateY(0);
    opacity: 1;
  }
  100% {
    transform: translateY(-50px);
    opacity: 0;
  }
`;

const bossHitAnimation = keyframes`
  0% { transform: scale(1); }
  50% { transform: scale(0.95); }
  100% { transform: scale(1); }
`;

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 2rem;
  min-height: 100vh;
  background-color: #f0f0f0;
`;

export const Spark = styled.div<{ x: number; y: number; color: string }>`
  position: fixed;
  left: ${(props: { x: number; y: number; color: string }) => props.x}px;
  top: ${(props: { x: number; y: number; color: string }) => props.y}px;
  width: 20px;
  height: 20px;
  background: radial-gradient(circle, ${(props: { x: number; y: number; color: string }) => props.color} 0%, transparent 70%);
  border-radius: 50%;
  pointer-events: none;
  animation: ${sparkAnimation} 0.5s ease-out forwards;
  transform: translate(-50%, -50%);
`;

export const BossImage = styled.img<{ isHit: boolean; health: number }>`
  width: 580px;
  height: 400px;
  object-fit: cover;
  border-radius: 45%;
  margin-bottom: 2rem;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: transform 0.1s ease, filter 0.3s ease;
  animation: ${(props: { isHit: boolean }) => props.isHit ? bossHitAnimation : 'none'} 0.3s ease;
  filter: ${(props: { health: number }) => {
    const bruiseIntensity = Math.max(0, (100 - props.health) / 100);
    return `sepia(${bruiseIntensity * 30}%) hue-rotate(${bruiseIntensity * 30}deg) saturate(${1 + bruiseIntensity * 0.5}) brightness(${1 - bruiseIntensity * 0.2})`;
  }};

  &:hover {
    transform: scale(1.05);
  }

  &:active {
    transform: scale(0.95);
  }
`;

export const HealthBar = styled.div<{ health: number }>`
  width: 300px;
  height: 20px;
  background-color: #ddd;
  border-radius: 10px;
  margin-bottom: 2rem;
  overflow: hidden;
  position: relative;

  &::after {
    content: '';
    display: block;
    width: ${(props: { health: number }) => props.health}%;
    height: 100%;
    background-color: ${(props: { health: number }) => props.health > 50 ? '#4CAF50' : props.health > 25 ? '#FFC107' : '#F44336'};
    transition: all 0.3s ease;
  }
`;

export const HealthParticle = styled.div<{ x: number }>`
  position: absolute;
  bottom: 0;
  left: ${(props: { x: number }) => props.x}%;
  width: 2px;
  height: 2px;
  background-color: #ff0000;
  border-radius: 50%;
  animation: ${damageNumberAnimation} 1s ease-out forwards;
`;

export const DamageNumber = styled.div<{ x: number; y: number }>`
  position: fixed;
  left: ${(props: { x: number; y: number }) => props.x}px;
  top: ${(props: { x: number; y: number }) => props.y}px;
  color: #ff0000;
  font-size: 24px;
  font-weight: bold;
  pointer-events: none;
  animation: ${damageNumberAnimation} 1s ease-out forwards;
  transform: translate(-50%, -50%);
`;

export const WeaponsContainer = styled.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
`;

export const WeaponButton = styled.button<{ selected: boolean }>`
  padding: 1rem 2rem;
  font-size: 1.2rem;
  border: none;
  border-radius: 5px;
  background-color: ${(props: { selected: boolean }) => props.selected ? '#1976D2' : '#2196F3'};
  color: white;
  cursor: pointer;
  transition: all 0.3s ease;
  transform: ${(props: { selected: boolean }) => props.selected ? 'scale(1.1)' : 'scale(1)'};

  &:hover {
    background-color: #1976D2;
  }

  &:disabled {
    background-color: #ccc;
    cursor: not-allowed;
  }
`;

export const GameStatus = styled.div`
  font-size: 1.5rem;
  margin-bottom: 1rem;
  text-align: center;
  padding: 1rem;
  border-radius: 8px;
  background-color: rgba(255, 255, 255, 0.9);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
  }
`;

export const FlagNotification = styled(GameStatus)`
  background-color: #4CAF50;
  color: white;
  font-weight: bold;
  animation: ${shakeAnimation} 0.5s ease;
`;

export const WeaponStatus = styled(GameStatus)<{ selected: boolean }>`
  background-color: ${(props: { selected: boolean }) => props.selected ? '#e3f2fd' : 'rgba(255, 255, 255, 0.9)'};
  border: 2px solid ${(props: { selected: boolean }) => props.selected ? '#1976D2' : 'transparent'};
  color: ${(props: { selected: boolean }) => props.selected ? '#1976D2' : 'inherit'};
  font-weight: ${(props: { selected: boolean }) => props.selected ? 'bold' : 'normal'};
`;

export const CooldownText = styled.span`
  color: #f44336;
  font-weight: bold;
  animation: pulse 1s infinite;
  
  @keyframes pulse {
    0% { opacity: 1; }
    50% { opacity: 0.5; }
    100% { opacity: 1; }
  }
`;

export const GameContainer = styled.div<{ isShaking: boolean }>`
  animation: ${(props: { isShaking: boolean }) => props.isShaking ? shakeAnimation : 'none'} 0.5s ease;
`;

export const ResetButton = styled.button`
  padding: 1rem 2rem;
  font-size: 1.2rem;
  border: none;
  border-radius: 5px;
  background-color: #dc3545;
  color: white;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-top: 1rem;

  &:hover {
    background-color: #c82333;
    transform: scale(1.05);
  }

  &:active {
    transform: scale(0.95);
  }
`;

export const BackendStatus = styled.div`
  position: fixed;
  bottom: 1rem;
  right: 1rem;
  padding: 0.5rem 1rem;
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  border-radius: 4px;
  font-size: 0.9rem;
  z-index: 1000;
`; 