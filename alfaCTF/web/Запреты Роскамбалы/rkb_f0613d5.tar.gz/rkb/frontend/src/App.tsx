import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  Container,
  Spark,
  BossImage,
  HealthBar,
  HealthParticle,
  DamageNumber,
  WeaponsContainer,
  WeaponButton,
  GameStatus,
  FlagNotification,
  WeaponStatus,
  CooldownText,
  GameContainer,
  ResetButton,
  BackendStatus
} from './styles/GameStyles';

const BACKEND_SERVERS = [
  // the test deployment has just one backend, unlike the production version
  `ws://${window.location.hostname}:8101/ws`
];

const measurePing = async (url: string): Promise<number> => {
  const start = performance.now();
  try {
    const ws = new WebSocket(url);
    await new Promise((resolve, reject) => {
      ws.onopen = resolve;
      ws.onerror = reject;
      setTimeout(reject, 3000);
    });
    ws.close();
    return performance.now() - start;
  } catch (error) {
    return Infinity;
  }
};

const getBestBackend = async (): Promise<string> => {
  const pings = await Promise.all(
    BACKEND_SERVERS.map(async (url) => ({
      url,
      ping: await measurePing(url)
    }))
  );
  
  const bestServer = pings.reduce((best, current) => 
    current.ping < best.ping ? current : best
  );
  
  return bestServer.url;
};

const App: React.FC = () => {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [gameId, setGameId] = useState<string | null>(null);
  const [health, setHealth] = useState(100);
  const [stamina, setStamina] = useState(5);
  const [gameOver, setGameOver] = useState(false);
  const [flag, setFlag] = useState<string | null>(null);
  const [selectedWeapon, setSelectedWeapon] = useState<string | null>(null);
  const [sparks, setSparks] = useState<Array<{ id: number; x: number; y: number; color: string }>>([]);
  const [canAttack, setCanAttack] = useState(true);
  const [isBossHit, setIsBossHit] = useState(false);
  const [isShaking, setIsShaking] = useState(false);
  const [damageNumbers, setDamageNumbers] = useState<Array<{ id: number; x: number; y: number; value: number }>>([]);
  const [healthParticles, setHealthParticles] = useState<Array<{ id: number; x: number }>>([]);
  const [selectedBackend, setSelectedBackend] = useState<string>('');
  const [latency, setLatency] = useState<number | null>(null);

  useEffect(() => {
    const initializeWebSocket = async () => {
      const bestBackend = await getBestBackend();
      setSelectedBackend(bestBackend);
      
      const ws = new WebSocket(bestBackend);
      
      ws.onopen = () => {
        console.log('Connected to WebSocket');
        ws.send(JSON.stringify({ type: 'new_game' }));
      };

      ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        
        if (data.type === 'game_created') {
          setGameId(data.game_id);
          setHealth(data.hp);
          setStamina(data.stamina);
        } else if (data.type === 'attack_result') {
          setHealth(data.hp);
          setStamina(data.stamina);
          if (data.is_game_over) {
            setGameOver(true);
            setFlag(data.is_game_over);
          }
        } else if (data.type === 'error') {
          alert(data.message);
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
      };

      setSocket(ws);

      return () => {
        ws.close();
      };
    };

    initializeWebSocket();
  }, []);

  // Function to measure ping periodically
  const measureLatency = useCallback(async () => {
    if (!selectedBackend) return;

    try {
      const ping = await measurePing(selectedBackend);
      if (ping !== Infinity) {
        setLatency(Math.round(ping * 10) / 10);
      }
    } catch (error) {
    }
  }, [selectedBackend]);

  // Measure latency every 5 seconds when connected
  useEffect(() => {
    if (!selectedBackend) return;

    // Measure immediately
    measureLatency();

    // Set up interval for periodic measurements
    const interval = setInterval(measureLatency, 5000);

    return () => clearInterval(interval);
  }, [selectedBackend, measureLatency]);

  const handleWeaponSelect = (weapon: string) => {
    if (stamina > 0 && !gameOver) {
      setSelectedWeapon(weapon);
    }
  };

  const createHealthParticles = () => {
    const particles = Array.from({ length: 15 }, (_, i) => ({
      id: Date.now() + i,
      x: Math.random() * 100
    }));
    setHealthParticles(particles);
    setTimeout(() => setHealthParticles([]), 1000);
  };

  const handleBossClick = (event: React.MouseEvent<HTMLImageElement>) => {
    if (!selectedWeapon || !socket || !gameId || gameOver || stamina <= 0 || !canAttack) return;


    const sparkColor = selectedWeapon === 'fist' ? '#ffd700' : 
                      selectedWeapon === 'brass_knuckles' ? '#ff4500' : '#8b4513';
    const sparkId = Date.now();
    setSparks(prev => [...prev, { id: sparkId, x: event.clientX, y: event.clientY, color: sparkColor }]);
    setTimeout(() => {
      setSparks(prev => prev.filter(spark => spark.id !== sparkId));
    }, 500);

    const damage = selectedWeapon === 'fist' ? 1 : 
                  selectedWeapon === 'brass_knuckles' ? 5 : 10;
    const damageId = Date.now();
    setDamageNumbers((prev: Array<{ id: number; x: number; y: number; value: number }>) => [...prev, { id: damageId, x: event.clientX, y: event.clientY, value: damage }]);
    setTimeout(() => {
      setDamageNumbers((prev: Array<{ id: number; x: number; y: number; value: number }>) => 
        prev.filter(num => num.id !== damageId)
      );
    }, 1000);
    
    setIsBossHit(true);
    setTimeout(() => setIsBossHit(false), 300);

    if (damage >= 5) {
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 500);
    }

    createHealthParticles();

    socket.send(JSON.stringify({
      type: 'attack',
      game_id: gameId,
      weapon: selectedWeapon
    }));

    setCanAttack(false);
    setTimeout(() => {
      setCanAttack(true);
    }, 300);
  };

  const getBossCursor = () => {
    if (gameOver || stamina <= 0) return 'default';
    if (!selectedWeapon) return 'not-allowed';
    if (!canAttack) return 'wait';
    return 'pointer';
  };

  const handleReset = () => {
    if (socket) {
      socket.send(JSON.stringify({ type: 'new_game' }));
      setGameOver(false);
      setStamina(5);
      setSelectedWeapon(null);
      setSparks([]);
      setDamageNumbers([]);
      setHealthParticles([]);
    }
  };

  return (
    <GameContainer isShaking={isShaking}>
      <Container>
        {sparks.map(spark => (
          <Spark key={spark.id} x={spark.x} y={spark.y} color={spark.color} />
        ))}
        {damageNumbers.map(num => (
          <DamageNumber key={num.id} x={num.x} y={num.y}>
            -{num.value}
          </DamageNumber>
        ))}
        <BossImage 
          src="/boss.png" 
          alt="Boss" 
          onClick={handleBossClick}
          style={{ cursor: getBossCursor() }}
          isHit={isBossHit}
          health={health}
        />
        <HealthBar health={health}>
          {healthParticles.map(particle => (
            <HealthParticle key={particle.id} x={particle.x} />
          ))}
        </HealthBar>
        <GameStatus>
          Health: {health} ♥️ | Stamina: {stamina}/5 ⚡
        </GameStatus>
        <WeaponsContainer>
          <WeaponButton 
            onClick={() => handleWeaponSelect('fist')}
            disabled={gameOver || stamina <= 0}
            selected={selectedWeapon === 'fist'}
          >
            Fist (1 dmg)
          </WeaponButton>
          <WeaponButton 
            onClick={() => handleWeaponSelect('brass_knuckles')}
            disabled={gameOver || stamina <= 0}
            selected={selectedWeapon === 'brass_knuckles'}
          >
            Brass knuckles (5 dmg)
          </WeaponButton>
          <WeaponButton 
            onClick={() => handleWeaponSelect('baseball_bat')}
            disabled={gameOver || stamina <= 0}
            selected={selectedWeapon === 'baseball_bat'}
          >
            Baseball bat (10 dmg)
          </WeaponButton>
        </WeaponsContainer>
        {gameOver && (
          <>
            <GameStatus>Game Over! RosKambala is defeated!</GameStatus>
            {flag && <FlagNotification>Flag: {flag}</FlagNotification>}
          </>
        )}
        {stamina <= 0 && !gameOver && <GameStatus>No stamina remaining!</GameStatus>}
        {selectedWeapon && !gameOver && stamina > 0 && (
          <WeaponStatus selected={!!selectedWeapon}>
            Selected weapon: <strong>{selectedWeapon.replace('_', ' ')}</strong> - Attack RosKambala!
            {!canAttack && <CooldownText> (Cooldown...)</CooldownText>}
          </WeaponStatus>
        )}
        {(gameOver || stamina <= 0) && (
          <ResetButton onClick={handleReset}>
            Start new game
          </ResetButton>
        )}
        {selectedBackend && (
          <BackendStatus>
            Connected to: {selectedBackend.replace('ws://', '').replace('/ws', '')}
            {latency !== null ? ` | Latency: ${latency} ms` : ' | Latency: Measuring...'}
          </BackendStatus>
        )}
      </Container>
    </GameContainer>
  );
};

export default App;
