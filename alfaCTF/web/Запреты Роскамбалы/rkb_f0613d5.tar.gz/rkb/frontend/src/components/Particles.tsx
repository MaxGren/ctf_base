import React from 'react';
import styled, { keyframes } from 'styled-components';

const floatUp = keyframes`
  0% {
    transform: translateY(0) scale(1);
    opacity: 1;
  }
  100% {
    transform: translateY(-50px) scale(0.5);
    opacity: 0;
  }
`;

const Particle = styled.div<{ x: number; y: number; color: string; delay: number }>`
  position: fixed;
  left: ${props => props.x}px;
  top: ${props => props.y}px;
  width: 8px;
  height: 8px;
  background-color: ${props => props.color};
  border-radius: 50%;
  pointer-events: none;
  animation: ${floatUp} 1s ease-out forwards;
  animation-delay: ${props => props.delay}s;
`;

interface ParticlesProps {
  particles: Array<{
    id: number;
    x: number;
    y: number;
    color: string;
  }>;
}

export const Particles: React.FC<ParticlesProps> = ({ particles }) => {
  return (
    <>
      {particles.map((particle, index) => (
        <Particle
          key={particle.id}
          x={particle.x}
          y={particle.y}
          color={particle.color}
          delay={index * 0.1}
        />
      ))}
    </>
  );
};