from flask import Flask, request, render_template, jsonify
from os import getenv
from action import CalculateAction
import logging
from safeCalc import InvalidExpression, FunctionNotDefined, NameNotDefined, FeatureNotAvailable

PORT = getenv("PORT")
DEBUG = getenv("DEBUG")

app = Flask(__name__, static_url_path='/static')
calc = CalculateAction()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        data = request.form.get('calc')
        if not data:
            return jsonify({'result': 'Please enter an expression'})
            
        try:
            result = calc.call(data)
        except InvalidExpression as e:
            app.logger.error('Invalid expression: %s', str(e))
            return jsonify({'result': 'Invalid expression'})
        except FunctionNotDefined as e:
            app.logger.error('Function not defined: %s', str(e))
            return jsonify({'result': 'Function not allowed'})
        except NameNotDefined as e:
            app.logger.error('Name not defined: %s', str(e))
            return jsonify({'result': 'Variable not defined'})
        except FeatureNotAvailable as e:
            app.logger.error('Feature not available: %s', str(e))
            return jsonify({'result': 'Operation not allowed'})
        except Exception as e:
            app.logger.error('Unexpected error: %s', str(e))
            return jsonify({'result': 'An unexpected error occurred'})
            
        return jsonify({'result': result})
    return render_template('magazine.html')

@app.route('/vinegar')
def vinegar():
    return render_template('vinegar.html')

@app.route('/iron')
def iron():
    return render_template('iron.html')

@app.route('/telephone')
def telephone():
    return render_template('telephone.html')

@app.route('/ammonia')
def ammonia():
    return render_template('ammonia.html')

@app.route('/compass')
def compass():
    return render_template('compass.html')

@app.route('/fish-oil')
def fish_oil():
    return render_template('fish-oil.html')

@app.route('/calculator')
def calculator():
    return render_template('calculator.html')

@app.route('/ping', methods=['GET'])
def ping():
    return "OK"

if __name__ == '__main__':
    app.run(port=PORT, debug=DEBUG)
else:
    gunicorn_logger = logging.getLogger('gunicorn.error')
    app.logger.handlers = gunicorn_logger.handlers
    app.logger.setLevel(gunicorn_logger.level)
