import math
import random

def get_allowed_functions():
    """Get the dictionary of allowed functions from various modules."""
    functions = {
        **{fname: func for fname, func in math.__dict__.items() if not fname.startswith('__')},
        **{fname: func for fname, func in random.__dict__.items() if not fname.startswith('__')},
    }
    return functions 