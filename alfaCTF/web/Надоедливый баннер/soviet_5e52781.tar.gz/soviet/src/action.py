import safeCalc
from config import get_allowed_functions

class CalculateAction():
    def __init__(self, *args, **kwargs):
        self.evaluator = safeCalc.EvalWithCompoundTypes(
            functions=get_allowed_functions(),
        )
        
    def call(self, expression):
        result = self.evaluator.eval(expression)
        return result