import { API_URL, TOKEN_KEY } from './config.js';
import { loadUserClubbings } from './user.js';
import { logout } from './auth.js';
import { Modal } from './modal.js';

let joinClubbingModal;
let purchaseSuccessModal;

export function showJoinClubbingModal() {
    if (!joinClubbingModal) {
        joinClubbingModal = new Modal(document.getElementById('joinClubbingModal'));
    }
    joinClubbingModal.show();
}

export async function createClubbing(product) {
    const token = localStorage.getItem(TOKEN_KEY);

    if (!token) {
        logout();
        return;
    }

    try {
        const response = await fetch(`${API_URL}/create_clubbing`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ product })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Не удалось создать складчину');
        }

        const data = await response.json();
        Notiflix.Notify.success('Складчина успешно создана! ID: ' + data.clubbing_id);
        loadUserClubbings();
    } catch (error) {
        Notiflix.Notify.failure('Не удалось создать складчину: ' + error.message);
    }
}

export async function joinClubbing() {
    const clubbingId = document.getElementById('clubbingId').value;
    const token = localStorage.getItem(TOKEN_KEY);

    if (!token) {
        logout();
        return;
    }

    try {
        const response = await fetch(`${API_URL}/join_clubbing`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ clubbing_id: clubbingId })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Ошибка вступления в складчину');
        }

        Notiflix.Notify.success('Вы успешно вступили в складчину!');
        if (joinClubbingModal) {
            joinClubbingModal.hide();
        }
        loadUserClubbings();
    } catch (error) {
        Notiflix.Notify.failure('Ошибка: ' + error.message);
    }
}

export async function leaveClubbing(clubbingId) {
    const token = localStorage.getItem(TOKEN_KEY);

    if (!token) {
        logout();
        return;
    }

    Notiflix.Confirm.show(
        'Выход из складчины',
        'Вы уверены, что хотите покинуть эту складчину?',
        'Да',
        'Нет',
        async function okCb() {
            try {
                const response = await fetch(`${API_URL}/leave_clubbing`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({ clubbing_id: clubbingId })
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.detail || 'Failed to leave clubbing');
                }

                const data = await response.json();
                Notiflix.Notify.success(data.message);

                loadUserClubbings();
            } catch (error) {
                Notiflix.Notify.failure('Не удалось покинуть складчину: ' + error.message);
            }
        },
        function cancelCb() {
            return;
        },
    );
}

export async function purchaseClubbing(clubbingId) {
    const token = localStorage.getItem(TOKEN_KEY);
    
    if (!token) {
        logout();
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/purchase_clubbing`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ clubbing_id: clubbingId })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Не удалось приобрести продукт');
        }

        const data = await response.json();

        if (data.flag) {
            document.getElementById('success-purchase').textContent = `Поздравляем! Вы успешно приобрели продукт! Флаг: ${data.flag}`
        } else {
            document.getElementById('success-purchase').textContent = `Поздравляем! Вы успешно приобрели ${data.product}!`
        }

        if (!purchaseSuccessModal) {
            purchaseSuccessModal = new Modal(document.getElementById('purchaseSuccessModal'));
        }
        purchaseSuccessModal.show();
    } catch (error) {
        Notiflix.Notify.failure('Не удалось приобрести продукт: ' + error.message);
    }
}

export async function purchaseProduct(product) {
    const token = localStorage.getItem(TOKEN_KEY);
    
    if (!token) {
        logout();
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/purchase_product`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ product })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Не удалось приобрести продукт');
        }
        
        const data = await response.json();

        if (data.flag) {
            document.getElementById('success-purchase').textContent = `Поздравляем! Вы успешно приобрели продукт! Флаг: ${data.flag}`
        } else {
            document.getElementById('success-purchase').textContent = `Поздравляем! Вы успешно приобрели ${data.product}!`
        }

        if (!purchaseSuccessModal) {
            purchaseSuccessModal = new Modal(document.getElementById('purchaseSuccessModal'));
        }
        purchaseSuccessModal.show();
    } catch (error) {
        Notiflix.Notify.failure('Не удалось приобрести продукт: ' + error.message);
    }
}