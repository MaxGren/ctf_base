import { showUserInfo, showLoginModal, showRegisterModal, login, register, logout } from './auth.js';
import { showJoinClubbingModal, createClubbing, joinClubbing, leaveClubbing, purchaseClubbing, purchaseProduct } from './clubbing.js';
import { showRenameModal, renameUser, loadUserClubbings, loadProducts } from './user.js';
import { copyToClipboard } from './utils.js';
import { TOKEN_KEY, USERNAME_KEY } from './config.js';

const token = localStorage.getItem(TOKEN_KEY);
const username = localStorage.getItem(USERNAME_KEY);

document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('mouseover', function() {
            this.style.transform = 'translateY(-2px)';
            this.style.transition = 'transform 0.3s ease';
        });

        button.addEventListener('mouseout', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    if (token && username) {
        showUserInfo(username);
        loadUserClubbings();
        loadProducts();
    }
});

window.showLoginModal = showLoginModal;
window.showRegisterModal = showRegisterModal;
window.login = login;
window.register = register;
window.logout = logout;
window.showRenameModal = showRenameModal;
window.renameUser = renameUser;
window.showJoinClubbingModal = showJoinClubbingModal;
window.createClubbing = createClubbing;
window.joinClubbing = joinClubbing;
window.leaveClubbing = leaveClubbing;
window.purchaseClubbing = purchaseClubbing;
window.purchaseProduct = purchaseProduct;
window.copyToClipboard = copyToClipboard;
