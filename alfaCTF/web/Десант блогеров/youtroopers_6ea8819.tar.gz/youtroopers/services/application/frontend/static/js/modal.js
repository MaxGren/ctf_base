export class Modal {
    constructor(element) {
        this.element = element;
        this.overlay = null;
        this.escKeyHandler = null;
        this.overlayClickHandler = null;
        this.closeButtonHandler = null;

        const closeButton = this.element.querySelector('.modal-close');
        if (closeButton) {
            this.closeButtonHandler = () => this.hide();
            closeButton.addEventListener('click', this.closeButtonHandler);
        }
    }

    show() {
        if (!this.overlay) {
            this.overlay = document.createElement('div');
            this.overlay.className = 'modal-overlay';
            document.body.appendChild(this.overlay);
        }

        this.overlayClickHandler = (e) => {
            if (e.target === this.overlay) {
                this.hide();
            }
        };
        this.overlay.addEventListener('click', this.overlayClickHandler);

        this.escKeyHandler = (e) => {
            if (e.key === 'Escape') {
                this.hide();
            }
        };
        document.addEventListener('keydown', this.escKeyHandler);

        this.element.classList.add('show');
        this.overlay.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    hide() {
        const inputs = this.element.querySelectorAll('input');
        inputs.forEach(input => {
            input.value = '';
        });

        this.element.classList.remove('show');
        if (this.overlay) {
            this.overlay.classList.remove('show');
        }

        if (this.overlayClickHandler) {
            this.overlay.removeEventListener('click', this.overlayClickHandler);
            this.overlayClickHandler = null;
        }
        if (this.escKeyHandler) {
            document.removeEventListener('keydown', this.escKeyHandler);
            this.escKeyHandler = null;
        }

        document.body.style.overflow = '';

        setTimeout(() => {
            if (this.overlay && !this.overlay.classList.contains('show')) {
                this.overlay.remove();
                this.overlay = null;
            }
        }, 300);
    }

    destroy() {
        const closeButton = this.element.querySelector('.modal-close');
        if (closeButton && this.closeButtonHandler) {
            closeButton.removeEventListener('click', this.closeButtonHandler);
            this.closeButtonHandler = null;
        }
    }
} 