import { Modal } from './modal.js';

let imageModal;

function ensureModal() {
    if (!imageModal) {
        const modalEl = document.getElementById('imagePreviewModal');
        if (!modalEl) return null;
        imageModal = new Modal(modalEl);
    }
    return imageModal;
}

function openImagePreview(src, alt) {
    const modal = ensureModal();
    if (!modal) return;
    const img = document.getElementById('imagePreview');
    if (img) {
        img.src = src;
        img.alt = alt || 'Просмотр изображения';
    }
    modal.show();
}

function onImageClick(e) {
    const target = e.target;
    if (!(target instanceof HTMLImageElement)) return;
    if (!target.classList.contains('product-image') && !target.classList.contains('clubbing-image')) return;
    const src = target.getAttribute('src');
    const alt = target.getAttribute('alt') || '';
    if (src) openImagePreview(src, alt);
}

document.addEventListener('click', onImageClick);
