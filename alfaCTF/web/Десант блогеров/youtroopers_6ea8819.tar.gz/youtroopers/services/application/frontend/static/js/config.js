export const API_URL = '/api';
export const TOKEN_KEY = 'token';
export const USERNAME_KEY = 'username'; 
