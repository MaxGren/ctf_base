export async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        Notiflix.Notify.success('Скопировано!');
    } catch (err) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        try {
            document.execCommand('copy');
            Notiflix.Notify.success('Скопировано!');
        } catch (err) {
            Notiflix.Notify.failure('Ошибка при копировании!');
        }
        document.body.removeChild(textarea);
    }
}
