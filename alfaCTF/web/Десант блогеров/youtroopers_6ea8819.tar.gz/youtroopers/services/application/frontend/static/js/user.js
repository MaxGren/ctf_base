import { logout } from './auth.js';
import { API_URL, TOKEN_KEY, USERNAME_KEY } from './config.js';
import { Modal } from './modal.js';

let renameModal;

export function showRenameModal() {
    if (!renameModal) {
        renameModal = new Modal(document.getElementById('renameModal'));
    }
    renameModal.show();
}

export async function renameUser() {
    const newUsername = document.getElementById('newUsername').value;
    const token = localStorage.getItem(TOKEN_KEY);

    if (!token) {
        logout();
        return;
    }

    try {
        const response = await fetch(`${API_URL}/rename`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ new_username: newUsername })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Ошибка переименования');
        }

        const data = await response.json();
        localStorage.setItem(USERNAME_KEY, newUsername);
        localStorage.setItem(TOKEN_KEY, data.access_token);

        document.getElementById('username').textContent = newUsername;

        Notiflix.Notify.success(data.message);

        if (renameModal) {
            renameModal.hide();
        }
    } catch (error) {
        Notiflix.Notify.failure(error.message);
    }
}

export async function loadUserClubbings() {
    const token = localStorage.getItem(TOKEN_KEY);

    if (!token) {
        logout();
        return;
    }

    try {
        const response = await fetch(`${API_URL}/clubbings`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Ошибка загрузки складчин');
        }

        const clubbings = await response.json();
        displayClubbings(clubbings);
    } catch (error) {
        console.error('Ошибка:', error);
        logout();
    }
}

function displayClubbings(clubbings) {
    const container = document.querySelector('.clubbing-list');
    container.innerHTML = '';

    if (Array.isArray(clubbings) && clubbings.length > 0) {
        clubbings.forEach(clubbing => {
            const div = document.createElement('div');
            div.className = 'clubbing-item';
            div.innerHTML = `
                <img src="${clubbing.image}" alt="Товар" class="clubbing-image">
                <div class="clubbing-info">
                    <h3>${clubbing.product}</h3>
                    <p>Участников: ${clubbing.participants.length}</p>
                    <p class="clubbing-price">
                        <span class="total-price">${clubbing.price} $$$</span>
                        <span class="person-price">${clubbing.price_per_person} $$$/чел</span>
                    </p>
                    <div class="clubbing-actions">
                        <button class="btn-primary btn-sm" onclick="purchaseClubbing('${clubbing.clubbing_id}')">Купить</button>
                        <button class="btn-outlined btn-sm" onclick="leaveClubbing('${clubbing.clubbing_id}')">Выйти</button>
                        <button class="btn-light btn-sm" onclick="copyToClipboard('${clubbing.clubbing_id}')">
                            <i class="fas fa-copy"></i> ID
                        </button>
                    </div>
                </div>
            `;
            container.appendChild(div);
        });
    }

    const joinButton = document.createElement('div');
    joinButton.className = 'join-clubbing';
    joinButton.innerHTML = `
        <button class="btn-primary btn-full" onclick="showJoinClubbingModal()">
            <i class="fas fa-plus"></i> Вступить в складчину
        </button>
    `;
    container.appendChild(joinButton);
}

export async function loadProducts() {
    const token = localStorage.getItem(TOKEN_KEY);

    if (!token) {
        logout();
        return;
    }

    try {
        const response = await fetch(`${API_URL}/products`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            throw new Error('Ошибка загрузки продуктов');
        }

        const products = await response.json();
        const productList = document.querySelector('.product-list');
        
        if (products.length === 0) {
            productList.innerHTML = '<p class="empty-message">Нет доступных продуктов</p>';
            return;
        }

        productList.innerHTML = products.map(product => `
            <div class="product-item">
                <img src="${product.image}" alt="Товар" class="product-image">
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <p>${product.description}</p>
                    <p class="product-price">${product.price} $$$</p>
                    <div class="product-actions">
                        <button class="btn-outlined" onclick="createClubbing('${product.name}')">Создать складчину</button>
                        <button class="btn-primary" onclick="purchaseProduct('${product.name}')">Купить</button>
                    </div>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Ошибка загрузки продуктов:', error);
        document.querySelector('.product-list').innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <p>Ошибка загрузки продуктов</p>
            </div>
        `;
    }
}
