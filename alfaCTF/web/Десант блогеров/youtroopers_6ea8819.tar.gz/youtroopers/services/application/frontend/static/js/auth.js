import { API_URL, TOKEN_KEY, USERNAME_KEY } from './config.js';
import { loadUserClubbings, loadProducts } from './user.js';
import { Modal } from './modal.js';

let loginModal;
let registerModal;

export function showLoginModal() {
    if (!loginModal) {
        loginModal = new Modal(document.getElementById('loginModal'));
    }
    loginModal.show();
}

export function showRegisterModal() {
    if (!registerModal) {
        registerModal = new Modal(document.getElementById('registerModal'));
    }
    registerModal.show();
}

export async function login() {
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch(`${API_URL}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Ошибка входа');
        }

        const data = await response.json();
        localStorage.setItem(TOKEN_KEY, data.access_token);
        localStorage.setItem(USERNAME_KEY, username);

        showUserInfo(username);
        loadUserClubbings();
        loadProducts();

        if (loginModal) {
            loginModal.hide();
        }
    } catch (error) {
        Notiflix.Notify.failure(error.message);
    }
}

export async function register() {
    const username = document.getElementById('registerUsername').value;
    const password = document.getElementById('registerPassword').value;
    const recaptchaToken = grecaptcha.getResponse();

    if (!recaptchaToken) {
        Notiflix.Notify.failure('Пожалуйста, пройдите проверку reCAPTCHA');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                username, 
                password,
                recaptcha_token: recaptchaToken
            })
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Ошибка регистрации');
        }

        const data = await response.json();
        localStorage.setItem(TOKEN_KEY, data.access_token);
        localStorage.setItem(USERNAME_KEY, username);

        showUserInfo(username);
        loadUserClubbings();
        loadProducts();

        if (registerModal) {
            registerModal.hide();
        }
        grecaptcha.reset();
    } catch (error) {
        Notiflix.Notify.failure(error.message);
        grecaptcha.reset();
    }
}

export function logout() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USERNAME_KEY);
    document.getElementById('userInfo').classList.add('d-none');
    document.getElementById('usernameBlock').classList.add('d-none');
    document.getElementById('guestInfo').classList.remove('d-none');
    document.querySelector('.clubbing-list').innerHTML = `
    <div class="login-required-message">
        <i class="fas fa-lock"></i>
        <p>Войдите в учётную запись</p>
    </div>
    `;
    document.querySelector('.product-list').innerHTML = `
        <div class="login-required-message">
            <i class="fas fa-lock"></i>
            <p>Войдите в учётную запись</p>
        </div>
    `;
}

export function showUserInfo(username) {
    document.getElementById('userInfo').classList.remove('d-none');
    document.getElementById('usernameBlock').classList.remove('d-none');
    document.getElementById('guestInfo').classList.add('d-none');
    document.getElementById('username').textContent = username;
}