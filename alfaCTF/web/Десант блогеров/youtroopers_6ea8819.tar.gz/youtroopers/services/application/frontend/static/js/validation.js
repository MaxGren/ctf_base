(function() {
    function getUsernameError(username) {
        if (!username) return 'Поле должно быть заполнено';
        if (username.trim().length < 9) return 'Имя пользователя должно быть не менее 9 символов';
        if (!/^[а-яА-Яa-zA-Z0-9_-]+$/.test(username)) return 'Имя пользователя содержит недопустимые символы';
        return '';
    }

    function getPasswordError(password) {
        if (!password) return 'Поле должно быть заполнено';
        if (password.length < 6) return 'Пароль должен быть не менее 6 символов';
        if (!/[0-9]/.test(password) || !/[A-ZА-Я]/.test(password)) return 'Пароль должен содержать хотя бы одну цифру и заглавную букву';
        return '';
    }

    function setFieldState(inputEl, errorEl, errorMessage) {
        if (!inputEl || !errorEl) return;
        if (errorMessage) {
            inputEl.classList.add('input-invalid');
            errorEl.textContent = errorMessage;
        } else {
            inputEl.classList.remove('input-invalid');
            errorEl.textContent = '';
        }
    }

    function updateLoginValidation() {
        const loginUsernameInput = document.getElementById('loginUsername');
        const loginPasswordInput = document.getElementById('loginPassword');
        const loginUsernameError = document.getElementById('loginUsernameError');
        const loginPasswordError = document.getElementById('loginPasswordError');
        const loginBtn = document.getElementById('loginBtn');

        const u = (loginUsernameInput?.value || '').trim();
        const p = loginPasswordInput?.value || '';

        const uErr = getUsernameError(u);
        const pErr = getPasswordError(p);

        setFieldState(loginUsernameInput, loginUsernameError, uErr);
        setFieldState(loginPasswordInput, loginPasswordError, pErr);

        const isValid = !uErr && !pErr;
        if (loginBtn) loginBtn.disabled = !isValid;
    }

    function updateRegisterValidation() {
        const registerUsernameInput = document.getElementById('registerUsername');
        const registerPasswordInput = document.getElementById('registerPassword');
        const registerUsernameError = document.getElementById('registerUsernameError');
        const registerPasswordError = document.getElementById('registerPasswordError');
        const registerBtn = document.getElementById('registerBtn');

        const u = (registerUsernameInput?.value || '').trim();
        const p = registerPasswordInput?.value || '';

        const uErr = getUsernameError(u);
        const pErr = getPasswordError(p);

        setFieldState(registerUsernameInput, registerUsernameError, uErr);
        setFieldState(registerPasswordInput, registerPasswordError, pErr);

        const isValid = !uErr && !pErr;
        if (registerBtn) registerBtn.disabled = !isValid;
    }

    document.addEventListener('DOMContentLoaded', function() {
        const loginUsernameInput = document.getElementById('loginUsername');
        const loginPasswordInput = document.getElementById('loginPassword');
        const registerUsernameInput = document.getElementById('registerUsername');
        const registerPasswordInput = document.getElementById('registerPassword');

        if (loginUsernameInput) loginUsernameInput.addEventListener('input', updateLoginValidation);
        if (loginPasswordInput) loginPasswordInput.addEventListener('input', updateLoginValidation);
        if (registerUsernameInput) registerUsernameInput.addEventListener('input', updateRegisterValidation);
        if (registerPasswordInput) registerPasswordInput.addEventListener('input', updateRegisterValidation);

        updateLoginValidation();
        updateRegisterValidation();
    });
})();


