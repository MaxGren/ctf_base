import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    SECRET_KEY: str = os.urandom(10).hex()

    API_PREFIX: str = "/api"

    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 30)

    USERS_DIR: str = "users"
    CLUBBINGS_DIR: str = "clubbings"

    RECAPTCHA_SECRET_KEY: str = os.getenv("RECAPTCHA_SECRET_KEY", "secret-key")    

    PRODUCTS: list = [
        {
            "name": "Непромокаемый рюкзак ReefPack 30L",
            "description": "Гермозастёжка и проклеенные швы, защищённый отсек для электроники, светоотражающие элементы для вечерних прогулок по пляжу.",
            "image": "/static/images/backpack.png",
            "price": 5
        },
        {
            "name": "Портативный опреснитель AquaSalt GO",
            "description": "Компактный USB/ручной привод, до 2л пресной воды в час, сменные фильтры для походов по острову",
            "image": "/static/images/water.png",
            "price": 10
        },
        {
            "name": "Солнечная станция SunShell 200",
            "description": "Складная панель + аккумулятор 20 000 mAh, заряжает гаджеты и роутер, работает под морским бризом и ярким солнцем",
            "image": "/static/images/solar.png",
            "price": 15
        },
        {
            "name": "Высокоскоростной роутер SeaLink X20",
            "description": "Влагозащищённый корпус, устойчив к соляному туману, поддержка Wi‑Fi 6 и LTE/5G для резервирования связи, стабильное покрытие бунгало и пляжной зоны",
            "image": "/static/images/router.png",
            "price": 333
        }
    ]

settings = Settings()
