import os
import uuid
import re
from typing import List
from datetime import timedelta

from fastapi import APIRouter, HTTPException, Depends, status, Request

from config import settings
from models import (
    UserCreate, UserRename, ClubbingCreate, ClubbingJoin, ClubbingPurchase,
    Token, ClubbingInfo, Product, ProductPurchase, UserLogin
)
from auth import create_access_token, authenticate_user, get_current_user
from utils import (
    get_user_file, get_clubbing_path, hash_password,
    read_user_data, write_user_data
)
from recaptcha import verify_recaptcha

router = APIRouter()

@router.post("/register", response_model=Token)
async def register(user: UserCreate):
    await verify_recaptcha(user.recaptcha_token)

    if not user.username:
        raise HTTPException(
            status_code=400,
            detail='Заполните поле "Имя пользователя"'
        )

    if len(user.username) < 9:
        raise HTTPException(
            status_code=400,
            detail="Имя пользователя должно быть не менее 9 символов"
        )

    if not re.search(r'^[а-яА-Яa-zA-Z0-9_-]+$', user.username):
        raise HTTPException(
            status_code=400,
            detail="Имя пользователя содержит недопустимые символы"
        )

    if len(user.password) < 6:
        raise HTTPException(
            status_code=400,
            detail="Пароль должен быть не менее 6 символов"
        )

    if not any(char.isdigit() for char in user.password) or not any(char.isupper() for char in user.password):
        raise HTTPException(
            status_code=400,
            detail="Пароль должен содержать хотя бы одну цифру и одну заглавную букву"
        )

    user_file = get_user_file(user.username)
    if os.path.exists(user_file):
        raise HTTPException(
            status_code=400,
            detail="Имя пользователя уже существует"
        )

    hashed_password = hash_password(user.password)
    with open(user_file, 'w') as f:
        f.write(hashed_password + '\n')

    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@router.post("/login", response_model=Token)
async def login(user: UserLogin):
    if not user.username:
        raise HTTPException(
            status_code=400,
            detail='Заполните поле "Имя пользователя"'
        )

    if len(user.username) < 9:
        raise HTTPException(
            status_code=400,
            detail="Имя пользователя должно быть не менее 9 символов"
        )
    
    if len(user.password) < 6:
        raise HTTPException(
            status_code=400,
            detail="Пароль должен быть не менее 6 символов"
        )

    if not any(char.isdigit() for char in user.password) or not any(char.isupper() for char in user.password):
        raise HTTPException(
            status_code=400,
            detail="Пароль должен содержать хотя бы одну цифру и одну заглавную букву"
        )

    if not authenticate_user(user.username, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Неверное имя пользователя или пароль",
            headers={"WWW-Authenticate": "Bearer"},
        )

    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )

    return {"access_token": access_token, "token_type": "bearer"}

@router.post("/rename")
async def rename_user(
    rename_data: UserRename,
    current_user: str = Depends(get_current_user)
):
    new_username = rename_data.new_username

    if not new_username:
        raise HTTPException(
            status_code=400,
            detail='Заполните поле "Новое имя пользователя"'
        )

    if len(new_username) < 9:
        raise HTTPException(
            status_code=400,
            detail="Имя пользователя должно быть не менее 9 символов"
        )

    new_user_file = get_user_file(new_username)
    if os.path.exists(new_user_file):
        raise HTTPException(
            status_code=400,
            detail="Имя пользователя уже существует"
        )

    user_data = read_user_data(current_user)
    old_user_file = get_user_file(current_user)
    os.rename(old_user_file, new_user_file)
    
    for clubbing_id in user_data[1:]:
        for product in settings.PRODUCTS:
            clubbing_path = get_clubbing_path(product.get('name'), clubbing_id)
            if os.path.exists(clubbing_path):
                old_user_file = os.path.join(clubbing_path, current_user)
                if os.path.exists(old_user_file):
                    os.rename(old_user_file,
                        os.path.join(clubbing_path, new_username)
                    )

    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": new_username}, expires_delta=access_token_expires
    )
    
    return {"message": "Имя пользователя изменено", "access_token": access_token}

@router.post("/create_clubbing", response_model=ClubbingInfo)
async def create_clubbing(
    clubbing_data: ClubbingCreate,
    current_user: str = Depends(get_current_user)
):
    if clubbing_data.product not in [product.get('name') for product in settings.PRODUCTS]:
        raise HTTPException(status_code=400, detail="Invalid product")

    user_data = read_user_data(current_user)
    for clubbing_id in user_data[1:]:
        clubbing_path = get_clubbing_path(clubbing_data.product, clubbing_id)
        if os.path.exists(clubbing_path):
            raise HTTPException(status_code=400, detail="Складчина уже существует")

    clubbing_id = str(uuid.uuid4()).split('-')[0]
    clubbing_path = get_clubbing_path(clubbing_data.product, clubbing_id)

    os.makedirs(clubbing_path)

    user_clubbing_file = os.path.join(clubbing_path, current_user)
    with open(user_clubbing_file, 'w') as _:
        pass

    write_user_data(current_user, clubbing_id)

    product = None
    for product in settings.PRODUCTS:
        if product.get('name') == clubbing_data.product:
            return {
                "clubbing_id": clubbing_id,
                "product": clubbing_data.product,
                "price": product.get('price'),
                "image": product.get('image'),
                "price_per_person": product.get('price'),
                "participants": [current_user]
            }

@router.post("/join_clubbing", response_model=ClubbingInfo)
async def join_clubbing(
    clubbing_data: ClubbingJoin,
    current_user: str = Depends(get_current_user)
):
    clubbing_id = clubbing_data.clubbing_id

    if not clubbing_id:
        raise HTTPException(
            status_code=400,
            detail='Заполните поле "ID складчины"'
        )

    target_product = None
    clubbing_path = None
    for product in settings.PRODUCTS:
        path = get_clubbing_path(product.get('name'), clubbing_id)
        if os.path.exists(path):
            target_product = product.get('name')
            clubbing_path = path
            break

    if target_product is None:
        raise HTTPException(
            status_code=404,
            detail="Складчина не существует"
        )

    user_data = read_user_data(current_user)
    user_clubbings = user_data[1:] if len(user_data) > 1 else []

    if clubbing_id in user_clubbings:
        raise HTTPException(
            status_code=400,
            detail="Вы уже состоите в этой складчине"
        )

    for existing_id in user_clubbings:
        existing_path = get_clubbing_path(target_product, existing_id)
        if os.path.exists(existing_path):
            user_in_clubbing = os.path.join(existing_path, current_user)
            if os.path.exists(user_in_clubbing):
                raise HTTPException(
                    status_code=400,
                    detail=f'Вы уже состоите в другой складчине товара "{target_product}"'
                )

    user_clubbing_file = os.path.join(clubbing_path, current_user)
    with open(user_clubbing_file, 'w') as _:
        pass

    write_user_data(current_user, clubbing_id)

    participants = os.listdir(clubbing_path)

    price = None
    for product in settings.PRODUCTS:
        if product.get('name') == target_product:
            price = product.get('price')
            image = product.get('image')
            break

    return {
        "clubbing_id": clubbing_data.clubbing_id,
        "product": target_product,
        "price": price,
        "image": image,
        "price_per_person": int(price / len(participants)),
        "participants": participants
    }

@router.get("/clubbings", response_model=List[ClubbingInfo])
async def get_clubbings(current_user: str = Depends(get_current_user)):
    user_data = read_user_data(current_user)
    clubbings = []

    for clubbing_id in user_data[1:]:
        target_product = None
        for product in settings.PRODUCTS:
            clubbing_path = get_clubbing_path(product.get('name'), clubbing_id)
            if os.path.exists(clubbing_path):
                target_product = product
                break

        if target_product:
            participants = os.listdir(clubbing_path)
            clubbings.append({
                "clubbing_id": clubbing_id,
                "product": target_product.get('name'),
                "price": target_product.get('price'),
                "image": target_product.get('image'),
                "participants": participants,
                "price_per_person": int(target_product.get('price') / len(participants))
            })

    return clubbings

@router.post("/leave_clubbing")
async def leave_clubbing(
    clubbing_data: ClubbingJoin,
    current_user: str = Depends(get_current_user)
):
    user_file = get_user_file(current_user)
    user_data = read_user_data(current_user)
    if clubbing_data.clubbing_id not in user_data[1:]:
        raise HTTPException(
            status_code=400,
            detail="Вы не состоите в этой складчине"
        )
    
    clubbing_found = False
    for product in settings.PRODUCTS:
        clubbing_path = get_clubbing_path(product.get('name'), clubbing_data.clubbing_id)
        if os.path.exists(clubbing_path):
            clubbing_found = True
            break

    if not clubbing_found:
        raise HTTPException(status_code=404, detail="Складчина не найдена")

    user_clubbing_file = os.path.join(clubbing_path, current_user)
    if os.path.exists(user_clubbing_file): os.remove(user_clubbing_file)
    if os.listdir(clubbing_path) == []: os.rmdir(clubbing_path)

    with open(user_file, 'w') as f:
        f.write(user_data[0] + "\n")
        for clubbing_id in user_data[1:]:
            if clubbing_id.strip() != clubbing_data.clubbing_id:
                f.write(clubbing_id + "\n")

    return {"message": "Вы успешно покинули складчину"}

@router.get("/products", response_model=List[Product])
async def get_products(current_user: str = Depends(get_current_user)):
    return settings.PRODUCTS

@router.post("/purchase_product")
async def purchase_product(
    request: Request,
    product_data: ProductPurchase,
    current_user: str = Depends(get_current_user)
):
    if product_data.product not in [product.get('name') for product in settings.PRODUCTS]:
        raise HTTPException(status_code=400, detail="Продукт не существует")

    price = None
    for product in settings.PRODUCTS:
        if product.get('name') == product_data.product:
            price = product.get('price')
            break

    try:
        user_balance = get_user_balance(current_user)
    except Exception:
        # Not implemented!
        user_balance = 0

    if user_balance < price:
        raise HTTPException(status_code=400, detail=f"Не хватает денег! Вам нужно {price} $$$")

    if product_data.product == "Высокоскоростной роутер SeaLink X20":
        return {"message": "Оплата успешна", "product": product_data.product, "flag": "alfa{***REDACTED***}"}
    else:
        return {"message": "Оплата успешна", "product": product_data.product}

@router.post("/purchase_clubbing")
async def purchase_clubbing(
    request: Request,
    clubbing_data: ClubbingPurchase,
    current_user: str = Depends(get_current_user)
):
    clubbing_id = clubbing_data.clubbing_id

    target_product = None
    clubbing_path = None
    product_price = None
    for product in settings.PRODUCTS:
        path = get_clubbing_path(product.get('name'), clubbing_id)
        if os.path.exists(path):
            target_product = product.get('name')
            product_price = product.get('price')
            clubbing_path = path
            break

    if target_product is None:
        raise HTTPException(
            status_code=404,
            detail="Складчина не существует"
        )

    user_in_clubbing = os.path.join(clubbing_path, current_user)
    if not os.path.exists(user_in_clubbing):
        raise HTTPException(
            status_code=403,
            detail="Вы не состоите в этой складчине"
        )

    participants = os.listdir(clubbing_path)
    participant_count = len(participants)
    price_per_person = int(product_price / participant_count)

    try:
        user_balance = get_user_balance(current_user)
    except Exception:
        # Not implemented!
        user_balance = 0

    if price_per_person <= user_balance:
        flag = None
        if target_product == "Высокоскоростной роутер SeaLink X20":
            flag = "alfa{***REDACTED***}"

        participants = os.listdir(clubbing_path)
        for participant in participants:
            user_file = get_user_file(participant)
            if os.path.exists(user_file):
                user_data = read_user_data(participant)
                with open(user_file, 'w') as f:
                    f.write(user_data[0] + "\n")
                    for existing_clubbing_id in user_data[1:]:
                        if existing_clubbing_id.strip() != clubbing_id:
                            f.write(existing_clubbing_id + "\n")
        import shutil
        shutil.rmtree(clubbing_path)

        return {"message": "Оплата успешна", "product": target_product, "flag": flag}
    else:
        raise HTTPException(
            status_code=400,
            detail=f"Не хватает денег! Вам нужно {price_per_person} $$$"
        )
