from pydantic import BaseModel
from typing import List, Optional

class UserCreate(BaseModel):
    username: str
    password: str
    recaptcha_token: str

class UserLogin(BaseModel):
    username: str
    password: str

class UserRename(BaseModel):
    new_username: str

class ClubbingCreate(BaseModel):
    product: str

class ClubbingJoin(BaseModel):
    clubbing_id: str

class ClubbingPurchase(BaseModel):
    clubbing_id: str

class ProductPurchase(BaseModel):
    product: str

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

class ClubbingInfo(BaseModel):
    clubbing_id: str
    product: str
    price: int
    image: str
    price_per_person: int
    participants: List[str]

class Product(BaseModel):
    name: str
    description: str
    image: str
    price: int
