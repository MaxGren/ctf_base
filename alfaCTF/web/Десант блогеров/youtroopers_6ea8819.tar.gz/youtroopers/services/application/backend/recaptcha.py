import httpx
from fastapi import HTTPException

from config import settings

async def verify_recaptcha(token: str) -> bool:
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://www.google.com/recaptcha/api/siteverify",
                data={
                    "secret": settings.RECAPTCHA_SECRET_KEY,
                    "response": token
                }
            )
            result = response.json()
            
            if not result.get("success"):
                raise HTTPException(
                    status_code=400,
                    detail="Неверная каптча"
                )
            
            return result.get("success", False)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Ошибка при проверке каптчи: {str(e)}"
        )
