import os
import hashlib
from typing import List

from config import settings

def get_user_file(username: str) -> str:
    return os.path.join(settings.USERS_DIR, username)

def get_clubbing_path(product: str, clubbing_id: str) -> str:
    return os.path.join(settings.CLUBBINGS_DIR, product, clubbing_id)

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password: str, hashed_password: str) -> bool:
    return hash_password(password) == hashed_password

def ensure_directories():
    os.makedirs(settings.USERS_DIR, exist_ok=True)
    os.makedirs(settings.CLUBBINGS_DIR, exist_ok=True)
    for product in settings.PRODUCTS:
        os.makedirs(os.path.join(settings.CLUBBINGS_DIR, product.get('name')), exist_ok=True)

def read_user_data(username: str) -> List[str]:
    user_file = get_user_file(username)
    if not os.path.exists(user_file):
        return []
    with open(user_file, 'r') as f:
        return f.read().splitlines()

def write_user_data(username: str, data: str):
    user_file = get_user_file(username)

    with open(user_file, 'a') as f:
        f.write(data + "\n")
