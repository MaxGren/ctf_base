#!/bin/bash

BRAINROTS_DIR=./rots                # we'll take all 3-second brainrots from this dir
# USEFUL_FILE=./alfactf_flag.mp4      # this is the thing we desperately wanted to remember...
# DURATION=$((6*60*60))               # 6 hours
USEFUL_FILE=./useful_memory.mp4     # this is the thing we desperately wanted to remember...
DURATION=$((1*60))                  # 1 minute

# 1. Let's accumulate enough brainrots to cover the duration
TARGET_ROTS=$(($DURATION / 3))
ls -1 rots/*.mp4 > rots.txt
ROTS_IN_LIST=$(wc -l < rots.txt)
while [[ "$ROTS_IN_LIST" -lt "$TARGET_ROTS" ]] ; do
    cat rots.txt rots.txt > doublerots.txt  # just double every time
    mv doublerots.txt rots.txt
    ROTS_IN_LIST=$(($ROTS_IN_LIST * 2))
done

# 2. Let's leave only the needed amount of brainrot
head -n $TARGET_ROTS rots.txt > precise_rots.txt
mv precise_rots.txt rots.txt

# 3. Let's add one useful thing to this mess
echo "$USEFUL_FILE" >> rots.txt

# 4. Let's shuffle it up really well
shuf rots.txt > shuffled_rots.txt
mv shuffled_rots.txt rots.txt

# 5. Let's prepare this list for ffmpeg
sed -i 's/^/file /' rots.txt

# 6. And finally, let's rot! \m/
ffmpeg -f concat -safe 0 -i rots.txt -c copy brainrot.mp4

# 7. Enjoy the meal!
ls -la brainrot.mp4
