package zen.messenger.ui.contacts

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.koin.compose.viewmodel.koinViewModel
import zen.messenger.domain.model.Contact

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactsScreen(
    viewModel: ContactsViewModel = koinViewModel(),
    onContactClick: (id: String) -> Unit,
) {
    val uiState by viewModel.uiState.collectAsState()
    val vmSearchState by viewModel.searchState.collectAsState()
    val searchState = vmSearchState

    val searchQuery = when (searchState) {
        is SearchState.Idle -> ""
        is SearchState.Active -> searchState.query
    }

    val isSearchActive = when (searchState) {
        is SearchState.Idle -> false
        is SearchState.Active -> searchState.isActive
    }

    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val focusManager = LocalFocusManager.current
    val drawerState = rememberDrawerState(DrawerValue.Closed)

    BackHandler(enabled = drawerState.isOpen) {
        scope.launch {
            drawerState.close()
        }
    }

    val backgroundColor by animateColorAsState(
        targetValue = if (isSearchActive) Color.Black else MaterialTheme.colorScheme.surface,
        animationSpec = tween(durationMillis = 300),
        label = "backgroundColor"
    )

    val textColor by animateColorAsState(
        targetValue = if (isSearchActive) Color.White else MaterialTheme.colorScheme.onSurface,
        animationSpec = tween(durationMillis = 300),
        label = "textColor"
    )

    ContactsContent(
        uiState = uiState,
        searchState = searchState,
        searchQuery = searchQuery,
        isSearchActive = isSearchActive,
        backgroundColor = backgroundColor,
        textColor = textColor,
        listState = listState,
        focusManager = focusManager,
        viewModel = viewModel,
        onContactClick = onContactClick
    )
}

@Composable
private fun ContactsContent(
    uiState: UiState,
    searchState: SearchState,
    searchQuery: String,
    isSearchActive: Boolean,
    backgroundColor: Color,
    textColor: Color,
    listState: androidx.compose.foundation.lazy.LazyListState,
    focusManager: androidx.compose.ui.focus.FocusManager,
    viewModel: ContactsViewModel,
    onContactClick: (id: String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        focusManager.clearFocus()
                    }
                )
            }
    ) {
        when (uiState) {
            is UiState.Loading -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "...",
                        style = MaterialTheme.typography.bodyLarge,
                        color = textColor.copy(alpha = 0.6f)
                    )
                }
            }

            is UiState.Error -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = uiState.errorMsg,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isSearchActive) Color.Red else MaterialTheme.colorScheme.error
                    )
                }
            }

            is UiState.Success -> {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 16.dp),
                ) {
                    item {
                        AddContactItem(
                            text = "запрос во вселенную",
                            value = searchQuery,
                            onValueChange = viewModel::updateSearchQuery,
                            onFocusChange = viewModel::setSearchFocused,
                            textColor = textColor
                        )
                    }

                    if (isSearchActive) {
                        when (searchState) {
                            is SearchState.Idle -> {}

                            is SearchState.Active -> {
                                when (searchState.remoteState) {
                                    is RemoteSearchState.Loading -> {
                                        item {
                                            Text(
                                                text = "жду ответа...",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = textColor.copy(alpha = 0.6f),
                                                modifier = Modifier.padding(
                                                    horizontal = 16.dp,
                                                    vertical = 8.dp
                                                )
                                            )
                                        }
                                    }

                                    is RemoteSearchState.Success -> {
                                        items(searchState.remoteState.results) { contact ->
                                            ContactItem(
                                                contact = contact,
                                                textColor = textColor,
                                                onClick = { onContactClick(contact.id) }
                                            )
                                        }
                                    }

                                    is RemoteSearchState.Error -> {
                                        item {
                                            Text(
                                                text = "ошибка поиска: ${searchState.remoteState.message}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = if (isSearchActive) Color.Red else MaterialTheme.colorScheme.error,
                                                modifier = Modifier.padding(
                                                    horizontal = 16.dp,
                                                    vertical = 8.dp
                                                )
                                            )
                                        }
                                    }

                                    RemoteSearchState.AwaitingQuery -> {}
                                }

                                val hasRemoteResults =
                                    searchState.remoteState is RemoteSearchState.Success &&
                                            searchState.remoteState.results.isNotEmpty()
                                val hasLocalResults = searchState.localResults.isNotEmpty()

                                if (hasRemoteResults && hasLocalResults) {
                                    item {
                                        Text(
                                            text = "separator",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = textColor.copy(alpha = 0.5f),
                                            modifier = Modifier.padding(
                                                horizontal = 16.dp,
                                                vertical = 8.dp
                                            )
                                        )
                                    }
                                }

                                items(searchState.localResults) { contact ->
                                    ContactItem(
                                        contact = contact,
                                        textColor = textColor,
                                        onClick = { onContactClick(contact.id) }
                                    )
                                }
                            }
                        }
                    } else {
                        itemsIndexed(uiState.contacts) { i, contact ->
                            ContactItem(
                                contact = contact,
                                textColor = textColor,
                                onClick = { onContactClick(contact.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ContactItem(
    contact: Contact,
    textColor: Color = MaterialTheme.colorScheme.onSurface,
    onClick: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 14.dp, horizontal = 16.dp)
    ) {
        Text(
            text = contact.username,
            fontSize = 20.sp,
            fontWeight = FontWeight.Thin,
            color = textColor,
            lineHeight = 20.sp,
            overflow = TextOverflow.Ellipsis,
            maxLines = 2
        )
    }
}

@Composable
private fun AddContactItem(
    text: String,
    value: String,
    onValueChange: (String) -> Unit,
    onFocusChange: (Boolean) -> Unit,
    textColor: Color = MaterialTheme.colorScheme.onSurface
) {
    val focusRequester = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var isFocused by remember { mutableStateOf(false) }

    BackHandler(enabled = isFocused || value.isNotEmpty()) {
        if (isFocused) {
            focusManager.clearFocus()
        } else if (value.isNotEmpty()) {
            onValueChange("")
        }
    }

    val style = TextStyle(
        fontSize = 12.sp,
        fontWeight = FontWeight.Thin,
        fontStyle = FontStyle.Italic,
        textAlign = TextAlign.Center,
        color = textColor,
        lineHeight = 12.sp,
    )

    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(top = 24.dp, bottom = 16.dp)
            .focusRequester(focusRequester)
            .onFocusChanged { focusState ->
                isFocused = focusState.isFocused
                onFocusChange(focusState.isFocused)
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { focusRequester.requestFocus() }
                )
            },
        textStyle = style,
        cursorBrush = SolidColor(textColor),
        decorationBox = { innerTextField ->
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                if (value.isEmpty()) {
                    Text(
                        text = text,
                        style = style,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                innerTextField()
            }
        }
    )
}