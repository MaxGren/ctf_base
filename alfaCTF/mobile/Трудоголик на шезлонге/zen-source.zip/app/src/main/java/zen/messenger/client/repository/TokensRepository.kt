package zen.messenger.client.repository

interface TokensRepository {
    fun get(): String?
    fun set(token: String)
}