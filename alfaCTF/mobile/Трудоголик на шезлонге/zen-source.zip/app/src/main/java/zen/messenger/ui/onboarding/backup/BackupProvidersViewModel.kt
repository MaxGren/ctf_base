package zen.messenger.ui.onboarding.backup

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import zen.messenger.backup.BackupManager
import zen.messenger.backup.model.BackupProvider
import zen.messenger.backup.model.CloudBackup
import zen.messenger.backup.model.LocalBackup
import zen.messenger.backup.repository.BackupRepository
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

sealed class BackupItem {
    abstract val id: String
    abstract val title: String
    abstract val subtitle: String

    data class Local(
        override val id: String,
        override val title: String,
        override val subtitle: String,
        val backup: LocalBackup
    ) : BackupItem()

    data class Cloud(
        override val id: String,
        override val title: String,
        override val subtitle: String,
        val backup: CloudBackup
    ) : BackupItem()
}

data class UiState(
    val backupProviders: List<BackupProvider> = emptyList(),
    val showBackupList: Boolean = false,
    val selectedProviderId: String? = null,
    val backupItems: List<BackupItem> = emptyList(),
    val isLoadingBackups: Boolean = false,
    val isRestoringBackup: Boolean = false,
    val loadingText: String = ""
)

class BackupProvidersViewModel(
    private val backupRepo: BackupRepository,
    private val backupManager: BackupManager
) : ViewModel() {
    companion object {
        private const val TAG = "BackupProvidersViewModel"
        private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
    }

    private val backupProviders = MutableStateFlow(emptyList<BackupProvider>())
    private val _uiState = MutableStateFlow(UiState())

    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            backupRepo.providersFlow().collect { providers ->
                backupProviders.emit(providers)
                _uiState.value = _uiState.value.copy(
                    backupProviders = providers + listOf(
                        BackupProvider("local", "на устройстве", "local", "{}")
                    )
                )
            }
        }
    }

    fun selectBackupProvider(id: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                selectedProviderId = id,
                showBackupList = true,
                isLoadingBackups = true,
                loadingText = "загружаем резервные копии..."
            )

            try {
                val backupItems = when (id) {
                    "local" -> loadLocalBackups()
                    else -> loadCloudBackups(id)
                }

                _uiState.value = _uiState.value.copy(
                    backupItems = backupItems,
                    isLoadingBackups = false,
                    loadingText = ""
                )

                if (backupItems.isEmpty()) {
                    finishWithProvider(id)
                }

            } catch (e: Exception) {
                Log.e(TAG, "Error loading backups for provider $id", e)
                _uiState.value = _uiState.value.copy(
                    isLoadingBackups = false,
                    loadingText = ""
                )
                finishWithProvider(id)
            }
        }
    }

    fun selectBackup(backupItem: BackupItem) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isRestoringBackup = true
            )

            try {
                when (backupItem) {
                    is BackupItem.Local -> {
                        backupManager.restore(backupItem.backup.path)
                    }

                    is BackupItem.Cloud -> {
                        backupManager.fetch(backupItem.backup, restore = true)
                    }
                }

                finishWithProvider(_uiState.value.selectedProviderId!!)

            } catch (e: Exception) {
                Log.e(TAG, "Error restoring backup", e)
                _uiState.value = _uiState.value.copy(
                    isRestoringBackup = false
                )
            }
        }
    }

    private suspend fun loadLocalBackups(): List<BackupItem> {
        val localBackups = backupManager.lookForLocalBackups()
        return localBackups.map { backup ->
            BackupItem.Local(
                id = backup.meta.id,
                title = formatDate(backup.meta.createdAt),
                subtitle = "${backup.meta.contactsCount} контактов, ${backup.meta.messagesCount} сообщений",
                backup = backup
            )
        }
    }

    private suspend fun loadCloudBackups(providerId: String): List<BackupItem> {
        val cloudBackups = backupManager.lookForCloudBackups(providerId)
        return cloudBackups.map { backup ->
            BackupItem.Cloud(
                id = backup.meta.id,
                title = formatDate(backup.meta.createdAt),
                subtitle = "${backup.meta.contactsCount} контактов, ${backup.meta.messagesCount} сообщений",
                backup = backup
            )
        }
    }

    private fun formatDate(instant: Instant): String {
        return instant.atZone(ZoneId.systemDefault()).format(dateFormatter)
    }

    private suspend fun finishWithProvider(providerId: String) {
        backupRepo.setCurrentProviderID(providerId)
    }
}