package zen.messenger.data.repository

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import zen.messenger.backup.model.BackupProvider
import zen.messenger.backup.repository.BackupRepository
import zen.messenger.data.db.datasource.LocalStringKV
import zen.messenger.data.db.datasource.LocalBackup as LocalBackupDataSource

class BackupRepositoryImpl(
    private val localBackup: LocalBackupDataSource,
    private val localStringKV: LocalStringKV
) : BackupRepository {

    companion object {
        private const val KEY_ENDPOINT = "key_endpoint"
        private const val CURRENT_PROVIDER_ID = "current_provider_id"
    }

    override fun getKeyEndpoint(): String =
        localStringKV.get(KEY_ENDPOINT) ?: ""

    override fun setKeyEndpoint(new: String) {
        localStringKV.set(KEY_ENDPOINT, new)
    }

    override fun providers(): List<BackupProvider> =
        localBackup.getAllProviders()

    override fun providersFlow(): Flow<List<BackupProvider>> =
        localBackup.getAllProvidersFlow()

    override fun updateProviders(new: List<BackupProvider>) {
        localBackup.updateProviders(new)
    }

    override fun getProviderByID(id: String): BackupProvider? =
        localBackup.getProviderById(id)

    override fun getCurrentProviderID(): String? = localStringKV.get(CURRENT_PROVIDER_ID)

    override fun setCurrentProviderID(new: String?) {
        localStringKV.set(CURRENT_PROVIDER_ID, new ?: "")
    }

    override fun getCurrentProvider(): BackupProvider? {
        val currentId = getCurrentProviderID()
        return if (currentId.isNullOrEmpty()) null else getProviderByID(currentId)
    }

    override fun flowableCurrentProvider(): Flow<BackupProvider?> =
        localStringKV.flow(CURRENT_PROVIDER_ID)
            .map { it?.let { getProviderByID(it) } }
}