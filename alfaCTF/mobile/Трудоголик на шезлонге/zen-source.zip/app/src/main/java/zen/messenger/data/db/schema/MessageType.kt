package zen.messenger.data.db.schema

enum class MessageType {
    SERVICE,
    TEXT_INCOMING,
    TEXT_OUTGOING
}