package zen.messenger.data.db.datasource

import app.cash.sqldelight.coroutines.asFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import zen.messenger.data.db.schema.Database
import zen.messenger.data.db.schema.MessageRecord
import zen.messenger.data.db.schema.MessageType
import zen.messenger.domain.model.Ack
import zen.messenger.domain.model.AckStatus
import zen.messenger.domain.model.Message
import zen.messenger.domain.model.MessageMeta
import zen.messenger.domain.model.ServiceMessage
import zen.messenger.domain.model.ServiceMessageContent
import zen.messenger.domain.model.TextMessage
import java.time.Instant

class LocalMessages(val db: Database) {
    fun MessageRecord.toMessage(): Message {
        val meta = MessageMeta(
            internalID = this.internal_id,
            contactID = this.contact_id,
            timestampUTC = Instant.ofEpochMilli(this.timestamp_utc),
            ackStatus = this.ack_status ?: AckStatus.NOT_SET,
            serverID = this.server_id,
        )
        return when (this.type) {
            MessageType.SERVICE -> {
                val payload: ServiceMessageContent = Json.decodeFromString(this.text)
                payload.toServiceMessage(meta)
            }

            MessageType.TEXT_INCOMING, MessageType.TEXT_OUTGOING -> TextMessage(
                meta = meta,
                toMe = this.type == MessageType.TEXT_INCOMING,
                text = this.text,
            )
        }
    }

    fun getMessages(
        contactID: String,
        limit: Long,
        offsetID: Long?
    ): List<Message> {
        val query = if (offsetID == null) {
            db.messageQueries.getMessages(contactID, limit)
        } else {
            db.messageQueries.getMessagesWithOffset(contactID, offsetID, limit)
        }
        return query.executeAsList().map { it.toMessage() }
    }

    fun getNewMessagesFlow(
        contactID: String,
        sinceMsgID: Long
    ): Flow<List<Message>> {
        return db.messageQueries.getMessagesAfter(contactID, sinceMsgID)
            .asFlow().map { it.executeAsList().map { msg -> msg.toMessage() } }
    }

    fun addMessage(msg: Message): Message {
        val result = db.messageQueries.transactionWithResult {
            when (msg) {
                is Ack -> {
                    db.messageQueries.setAckStatus(msg.ackStatus, msg.serverID)
                    return@transactionWithResult -42L
                }

                is TextMessage -> {
                    db.messageQueries.add(
                        server_id = msg.serverID,
                        contact_id = msg.contactID,
                        type = if (msg.toMe) MessageType.TEXT_INCOMING else MessageType.TEXT_OUTGOING,
                        timestamp_utc = msg.timestampUTC.toEpochMilli(),
                        text = msg.text,
                        ack_status = msg.ackStatus
                    )
                }

                is ServiceMessage -> {
                    db.messageQueries.add(
                        server_id = msg.serverID,
                        contact_id = msg.contactID,
                        type = MessageType.SERVICE,
                        timestamp_utc = msg.timestampUTC.toEpochMilli(),
                        text = Json.encodeToString(msg.content),
                        ack_status = msg.ackStatus
                    )
                }

                is MessageMeta -> error("MessageBase cannot be added as message")
            }
            return@transactionWithResult db.messageQueries.getInserted().executeAsOne().internal_id
        }
        if (result > 0L) {
            return msg.updateInternalID(result)
        }
        return msg
    }

    fun getByServerID(serverID: String): Message? {
        return db.messageQueries.getByServerID(serverID).executeAsOneOrNull()?.toMessage()
    }

    fun getIncomingPending(): List<Message> {
        return db.messageQueries.getPendingIncomingMessages().executeAsList().map { it.toMessage() }
    }

    fun markSent(internalID: Long, serverID: String) {
        db.transaction {
            db.messageQueries.setServerID(server_id = serverID, internal_id = internalID)
            db.messageQueries.setAckStatusInternal(AckStatus.OUT_SENT, internalID)
        }
    }

    fun setAckStatus(internalID: Long, status: AckStatus): Long {
        return db.messageQueries.setAckStatusInternal(status, internalID).value
    }

    fun setAckStatus(serverID: String, status: AckStatus): Long {
        return db.messageQueries.setAckStatus(status, serverID).value
    }

    fun allMessages(): List<Message> = allMessageRecords().map { it.toMessage() }

    fun allMessagesFlow(): Flow<List<Message>> = db.messageQueries.allMessages().asFlow()
        .map { it.executeAsList().map { msg -> msg.toMessage() } }

    fun allMessageRecords(): List<MessageRecord> {
        return db.messageQueries.allMessages().executeAsList()
    }

    fun restoreMessages(messages: List<MessageRecord>) {
        db.messageQueries.transaction {
            messages.forEach {
                try {
                    db.messageQueries.restoreMessage(
                        internal_id = it.internal_id,
                        server_id = it.server_id,
                        contact_id = it.contact_id,
                        type = it.type,
                        timestamp_utc = it.timestamp_utc,
                        text = it.text,
                        ack_status = it.ack_status
                    )
                } catch (e: Exception) {
                    db.messageQueries.restoreMessageUpdate(
                        internal_id = it.internal_id,
                        server_id = it.server_id,
                        contact_id = it.contact_id,
                        type = it.type,
                        timestamp_utc = it.timestamp_utc,
                        text = it.text,
                        ack_status = it.ack_status?.name,
                    )
                }
            }
        }
    }
}