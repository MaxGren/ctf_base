package zen.messenger

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import org.koin.android.ext.android.get
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.GlobalContext.startKoin
import zen.messenger.backup.BackupManager
import zen.messenger.domain.StateManager

class ZenApp : Application() {
    override fun onCreate() {
        super.onCreate()

        startKoin {
            androidLogger()
            androidContext(this@ZenApp)
            modules(appModule(this@ZenApp))

            get<BackupManager>().handleRegionUpdates(CoroutineScope(SupervisorJob() + Dispatchers.Default))
            get<MessageWorker>().start(CoroutineScope(SupervisorJob() + Dispatchers.Default))
            get<StateManager>().handleStateUpdates(CoroutineScope(SupervisorJob() + Dispatchers.Default))
        }
    }
}