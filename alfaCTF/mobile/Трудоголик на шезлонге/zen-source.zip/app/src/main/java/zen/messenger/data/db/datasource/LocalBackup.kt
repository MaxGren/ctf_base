package zen.messenger.data.db.datasource

import app.cash.sqldelight.coroutines.asFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import zen.messenger.backup.model.BackupProvider
import zen.messenger.data.db.schema.Database

class LocalBackup(private val db: Database) {
    fun getAllProviders(): List<BackupProvider> =
        db.backupQueries.getAllProviders().executeAsList().map {
            BackupProvider(it.id, it.name, it.strategy, it.json_params)
        }

    fun getProviderById(id: String): BackupProvider? =
        db.backupQueries.getProviderById(id).executeAsOneOrNull()?.let {
            BackupProvider(it.id, it.name, it.strategy, it.json_params)
        }

    fun updateProviders(providers: List<BackupProvider>) {
        db.transaction {
            db.backupQueries.updateProviders()
            providers.forEach { provider ->
                db.backupQueries.insertProvider(
                    provider.id,
                    provider.name,
                    provider.strategy,
                    provider.jsonParams
                )
            }
        }
    }

    fun getAllProvidersFlow(): Flow<List<BackupProvider>> =
        db.backupQueries.getAllProviders().asFlow()
            .map { it ->
                it.executeAsList().map {
                    BackupProvider(it.id, it.name, it.strategy, it.json_params)
                }
            }
}