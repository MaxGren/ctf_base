package zen.messenger.client.discovery

import zen.messenger.client.ClientError
import zen.messenger.client.proto.ContactByIDErrorCode
import zen.messenger.client.proto.RegisterUsernameErrorCode

class RegisterUsernameException(code: RegisterUsernameErrorCode, msg: String) :
    ClientError(code.name, msg)

class ContactsByUsernameException(msg: String) : ClientError("UNSPECIFIED", msg)
class ContactByIDException(code: ContactByIDErrorCode, msg: String) : ClientError(code.name, msg)