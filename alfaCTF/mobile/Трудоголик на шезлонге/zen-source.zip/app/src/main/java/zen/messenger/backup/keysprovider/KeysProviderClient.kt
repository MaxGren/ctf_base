package zen.messenger.backup.keysprovider

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import zen.messenger.backup.repository.BackupRepository
import zen.messenger.client.crypto.SessionKey
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class KeysProviderClient(
    val backupRepository: BackupRepository,
    private val httpClient: OkHttpClient,
) {
    suspend fun getKey(keyID: String): SessionKey {
        val endpoint = currentEndpoint() ?: throw Exception("No endpoint configured")
        val url = buildUrl(endpoint, keyID)
        val keyBytes = fetchKeyBytes(url)
        return SessionKey(keyBytes)
    }

    fun currentEndpoint(): String? {
        return backupRepository.getKeyEndpoint()
    }

    fun setEndpoint(endpoint: String) {
        backupRepository.setKeyEndpoint(endpoint)
    }

    private fun buildUrl(endpoint: String, keyID: String): String {
        return endpoint.trimEnd('/') + "/$keyID"
    }

    private suspend fun fetchKeyBytes(url: String): ByteArray =
        suspendCancellableCoroutine { continuation ->
            val request = Request.Builder()
                .url(url)
                .build()

            val call = httpClient.newCall(request)

            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    continuation.resumeWithException(Exception("Failed to fetch key", e))
                }

                override fun onResponse(call: Call, response: Response) {
                    try {
                        if (!response.isSuccessful) {
                            continuation.resumeWithException(Exception("HTTP error: ${response.code}"))
                            return
                        }

                        val bytes = response.body.bytes()
                        if (bytes.isEmpty()) {
                            throw Exception("Empty response body")
                        }

                        continuation.resume(bytes)
                    } catch (e: Exception) {
                        continuation.resumeWithException(Exception("Failed to read response", e))
                    } finally {
                        response.close()
                    }
                }
            })

            continuation.invokeOnCancellation {
                call.cancel()
            }
        }
}