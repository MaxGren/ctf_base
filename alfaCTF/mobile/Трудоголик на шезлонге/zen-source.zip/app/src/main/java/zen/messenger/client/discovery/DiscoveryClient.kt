package zen.messenger.client.discovery

import io.grpc.Channel
import zen.messenger.client.auth.AuthInterceptor
import zen.messenger.client.crypto.ed25519.Ed25519PublicKey
import zen.messenger.client.crypto.x25519.X25519PublicKey
import zen.messenger.client.proto.ContactByIDErrorCode
import zen.messenger.client.proto.ContactByIDRequest
import zen.messenger.client.proto.ContactByIDResponse
import zen.messenger.client.proto.ContactsByUsernameRequest
import zen.messenger.client.proto.ContactsByUsernameResponse
import zen.messenger.client.proto.DiscoveryServiceGrpcKt
import zen.messenger.client.proto.MeRequest
import zen.messenger.client.proto.RegisterUsernameErrorCode
import zen.messenger.client.proto.RegisterUsernameRequest
import zen.messenger.client.proto.RegisterUsernameResponse
import zen.messenger.client.proto.toDomainContact
import zen.messenger.domain.model.Contact

internal class DiscoveryClient(channel: Channel, interceptor: AuthInterceptor) {
    private val stub = DiscoveryServiceGrpcKt.DiscoveryServiceCoroutineStub(channel)
        .withInterceptors(interceptor)

    suspend fun getMe(): Contact {
        val response = stub.me(MeRequest.newBuilder().build())
        return response.contact!!.toDomainContact()
    }

    suspend fun registerUsername(username: String) {
        val response = stub.registerUsername(
            RegisterUsernameRequest.newBuilder()
                .setUsername(username)
                .build()
        )
        when (response.resultCase) {
            RegisterUsernameResponse.ResultCase.SUCCESS -> return
            RegisterUsernameResponse.ResultCase.ERROR -> throw RegisterUsernameException(
                response.error.code, response.error.message
            )

            RegisterUsernameResponse.ResultCase.RESULT_NOT_SET -> RegisterUsernameException(
                RegisterUsernameErrorCode.UNRECOGNIZED, "Empty response provided by server"
            )
        }
    }

    suspend fun contactsByUsername(username: String): List<Contact> {
        val response = stub.contactsByUsername(
            ContactsByUsernameRequest.newBuilder()
                .setUsername(username)
                .build()
        )
        when (response.resultCase) {
            ContactsByUsernameResponse.ResultCase.ERROR -> throw ContactsByUsernameException(
                response.error.message
            )

            ContactsByUsernameResponse.ResultCase.RESULT_NOT_SET -> throw ContactsByUsernameException(
                "Empty response provided by server"
            )

            ContactsByUsernameResponse.ResultCase.SUCCESS -> null
        }
        return response.success.resultList.map { it.toDomainContact() }
    }

    suspend fun contactByID(id: String): Pair<Contact, ContactKeys>? {
        val response = stub.contactByID(ContactByIDRequest.newBuilder().setId(id).build())
        when (response.resultCase) {
            ContactByIDResponse.ResultCase.ERROR -> {
                if (response.error.code == ContactByIDErrorCode.CBID_FAILURE_NOT_FOUND) {
                    return null
                }
                throw ContactByIDException(response.error.code, response.error.message)
            }

            ContactByIDResponse.ResultCase.RESULT_NOT_SET -> throw ContactByIDException(
                ContactByIDErrorCode.CBID_FAILURE_GENERIC, "Empty response provided by server"
            )

            ContactByIDResponse.ResultCase.SUCCESS -> {
                val domain = response.success.contact.toDomainContact()
                val prekeyObj = requireNotNull(response.success.contact.prekey)
                val contactKeys = ContactKeys(
                    signing = Ed25519PublicKey(domain.signingKey!!),
                    identity = X25519PublicKey(domain.identityKey!!),
                    prekey = X25519PublicKey(prekeyObj.prekey.toByteArray())
                )
                return domain to contactKeys
            }
        }
    }
}