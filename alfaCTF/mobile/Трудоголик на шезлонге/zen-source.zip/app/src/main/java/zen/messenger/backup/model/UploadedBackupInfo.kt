package zen.messenger.backup.model

import kotlinx.serialization.Serializable
import zen.messenger.util.InstantSerializer
import java.time.Instant

@Serializable
data class UploadedBackupInfo(
    val providerID: String,
    @Serializable(with = InstantSerializer::class) val uploadedAt: Instant,
)