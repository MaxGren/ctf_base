package zen.messenger.data.db

import app.cash.sqldelight.EnumColumnAdapter
import org.koin.dsl.module
import zen.messenger.backup.BackupOperator
import zen.messenger.data.db.datasource.LocalBackup
import zen.messenger.data.db.datasource.LocalBackupOperator
import zen.messenger.data.db.datasource.LocalContacts
import zen.messenger.data.db.datasource.LocalEncryptionKeys
import zen.messenger.data.db.datasource.LocalMessages
import zen.messenger.data.db.datasource.LocalStringKV
import zen.messenger.data.db.schema.Database
import zen.messenger.data.db.schema.MessageRecord

fun dbModule() = module {
    factory {
        Database(
            get(), MessageRecord.Adapter(
                typeAdapter = EnumColumnAdapter(),
                ack_statusAdapter = EnumColumnAdapter()
            )
        )
    }

    single { LocalContacts(get(), get()) }
    single { LocalMessages(get()) }
    single { LocalEncryptionKeys(get()) }
    single { LocalStringKV(get()) }
    single { LocalBackup(get()) }
    single { LocalBackupOperator(get(), get(), get(), get()) as BackupOperator }
}