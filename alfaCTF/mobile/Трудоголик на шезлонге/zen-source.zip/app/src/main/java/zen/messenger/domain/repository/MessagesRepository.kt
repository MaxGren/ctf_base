package zen.messenger.domain.repository

import kotlinx.coroutines.flow.Flow
import zen.messenger.domain.model.Contact
import zen.messenger.domain.model.Message
import zen.messenger.domain.model.ServiceMessage

interface MessagesRepository {
    suspend fun get(contactID: String, limit: Long, offsetID: Long? = null): List<Message>
    suspend fun getNewSince(contactID: String, offsetID: Long): Flow<List<Message>>

    suspend fun handleIncoming(msg: Message, from: Contact?): Message
    suspend fun ackIncoming(serverID: String)
    fun subscribeIncomingPending(filter: (Message) -> Boolean): Flow<Message>

    fun serviceMessagesFlow(): Flow<List<ServiceMessage>>
    fun subscribeServicePending(filter: (ServiceMessage) -> Boolean): Flow<ServiceMessage>

    suspend fun sendText(contactID: String, text: String)
}
