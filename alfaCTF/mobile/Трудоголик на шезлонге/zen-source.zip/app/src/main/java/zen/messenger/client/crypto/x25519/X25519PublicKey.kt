package zen.messenger.client.crypto.x25519

import org.bouncycastle.crypto.params.X25519PublicKeyParameters

data class X25519PublicKey(val publicKey: ByteArray) {
    val publicKeyParams by lazy { X25519PublicKeyParameters(publicKey, 0) }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as X25519PublicKey

        return publicKey.contentEquals(other.publicKey)
    }

    override fun hashCode(): Int {
        return publicKey.contentHashCode()
    }
}