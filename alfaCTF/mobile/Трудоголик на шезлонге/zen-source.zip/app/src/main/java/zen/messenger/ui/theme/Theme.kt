package zen.messenger.ui.theme

import androidx.compose.material.ripple.RippleAlpha
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalRippleConfiguration
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RippleConfiguration
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color

private val ZenColorScheme = lightColorScheme(
    primary = Color(0xFFB2B2B2),
    secondary = Color(0xFFCFCFCF),
    tertiary = Color(0xFF7D5260),

    background = Color(0xFFFDFDFD),
    surface = Color(0xFFFFFFFF),
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color(0xFF1C1B1F),
    onSurface = Color(0xFF6B6B6B),
    onSurfaceVariant = Color(0xFFFFFFFF)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZenTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = ZenColorScheme

    CompositionLocalProvider(
        LocalRippleConfiguration provides RippleConfiguration(
            color = Color(0xFFE1E1E1),
            rippleAlpha = RippleAlpha(
                pressedAlpha = 0.2f,
                focusedAlpha = 0.05f,
                draggedAlpha = 0.05f,
                hoveredAlpha = 0.05f
            )
        )
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}