package zen.messenger.client.crypto

import zen.messenger.client.crypto.ed25519.Ed25519MnemonicKeygen
import zen.messenger.client.crypto.ed25519.Ed25519PrivateKey
import zen.messenger.client.crypto.x25519.X25519MnemonicKeygen
import zen.messenger.client.crypto.x25519.X25519PrivateKey

data class ZenKeypair(
    val signing: Ed25519PrivateKey,
    val identity: X25519PrivateKey
) {
    companion object {
        fun generateFromMnemonic(mnemonic: List<CharArray>): ZenKeypair {
            return ZenKeypair(
                Ed25519MnemonicKeygen().keyFromMnemonic(mnemonic),
                X25519MnemonicKeygen().keyFromMnemonic(mnemonic)
            )
        }
    }
}
