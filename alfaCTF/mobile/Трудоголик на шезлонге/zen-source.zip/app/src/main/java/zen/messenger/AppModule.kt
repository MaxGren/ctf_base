package zen.messenger

import android.content.Context
import okhttp3.ConnectionSpec
import okhttp3.OkHttpClient
import org.koin.dsl.module
import zen.messenger.backup.backupModule
import zen.messenger.client.clientModule
import zen.messenger.data.dataModule
import zen.messenger.data.db.dbModule
import zen.messenger.data.db.driver.dbDriverModule
import zen.messenger.domain.StateManager
import zen.messenger.ui.contacts.contactsViewModelModule
import zen.messenger.ui.dialogue.dialogueViewModelModule
import zen.messenger.ui.onboarding.onboardingModule
import java.time.Duration

fun appModule(context: Context) = module {
    single {
        OkHttpClient().newBuilder()
            .callTimeout(Duration.ofSeconds(15))
            .connectionSpecs(listOf(ConnectionSpec.MODERN_TLS, ConnectionSpec.CLEARTEXT))
            .build()
    }



    includes(
        dbDriverModule(),
        dbModule(),

        dataModule(),
        clientModule(),
        backupModule(context.getExternalFilesDir(null)!!),

        onboardingModule(),
        contactsViewModelModule(),
        dialogueViewModelModule(),
    )


    single(createdAtStart = true) {
        StateManager(get(), get(), get(), get())
    }
    single(createdAtStart = true) { MessageWorker(get(), get(), get(), get()) }
}