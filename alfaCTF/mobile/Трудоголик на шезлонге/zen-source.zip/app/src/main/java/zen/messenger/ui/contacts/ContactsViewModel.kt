package zen.messenger.ui.contacts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import zen.messenger.domain.model.Contact
import zen.messenger.domain.repository.ContactsRepository

sealed class UiState {
    data object Loading : UiState()
    data class Success(
        val contacts: List<Contact>,
    ) : UiState()

    data class Error(
        val errorMsg: String,
    ) : UiState()
}

sealed class SearchState {
    data object Idle : SearchState()
    data class Active(
        val query: String,
        val isFocused: Boolean,
        val remoteState: RemoteSearchState,
        val localResults: List<Contact>
    ) : SearchState() {
        val isActive: Boolean get() = isFocused || query.isNotEmpty()
    }
}

sealed class RemoteSearchState {
    data object AwaitingQuery : RemoteSearchState()
    data object Loading : RemoteSearchState()
    data class Success(val results: List<Contact>) : RemoteSearchState()
    data class Error(val message: String) : RemoteSearchState()
}

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class ContactsViewModel(
    private val contactsRepository: ContactsRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow<UiState>(UiState.Loading)
    val uiState = _uiState.asStateFlow()

    private val _searchState = MutableStateFlow<SearchState>(SearchState.Idle)
    val searchState = _searchState.asStateFlow()

    val searchQuery = _searchState.map { state ->
        when (state) {
            is SearchState.Idle -> ""
            is SearchState.Active -> state.query
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, "")

    init {
        viewModelScope.launch {
            contactsRepository.knownContactsFlow()
                .mapLatest { UiState.Success(it) }
                .catch { UiState.Error(it.message ?: "") }
                .collect { _uiState.value = it }
        }

        viewModelScope.launch {
            searchQuery
                .debounce(400)
                .distinctUntilChanged()
                .collect { query ->
                    val currentState = _searchState.value
                    if (query.isNotEmpty()) {
                        performSearch(
                            query,
                            currentState is SearchState.Active && currentState.isFocused
                        )
                    } else if (currentState is SearchState.Active && !currentState.isFocused) {
                        _searchState.value = SearchState.Idle
                    }
                }
        }
    }

    fun updateSearchQuery(query: String) {
        val currentState = _searchState.value
        when (currentState) {
            is SearchState.Idle -> {
                if (query.isNotEmpty()) {
                    _searchState.value = SearchState.Active(
                        query = query,
                        isFocused = false,
                        remoteState = RemoteSearchState.Loading,
                        localResults = emptyList()
                    )
                }
            }

            is SearchState.Active -> {
                _searchState.value = currentState.copy(query = query)
                if (query.isEmpty() && !currentState.isFocused) {
                    _searchState.value = SearchState.Idle
                }
            }
        }
    }

    fun setSearchFocused(focused: Boolean) {
        val currentState = _searchState.value
        when (currentState) {
            is SearchState.Idle -> {
                if (focused) {
                    _searchState.value = SearchState.Active(
                        query = "",
                        isFocused = focused,
                        remoteState = RemoteSearchState.AwaitingQuery,
                        localResults = emptyList()
                    )
                }
            }

            is SearchState.Active -> {
                _searchState.value = currentState.copy(isFocused = focused)
                if (!focused && currentState.query.isEmpty()) {
                    _searchState.value = SearchState.Idle
                }
            }
        }
    }

    private suspend fun performSearch(query: String, isFocused: Boolean) {
        _searchState.value = SearchState.Active(
            query = query,
            isFocused = isFocused,
            remoteState = RemoteSearchState.Loading,
            localResults = emptyList()
        )

        val remoteJob = viewModelScope.async {
            try {
                contactsRepository.remoteSearch(query)
            } catch (e: Exception) {
                throw e
            }
        }

        val localJob = viewModelScope.async {
            try {
                contactsRepository.localSearch(query)
            } catch (e: Exception) {
                emptyList()
            }
        }

        try {
            val localResults = localJob.await()
            val currentState = _searchState.value
            if (currentState is SearchState.Active && currentState.query == query) {
                _searchState.value = currentState.copy(localResults = localResults)
            }
        } catch (e: Exception) {
        }

        try {
            val remoteResults = remoteJob.await()
            val currentState = _searchState.value
            if (currentState is SearchState.Active && currentState.query == query) {
                _searchState.value = currentState.copy(
                    remoteState = RemoteSearchState.Success(remoteResults)
                )
            }
        } catch (e: Exception) {
            val currentState = _searchState.value
            if (currentState is SearchState.Active && currentState.query == query) {
                _searchState.value = currentState.copy(
                    remoteState = RemoteSearchState.Error(e.message ?: "Remote search failed")
                )
            }
        }
    }
}