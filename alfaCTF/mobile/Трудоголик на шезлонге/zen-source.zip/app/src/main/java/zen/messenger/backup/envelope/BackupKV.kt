package zen.messenger.backup.envelope

import kotlinx.serialization.Serializable

@Serializable
data class BackupKV(val key: String, val value: String)
