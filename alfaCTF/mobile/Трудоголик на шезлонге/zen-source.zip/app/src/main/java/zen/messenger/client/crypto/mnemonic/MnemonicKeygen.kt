package zen.messenger.client.crypto.mnemonic

import cash.z.ecc.android.bip39.Mnemonics
import cash.z.ecc.android.bip39.toSeed
import zen.messenger.data.repository.mnemonicSeparator
import zen.messenger.util.joinCharArrays

abstract class MnemonicKeygen<T> {
    abstract fun keyFromBytes(bytes: ByteArray): T

    fun keyFromMnemonic(mnemonic: List<CharArray>): T {
        val code = joinCharArrays(mnemonic, mnemonicSeparator)
        val seed = Mnemonics.MnemonicCode(code).toSeed().sliceArray(0..31)
        return keyFromBytes(seed)
    }

    companion object {
        fun generateMnemonic(): List<CharArray> {
            return Mnemonics.MnemonicCode(Mnemonics.WordCount.COUNT_12).words
        }

        fun validateMnemonic(mnemonic: List<CharArray>): Boolean {
            return try {
                Mnemonics.MnemonicCode(joinCharArrays(mnemonic, charArrayOf(' '))).validate()
                true
            } catch (e: Exception) {
                false
            }
        }
    }
}