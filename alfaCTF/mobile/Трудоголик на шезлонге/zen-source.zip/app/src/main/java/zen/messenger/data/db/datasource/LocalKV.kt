package zen.messenger.data.db.datasource

import app.cash.sqldelight.coroutines.asFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import zen.messenger.data.db.schema.Database
import zen.messenger.data.db.schema.StringKVRecord

class LocalStringKV(val db: Database) {
    fun get(key: String): String? {
        return db.stringKVQueries.get(key).executeAsOneOrNull()
    }

    fun flow(key: String): Flow<String?> {
        return db.stringKVQueries.get(key).asFlow().map { it -> it.executeAsOneOrNull() }
    }

    fun set(key: String, value: String) {
        if (value.isEmpty()) {
            db.stringKVQueries.delete(key)
        } else {
            db.stringKVQueries.set(key, value)
        }
    }

    fun all(): List<StringKVRecord> {
        return db.stringKVQueries.all().executeAsList()
    }
}