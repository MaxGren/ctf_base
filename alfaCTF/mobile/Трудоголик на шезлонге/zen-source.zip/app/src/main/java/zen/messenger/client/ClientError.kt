package zen.messenger.client

abstract class ClientError(code: String, msg: String) : Exception(msg.ifEmpty { code })