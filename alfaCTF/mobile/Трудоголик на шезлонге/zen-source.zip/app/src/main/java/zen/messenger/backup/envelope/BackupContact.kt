package zen.messenger.backup.envelope

import kotlinx.serialization.Serializable

@Serializable
data class BackupContact(
    val id: String,
    val username: String,
    val name: String?,
    val signingKey: ByteArray,
    val identityKey: ByteArray,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as BackupContact

        if (id != other.id) return false
        if (username != other.username) return false
        if (name != other.name) return false
        if (!signingKey.contentEquals(other.signingKey)) return false
        if (!identityKey.contentEquals(other.identityKey)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + username.hashCode()
        result = 31 * result + (name?.hashCode() ?: 0)
        result = 31 * result + signingKey.contentHashCode()
        result = 31 * result + identityKey.contentHashCode()
        return result
    }
}