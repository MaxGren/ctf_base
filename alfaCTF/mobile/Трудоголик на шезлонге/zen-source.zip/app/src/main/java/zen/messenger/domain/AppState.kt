package zen.messenger.domain

enum class AppState {
    LOADING,
    KEY_GENERATION,
    USERNAME_REGISTRATION,
    LICENSE_AGREEMENTS,
    BACKUP_CONFIG,
    READY
}