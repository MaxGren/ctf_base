package zen.messenger.client.repository

import kotlinx.coroutines.flow.Flow
import zen.messenger.client.crypto.SessionKey
import zen.messenger.client.crypto.ZenKeypair
import zen.messenger.client.crypto.x25519.X25519PrivateKey

interface KeysRepository {
    fun getIdentity(): ZenKeypair?
    fun getIdentityFlow(): Flow<ZenKeypair?>

    fun saveIdentity(identity: ZenKeypair)

    fun getPrekey(): X25519PrivateKey?
    fun savePrekey(pair: X25519PrivateKey)

    fun getSessionKey(id: String): SessionKey?
    fun saveSessionKey(id: String, key: SessionKey)
}