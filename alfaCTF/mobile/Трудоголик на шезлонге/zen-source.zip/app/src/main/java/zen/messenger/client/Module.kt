package zen.messenger.client

import io.grpc.Channel
import io.grpc.ManagedChannelBuilder
import org.koin.dsl.module
import zen.messenger.BuildConfig
import java.util.concurrent.TimeUnit

fun clientModule() = module {
    single<Channel> {
        ManagedChannelBuilder
            .forAddress(BuildConfig.GRPC_HOST, BuildConfig.GRPC_PORT)
            .apply {
                if (BuildConfig.GRPC_USE_TLS) {
                    useTransportSecurity()
                } else {
                    usePlaintext()
                }
            }
            .keepAliveTime(30, TimeUnit.SECONDS)
            .keepAliveTimeout(5, TimeUnit.SECONDS)
            .keepAliveWithoutCalls(true)
            .maxInboundMessageSize(4 * 1024 * 1024)
            .enableRetry()
            .build()
    }

    single {
        ZenClient(get(), get(), get())
    }
}

