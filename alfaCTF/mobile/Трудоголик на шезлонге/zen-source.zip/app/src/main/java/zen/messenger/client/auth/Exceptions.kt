package zen.messenger.client.auth

import zen.messenger.client.ClientError
import zen.messenger.client.proto.PubkeyOwnershipProofErrorCode
import zen.messenger.client.proto.RegisterPubkeyErrorCode

class RegisterPubkeyException(code: RegisterPubkeyErrorCode, msg: String) :
    ClientError(code.name, msg)

class PubkeyOwnershipProofException(code: PubkeyOwnershipProofErrorCode, msg: String) :
    ClientError(code.name, msg)