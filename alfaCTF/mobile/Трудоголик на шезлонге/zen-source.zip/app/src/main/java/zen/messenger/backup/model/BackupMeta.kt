package zen.messenger.backup.model

import kotlinx.serialization.Serializable
import zen.messenger.util.InstantSerializer
import java.time.Instant

@Serializable
data class BackupMeta(
    val id: String,
    @Serializable(with = InstantSerializer::class) val createdAt: Instant,
    val contactsCount: Int,
    val messagesCount: Int
)
