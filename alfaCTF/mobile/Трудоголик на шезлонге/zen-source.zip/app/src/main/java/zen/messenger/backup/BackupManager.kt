package zen.messenger.backup

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import zen.messenger.backup.keysprovider.KeysProviderClient
import zen.messenger.backup.model.BackupMeta
import zen.messenger.backup.model.CloudBackup
import zen.messenger.backup.model.LocalBackup
import zen.messenger.backup.model.UploadedBackupInfo
import zen.messenger.backup.repository.BackupRepository
import zen.messenger.backup.strategy.StrategyRegistry
import zen.messenger.client.crypto.EncryptedData
import zen.messenger.client.crypto.x25519.HKDFDerivation
import zen.messenger.client.repository.KeysRepository
import zen.messenger.domain.model.ServiceMessageContent
import zen.messenger.domain.repository.MessagesRepository
import java.io.File
import java.time.Instant


private const val TAG = "BackupManager"

class BackupManager(
    private val messagesRepository: MessagesRepository,
    private val keysRepository: KeysRepository,
    private val backupRepository: BackupRepository,

    private val keysProviderClient: KeysProviderClient,
    private val collector: BackupOperator,
    private val httpClient: OkHttpClient,

    private val rootPath: String,
) {
    companion object {
        private const val BACKUP_FILE_NAME = "backup.dat"
        private const val BACKUP_META_NAME = "meta.json"
        private const val BACKUP_UPLOADED_TO_NAME = ".uploaded_to"
    }

    private val keyID by lazy {
        HKDFDerivation.deriveKey(
            keysRepository.getIdentity()!!.identity.encoded,
            HKDFDerivation.BACKUP_USER_ID_DERIVATION_INFO
        ).toHexString()
    }

    fun handleRegionUpdates(scope: CoroutineScope) {
        scope.launch {
            messagesRepository.subscribeServicePending { it.content is ServiceMessageContent.RegionBackupProviders }
                .collect {
                    it.content as ServiceMessageContent.RegionBackupProviders

                    val currentEndpoint = keysProviderClient.currentEndpoint()
                    if (it.content.keyEndpoint != currentEndpoint) {
                        keysProviderClient.setEndpoint(it.content.keyEndpoint)
                    }

                    val newProviders = it.content.providers.filter { p -> p.id != "local" && p.strategy != "local" }
                    backupRepository.updateProviders(newProviders)

                    val currentProviderID = backupRepository.getCurrentProviderID()
                    if (currentProviderID != null && newProviders.any { provider -> provider.id == currentProviderID }) {
                        try {
                            backup()
                        } catch (e: Exception) {
                            Log.e(TAG, "Unable to backup", e)
                        }
                    }

                    messagesRepository.ackIncoming(it.serverID!!)
                }
        }
    }

    private fun loadBackup(
        path: String,
        loadBackupData: Boolean = false
    ): Pair<LocalBackup, EncryptedData?> {
        val metaFile = File(path, BACKUP_META_NAME)
        val backupFile = File(path, BACKUP_FILE_NAME)
        val uploadedInfo = File(path, BACKUP_UPLOADED_TO_NAME)

        if (!metaFile.exists()) {
            throw Exception("Backup meta file ${metaFile.path} not found")
        }

        if (!backupFile.exists()) {
            throw Exception("Backup file ${backupFile.path} not found")
        }

        val metaData = Json.decodeFromString<BackupMeta>(metaFile.readText())
        val backupData = if (loadBackupData) {
            Json.decodeFromString<EncryptedData>(backupFile.readText())
        } else {
            null
        }
        val uploadedTo =
            if (uploadedInfo.exists()) Json.decodeFromString<UploadedBackupInfo>(uploadedInfo.readText()) else null

        return LocalBackup(metaData, path, uploadedTo) to backupData
    }

    suspend fun backup() {
        Log.d(TAG, "Backup requested")
        val encryptionKey = try {
            keysProviderClient.getKey(keyID)
        } catch (e: Exception) {
            Log.e(TAG, "Unable to get encryption key", e)
            return
        }
        val backup = collector.collect()
        val encrypted = encryptionKey.encrypt(backup.second)

        val backupDir = File("$rootPath/${backup.first.createdAt}_${backup.first.id}")
        backupDir.mkdirs()
        Log.d(TAG, "Backing up to ${backupDir.absolutePath}")

        val backupFile = File(backupDir, BACKUP_FILE_NAME)
        val encryptedBytes = Json.encodeToString(encrypted).toByteArray()
        backupFile.writeBytes(encryptedBytes)

        val metaFile = File(backupDir, BACKUP_META_NAME)
        metaFile.writeText(Json.encodeToString(backup.first))

        val result = LocalBackup(meta = backup.first, path = backupDir.absolutePath)
        Log.d(TAG, "Successfully backed up to ${backupDir.absolutePath}")
        try {
            upload(result)
        } catch (e: Exception) {
            Log.e(TAG, "Unable to upload backup", e)
        }
    }

    suspend fun upload(localBackup: LocalBackup) {
        val currentProvider = backupRepository.getCurrentProvider()
        if (currentProvider == null) {
            Log.d(TAG, "No backup provider to upload ${localBackup.path}")
            return
        }

        val loaded = loadBackup(localBackup.path, true)

        Log.d(TAG, "Uploading backup ${localBackup.path} to ${currentProvider.id}")

        val strategy = try {
            StrategyRegistry.newStrategy(currentProvider, httpClient)
        } catch (e: Exception) {
            Log.e(TAG, "Unable to create strategy for ${currentProvider.id}", e)
            return
        }
        strategy.upload(keyID, loaded.second!!.toJson().toByteArray(), loaded.first.meta)
        val uploadedBackupInfo = UploadedBackupInfo(
            providerID = currentProvider.id,
            uploadedAt = Instant.now()
        )
        val serializedUbi = Json.encodeToString(uploadedBackupInfo)
        File(localBackup.path, BACKUP_UPLOADED_TO_NAME).writeText(serializedUbi)
        Log.d(TAG, "Successfully uploaded backup ${localBackup.path} to ${currentProvider.id}")
    }

    fun lookForLocalBackups(): List<LocalBackup> {
        return File(rootPath).listFiles()?.filter(File::isDirectory)?.mapNotNull { subdir ->
            try {
                loadBackup(subdir.path, false).first
            } catch (e: Exception) {
                Log.w(TAG, "Invalid backup in $subdir", e)
                null
            }
        }?.toList()?.sortedByDescending { it.meta.createdAt } ?: emptyList()
    }

    suspend fun lookForCloudBackups(providerID: String? = null): List<CloudBackup> {
        val provider = if (providerID != null) {
            backupRepository.getProviderByID(providerID)
        } else {
            backupRepository.getCurrentProvider()
        }

        if (provider == null) return emptyList()

        val strategy = StrategyRegistry.newStrategy(provider, httpClient)

        return try {
            strategy.latestUploadedBackup(keyID)?.let { listOf(it) } ?: emptyList()
        } catch (e: Exception) {
            Log.e(TAG, "Unable to fetch latest backup", e)
            emptyList()
        }
    }

    suspend fun fetch(cloudBackup: CloudBackup, restore: Boolean = true): LocalBackup {
        val provider = backupRepository.getProviderByID(cloudBackup.providerID)
            ?: throw Exception("Provider not found: ${cloudBackup.providerID}")

        val strategy = StrategyRegistry.newStrategy(provider, httpClient)
        val bytes = strategy.fetch(keyID, cloudBackup.meta.id)

        val backupDir = File("$rootPath/${cloudBackup.meta.createdAt}_${cloudBackup.meta.id}")
        if (!backupDir.exists()) {
            backupDir.mkdirs()
        }

        File(backupDir, BACKUP_FILE_NAME).writeBytes(bytes)
        File(backupDir, BACKUP_META_NAME).writeText(Json.encodeToString(cloudBackup.meta))

        val uploadedBackupInfo = UploadedBackupInfo(
            providerID = cloudBackup.providerID,
            uploadedAt = cloudBackup.uploadedAt
        )
        val serializedUbi = Json.encodeToString(uploadedBackupInfo)
        File(backupDir, BACKUP_UPLOADED_TO_NAME).writeText(serializedUbi)


        val result = LocalBackup(
            meta = cloudBackup.meta,
            path = backupDir.absolutePath
        )

        if (restore) {
            restore(result.path)
        }
        return result
    }

    suspend fun restore(path: String) {
        val loaded = loadBackup(path, true)
        val decryptionKey = keysProviderClient.getKey(keyID)
        val decryptedData = decryptionKey.decrypt(loaded.second!!)!!
        collector.restore(decryptedData, loaded.first.meta)
        Log.d(TAG, "Successfully restored backup")
    }
}