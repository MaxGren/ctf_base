package zen.messenger.util

fun joinCharArrays(arrays: List<CharArray>, separator: CharArray): CharArray {
    if (arrays.isEmpty()) return charArrayOf()

    val totalSize = arrays.sumOf { it.size } + (arrays.size - 1) * separator.size
    val result = CharArray(totalSize)
    var index = 0

    arrays.forEachIndexed { i, array ->
        array.copyInto(result, index)
        index += array.size

        if (i < arrays.size - 1) {
            separator.copyInto(result, index)
            index += separator.size
        }
    }

    return result
}