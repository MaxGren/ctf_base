package zen.messenger.client.crypto.x25519

import zen.messenger.client.crypto.mnemonic.MnemonicKeygen

class X25519MnemonicKeygen : MnemonicKeygen<X25519PrivateKey>() {
    override fun keyFromBytes(bytes: ByteArray): X25519PrivateKey {
        return X25519PrivateKey(bytes)
    }
}