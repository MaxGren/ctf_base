package zen.messenger.client.auth

import io.grpc.CallOptions
import io.grpc.Channel
import io.grpc.ClientCall
import io.grpc.ClientInterceptor
import io.grpc.Metadata
import io.grpc.MethodDescriptor
import io.grpc.Status
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import zen.messenger.client.repository.KeysRepository
import zen.messenger.client.repository.TokensRepository

internal class AuthInterceptor(
    private val tokensRepository: TokensRepository,
    private val keysRepository: KeysRepository,
    private val pubkeyServiceClient: PubkeyServiceClient
) : ClientInterceptor {
    private val refreshMutex = Mutex()

    suspend fun getToken(forceRefresh: Boolean = false): String? {
        refreshMutex.withLock {
            if (!forceRefresh) {
                tokensRepository.get()?.let { return it }
            }
            val identity = requireNotNull(keysRepository.getIdentity()) { "Identity key is null" }
            val prekey = requireNotNull(keysRepository.getPrekey()) { "Prekey is null" }
            val result = pubkeyServiceClient.registerPubkey(identity, prekey.asPublicKey())
            tokensRepository.set(result)
            return result
        }
    }

    override fun <ReqT : Any?, RespT : Any?> interceptCall(
        method: MethodDescriptor<ReqT?, RespT?>?,
        callOptions: CallOptions?,
        next: Channel?
    ): ClientCall<ReqT?, RespT?>? {
        requireNotNull(next) { "Auth interceptor expects channel to be not-null" }
        return AuthRetryingCall(next.newCall(method, callOptions), method, callOptions, next)
    }

    private inner class AuthRetryingCall<ReqT, RespT>(
        private var delegate: ClientCall<ReqT?, RespT?>,
        private val method: MethodDescriptor<ReqT?, RespT?>?,
        private val callOptions: CallOptions?,
        private val channel: Channel
    ) : ClientCall<ReqT, RespT>() {
        private var originalListener: Listener<RespT>? = null
        private var originalHeaders: Metadata? = null
        private var requestMessage: ReqT? = null
        private var callHasRetried = false

        override fun halfClose() = delegate.halfClose()
        override fun request(numMessages: Int) = delegate.request(numMessages)
        override fun cancel(message: String?, cause: Throwable?) = delegate.cancel(message, cause)

        override fun start(responseListener: Listener<RespT>?, headers: Metadata?) {
            originalListener = responseListener
            originalHeaders = headers
            startWithAuth(false)
        }

        override fun sendMessage(message: ReqT) {
            requestMessage = message
            delegate.sendMessage(message)
        }

        val listener = object : Listener<RespT?>() {
            override fun onClose(status: Status, trailers: Metadata) {
                try {
                    if (status.code == Status.Code.UNAUTHENTICATED && !callHasRetried) {
                        callHasRetried = true
                        delegate = channel.newCall(method, callOptions)
                        startWithAuth(true)
                        requestMessage?.let { delegate.sendMessage(it) }
                        delegate.halfClose()
                    } else {
                        originalListener?.onClose(status, trailers)
                    }
                } finally {
                    originalHeaders = null
                    originalListener = null
                }
            }

            override fun onMessage(message: RespT?) = originalListener?.onMessage(message) ?: Unit
            override fun onHeaders(headers: Metadata) = originalListener?.onHeaders(headers) ?: Unit
            override fun onReady() = originalListener?.onReady() ?: Unit
        }

        private fun startWithAuth(isRetry: Boolean) {
            val token = runBlocking { getToken(isRetry) }
            val authHeaders = Metadata().apply {
                originalHeaders?.let { merge(it) }
                token?.let { put(AUTH_KEY, "Bearer $it") }
            }

            delegate.start(listener, authHeaders)
        }
    }

    companion object {
        private val AUTH_KEY = Metadata.Key.of("authorization", Metadata.ASCII_STRING_MARSHALLER)
    }
}