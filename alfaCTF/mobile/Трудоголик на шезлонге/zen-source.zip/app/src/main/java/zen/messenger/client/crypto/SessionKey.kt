package zen.messenger.client.crypto

import org.bouncycastle.crypto.modes.ChaCha20Poly1305
import org.bouncycastle.crypto.params.AEADParameters
import org.bouncycastle.crypto.params.KeyParameter
import java.security.SecureRandom

data class SessionKey(val bytes: ByteArray) {
    val params by lazy {
        KeyParameter(bytes, 0, bytes.size)
    }

    fun decrypt(bytes: ByteArray, nonce: ByteArray): ByteArray? {
        return try {
            with(ChaCha20Poly1305()) {
                init(false, AEADParameters(params, MAC_SIZE, nonce))
                val buf = ByteArray(getOutputSize(bytes.size))
                val processedBytes = processBytes(bytes, 0, bytes.size, buf, 0)
                val finalBytes = doFinal(buf, processedBytes)
                buf.copyOf(processedBytes + finalBytes)
            }
        } catch (e: Exception) {
            throw e
        }
    }

    fun decrypt(data: EncryptedData): ByteArray? {
        return decrypt(data.ciphertext, data.nonce)
    }

    fun encrypt(bytes: ByteArray): EncryptedData {
        val nonce = ByteArray(NONCE_SIZE)
        random.nextBytes(nonce)
        with(ChaCha20Poly1305()) {
            init(true, AEADParameters(params, MAC_SIZE, nonce))
            val buf = ByteArray(getOutputSize(bytes.size))
            val processedBytes = processBytes(bytes, 0, bytes.size, buf, 0)
            val finalBytes = doFinal(buf, processedBytes)
            val result = buf.copyOf(processedBytes + finalBytes)
            return EncryptedData(result, nonce)
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as SessionKey

        return bytes.contentEquals(other.bytes)
    }

    override fun hashCode(): Int {
        return bytes.contentHashCode()
    }

    companion object {
        val random by lazy { SecureRandom() }
        const val MAC_SIZE = 128
        const val NONCE_SIZE = 12
    }
}
