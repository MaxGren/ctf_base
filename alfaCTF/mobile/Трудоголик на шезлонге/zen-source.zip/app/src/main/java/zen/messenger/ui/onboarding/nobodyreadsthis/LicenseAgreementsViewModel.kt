package zen.messenger.ui.onboarding.nobodyreadsthis

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import zen.messenger.domain.model.AckStatus
import zen.messenger.domain.model.LicenseAgreement
import zen.messenger.domain.model.ServiceMessage
import zen.messenger.domain.model.ServiceMessageContent
import zen.messenger.domain.repository.MessagesRepository

data class UiState(
    val agreements: List<LicenseAgreement> = emptyList(),
)

class LicenseAgreementsViewModel(private val msgRepo: MessagesRepository) : ViewModel() {
    private val _pendingMessages = MutableStateFlow(emptyList<ServiceMessage>())

    val uiState: StateFlow<UiState> = _pendingMessages.asStateFlow().map {
        UiState(
            agreements = it
                .map { msg -> (msg.content as ServiceMessageContent.LicenseAgreements).agreements }
                .flatten()
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(),
        initialValue = UiState(agreements = emptyList())
    )

    init {
        viewModelScope.launch {
            msgRepo.serviceMessagesFlow().map { list ->
                list.filter { it.content is ServiceMessageContent.LicenseAgreements && it.ackStatus == AckStatus.IN_PENDING }
            }.collect { _pendingMessages.emit(it) }
        }
    }

    fun accept() {
        viewModelScope.launch {
            _pendingMessages.value.forEach {
                it.serverID?.let { id -> msgRepo.ackIncoming(id) }
            }
        }
    }
}