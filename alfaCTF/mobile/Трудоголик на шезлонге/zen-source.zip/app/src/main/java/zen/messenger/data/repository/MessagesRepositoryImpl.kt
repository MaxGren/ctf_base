package zen.messenger.data.repository

import android.util.Log
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import zen.messenger.client.ZenClient
import zen.messenger.data.db.datasource.LocalContacts
import zen.messenger.data.db.datasource.LocalMessages
import zen.messenger.domain.model.Ack
import zen.messenger.domain.model.AckStatus
import zen.messenger.domain.model.Contact
import zen.messenger.domain.model.Message
import zen.messenger.domain.model.MessageMeta
import zen.messenger.domain.model.ServiceMessage
import zen.messenger.domain.model.TextMessage
import zen.messenger.domain.repository.MessagesRepository
import java.time.Instant

class MessagesRepositoryImpl(
    val local: LocalMessages,
    val localContacts: LocalContacts,
    val remote: ZenClient
) : MessagesRepository {

    private val messageFlow = MutableSharedFlow<Message>(extraBufferCapacity = 50)
    private val serviceMessageFlow = MutableSharedFlow<ServiceMessage>(extraBufferCapacity = 50)

    override suspend fun get(
        contactID: String,
        limit: Long,
        offsetID: Long?
    ): List<Message> = local.getMessages(contactID, limit, offsetID)

    override suspend fun getNewSince(
        contactID: String,
        offsetID: Long
    ): Flow<List<Message>> = local.getNewMessagesFlow(contactID, offsetID)

    override suspend fun handleIncoming(msg: Message, from: Contact?): Message {
        if (msg is Ack) {
            if (msg.serverID == null) {
                Log.w("MessagesRepository", "Ack without serverID")
                return msg
            }
            local.setAckStatus(msg.serverID!!, msg.ackStatus)
            return msg
        }

        if (msg !is ServiceMessage && from != null) {
            localContacts.rememberContact(from)
        }

        val updatedMessage = local.addMessage(msg)
        if (msg is ServiceMessage) {
            serviceMessageFlow.emit(msg)
        }
        messageFlow.emit(updatedMessage)
        return updatedMessage
    }

    override suspend fun ackIncoming(serverID: String) {
        val message = local.getByServerID(serverID)
        if (message == null) {
            Log.w("MessagesRepository", "Ack on unknown message $serverID")
            return
        }

        if (message.ackStatus != AckStatus.IN_PENDING) {
            return
        }

        try {
            remote.sendAck(serverID)
            message.internalID?.let { internalID ->
                local.setAckStatus(internalID, AckStatus.IN_ACKED)
            }
        } catch (e: Exception) {
            Log.e("MessagesRepository", "Error sending ack", e)
        }
    }

    override fun subscribeIncomingPending(filter: (Message) -> Boolean): Flow<Message> = flow {
        local.getIncomingPending().filter(filter).forEach { emit(it) }
        messageFlow.filter(filter).collect { emit(it) }
    }

    override fun serviceMessagesFlow(): Flow<List<ServiceMessage>> = local.allMessagesFlow()
        .map { it.filterIsInstance<ServiceMessage>() }

    @OptIn(ExperimentalCoroutinesApi::class)
    override fun subscribeServicePending(filter: (ServiceMessage) -> Boolean): Flow<ServiceMessage> =
        flow {
            local.getIncomingPending().filter { it is ServiceMessage && filter(it) }
                .forEach { emit(it as ServiceMessage) }
            serviceMessageFlow.filter(filter).collect { emit(it) }
        }

    override suspend fun sendText(contactID: String, text: String) {
        val textMessage = TextMessage(
            meta = MessageMeta(
                contactID = contactID,
                timestampUTC = Instant.now(),
                ackStatus = AckStatus.OUT_PENDING
            ),
            toMe = false,
            text = text
        )

        val savedMsg = local.addMessage(textMessage) as TextMessage

        try {
            val serverID = remote.sendMessage(savedMsg)
            savedMsg.internalID?.let { internalID ->
                local.markSent(internalID, serverID)
            }
        } catch (e: Exception) {
            Log.e("MessagesRepository", "Unknown error sending message", e)
            savedMsg.internalID?.let { internalID ->
                local.setAckStatus(internalID, AckStatus.OUT_SEND_FAILED)
            }
        }
    }
}