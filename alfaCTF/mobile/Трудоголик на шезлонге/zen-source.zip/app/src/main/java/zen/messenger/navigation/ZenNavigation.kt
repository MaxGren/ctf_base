package zen.messenger.navigation

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import org.koin.compose.koinInject
import zen.messenger.domain.AppState
import zen.messenger.domain.StateManager
import zen.messenger.ui.onboarding.backup.BackupProvidersScreen
import zen.messenger.ui.onboarding.keygen.KeyGenerationScreen
import zen.messenger.ui.onboarding.nobodyreadsthis.LicenseAgreementsScreen
import zen.messenger.ui.onboarding.username.UsernameRegistrationScreen

@Composable
fun ZenNavigation(innerPadding: PaddingValues) {
    val stateMgr = koinInject<StateManager>()
    val stateFlow = stateMgr.flow.collectAsStateWithLifecycle(AppState.LOADING)

    Surface(
        modifier =
            Modifier
                .fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        AnimatedContent(
            targetState = stateFlow.value,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            },
            modifier = Modifier.fillMaxSize(),
        ) { state ->
            when (state) {
                AppState.LOADING -> {}
                AppState.KEY_GENERATION -> {
                    KeyGenerationScreen(innerPadding)
                }

                AppState.USERNAME_REGISTRATION -> {
                    UsernameRegistrationScreen(innerPadding)
                }

                AppState.LICENSE_AGREEMENTS -> {
                    LicenseAgreementsScreen(innerPadding)
                }

                AppState.BACKUP_CONFIG -> {
                    BackupProvidersScreen(innerPadding)
                }

                AppState.READY -> {
                    ReadyNavHost(Modifier.padding(innerPadding))
                }
            }
        }
    }
}
