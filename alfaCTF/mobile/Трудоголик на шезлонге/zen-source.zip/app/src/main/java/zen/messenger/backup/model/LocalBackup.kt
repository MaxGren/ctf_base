package zen.messenger.backup.model

data class LocalBackup(
    val meta: BackupMeta,
    val path: String,
    val uploadedBackupInfo: UploadedBackupInfo? = null
)