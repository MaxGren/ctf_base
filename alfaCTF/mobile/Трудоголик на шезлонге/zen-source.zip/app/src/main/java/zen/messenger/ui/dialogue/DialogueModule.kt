package zen.messenger.ui.dialogue

import org.koin.core.module.dsl.viewModel
import org.koin.dsl.module

fun dialogueViewModelModule() =
    module {
        viewModel { (id: String) -> DialogueViewModel(get(), get(), id) }
    }