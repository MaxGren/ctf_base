package zen.messenger

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import zen.messenger.client.ZenClient
import zen.messenger.domain.StateManager
import zen.messenger.domain.model.Message
import zen.messenger.domain.model.TextMessage
import zen.messenger.domain.repository.ContactsRepository
import zen.messenger.domain.repository.MessagesRepository
import kotlin.coroutines.cancellation.CancellationException

class MessageWorker(
    private val stateManager: StateManager,
    private val zenClient: ZenClient,
    private val msgRepository: MessagesRepository,
    private val contactsRepository: ContactsRepository,
) {
    private fun getIncomingMessagesRetryableFlow(): Flow<Message> = flow {
        var retryCount = 0
        Log.d("MessageWorker", "incomingMessagesFlow started")
        while (currentCoroutineContext().isActive) {
            try {
                zenClient.incomingMessagesFlow().collect { data ->
                    emit(data)
                    retryCount = 0
                }
            } catch (e: CancellationException) {
                Log.d("MessageWorker", "incomingMessagesFlow was cancelled")
                throw e
            } catch (e: Exception) {
                retryCount++
                val delayMs = minOf(1000 * (1 shl retryCount), 10000)
                Log.e(
                    "MessageWorker",
                    "Error $retryCount in incomingMessagesFlow (delay $delayMs)",
                    e
                )
                delay(delayMs.toLong())
            }
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
    private fun getIncoming(): Flow<Message> {
        return stateManager.clientUsableFlow.onEach {
            Log.d("MessageWorker", "Client usable: $it")
        }.flatMapLatest { shouldStream ->
            if (shouldStream) {
                getIncomingMessagesRetryableFlow()
            } else {
                emptyFlow()
            }
        }
    }


    fun start(scope: CoroutineScope) {
        scope.launch {
            getIncoming().collect {
                val contact = if (it is TextMessage) {
                    contactsRepository.getContact(it.contactID)
                } else {
                    null
                }

                try {
                    msgRepository.handleIncoming(it, contact)
                } catch (e: Exception) {
                    Log.e("MessageWorker", "Failed handling incoming message", e)
                }
            }
        }
    }
}