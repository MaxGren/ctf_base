package zen.messenger.domain.repository

import kotlinx.coroutines.flow.Flow
import zen.messenger.domain.model.Contact

interface ContactsRepository {
    fun rememberContact(contact: Contact)
    suspend fun getContact(id: String): Contact?
    fun knownContactsFlow(): Flow<List<Contact>>

    fun localSearch(query: String): List<Contact>
    suspend fun remoteSearch(username: String): List<Contact>

    suspend fun getMe(force: Boolean = false): Contact
    fun getCachedMeFlowable(): Flow<Contact?>
    suspend fun setMyUsername(username: String)
}