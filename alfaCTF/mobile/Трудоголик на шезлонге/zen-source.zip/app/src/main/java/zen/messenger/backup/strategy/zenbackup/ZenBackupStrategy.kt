package zen.messenger.backup.strategy.zenbackup

import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import zen.messenger.backup.model.BackupMeta
import zen.messenger.backup.model.CloudBackup
import zen.messenger.backup.strategy.Strategy
import java.io.IOException

class ZenBackupStrategy(private val httpClient: OkHttpClient, jsonConfig: String) : Strategy {
    private val json = Json { ignoreUnknownKeys = true }
    private val config = json.decodeFromString<ZenBackupStrategyConfig>(jsonConfig)
    private val baseUrl = config.baseUrl

    override suspend fun latestUploadedBackup(userID: String): CloudBackup? {
        val url = "$baseUrl/$userID/latest"
        val request = Request.Builder()
            .url(url)
            .get()
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Failed to fetch latest backup: ${response.code}")
                }

                if (response.code == 404) {
                    return null
                }

                val responseBody = response.body.string()
                if (responseBody.isEmpty()) {
                    throw IOException("Empty response body")
                }

                json.decodeFromString<CloudBackup>(responseBody)
            }
        } catch (e: Exception) {
            throw IOException("Failed to fetch latest backup", e)
        }
    }

    override suspend fun fetch(userID: String, id: String): ByteArray {
        val url = "$baseUrl/$userID/$id"
        val request = Request.Builder()
            .url(url)
            .get()
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Failed to fetch backup: ${response.code}")
                }

                val responseBody = response.body.bytes()
                if (responseBody.isEmpty()) {
                    throw IOException("Empty response body")
                }
                responseBody
            }
        } catch (e: Exception) {
            throw IOException("Failed to fetch backup", e)
        }
    }

    override suspend fun upload(
        userID: String,
        backup: ByteArray,
        metadata: BackupMeta
    ): String {
        val url = "$baseUrl/$userID"
        val multipartBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("backup", "backup.dat", backup.toRequestBody())
            .addFormDataPart(
                "metadata",
                "metadata.json",
                json.encodeToString(metadata).toRequestBody("application/json".toMediaType()),
            )
            .build()

        val request = Request.Builder()
            .url(url)
            .post(multipartBody)
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Failed to upload backup: ${response.code}")
                }

                val responseBody = response.body.string()
                if (responseBody.isEmpty()) {
                    throw IOException("Empty response body")
                }
                responseBody
            }
        } catch (e: Exception) {
            throw IOException("Failed to upload backup", e)
        }
    }
}