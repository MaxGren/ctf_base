package zen.messenger.client.crypto.ed25519

import org.bouncycastle.crypto.params.Ed25519PublicKeyParameters

data class Ed25519PublicKey(val encoded: ByteArray) {
    val publicKeyParams by lazy { Ed25519PublicKeyParameters(encoded, 0) }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Ed25519PublicKey

        if (!encoded.contentEquals(other.encoded)) return false
        if (publicKeyParams != other.publicKeyParams) return false

        return true
    }

    override fun hashCode(): Int {
        var result = encoded.contentHashCode()
        result = 31 * result + publicKeyParams.hashCode()
        return result
    }
}