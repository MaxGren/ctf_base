package zen.messenger.data.db.datasource

import app.cash.sqldelight.coroutines.asFlow
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import zen.messenger.data.db.schema.ContactRecord
import zen.messenger.data.db.schema.Database
import zen.messenger.domain.model.Contact

class LocalContacts(private val db: Database, private val stringKV: LocalStringKV) {
    fun ContactRecord.toContact(): Contact {
        return Contact(
            this.id,
            this.username,
            this.name ?: this.username,
            ByteArray(0),
            ByteArray(0),
        )
    }

    fun cacheContact(contact: Contact) {
        db.contactQueries.add(
            id = contact.id,
            username = contact.username,
            name = contact.name ?: contact.username,
            signing_key = contact.signingKey,
            identity_key = contact.identityKey,
        )
    }

    fun rememberContact(contact: Contact) {
        db.contactQueries.addKnown(
            id = contact.id,
            username = contact.username,
            name = contact.name ?: contact.username,
            signing_key = contact.signingKey,
            identity_key = contact.identityKey,
        )
    }

    fun renameContact(id: String, newName: String) {
        db.contactQueries.setName(id = id, name = newName)
    }

    fun get(id: String): Contact? {
        return db.contactQueries.getByID(id).executeAsOneOrNull()?.toContact()
    }

    fun getFlow(id: String): Flow<Contact?> {
        return db.contactQueries.getByID(id).asFlow().map { it.executeAsOneOrNull()?.toContact() }
    }

    fun getMe(): Contact? {
        return stringKV.get("me")?.let { get(it) }
    }

    fun setMe(id: String, contact: Contact) {
        stringKV.set("me", id)
        cacheContact(contact)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    fun getMeFlow(): Flow<Contact?> {
        return stringKV.flow("me").flatMapLatest { id ->
            id?.let { getFlow(it) } ?: flowOf(null)
        }
    }

    fun forgetContact(id: String) {
        db.contactQueries.forget(id)
    }

    fun list(): List<Contact> {
        return db.contactQueries.list().executeAsList().map { it.toContact() }
    }

    fun listFlow(): Flow<List<Contact>> {
        return db.contactQueries.list().asFlow()
            .map { it.executeAsList().map { cr -> cr.toContact() } }
    }

    fun search(query: String): List<Contact> {
        return db.contactQueries.search(query.replace("%", "\\%")).executeAsList().map {
            it.toContact()
        }
    }

    fun allContactRecords(): List<ContactRecord> {
        return db.contactQueries.list().executeAsList()
    }

    fun restoreContacts(contacts: List<ContactRecord>) {
        db.contactQueries.transaction {
            contacts.forEach {
                try {
                    db.contactQueries.restoreContact(
                        id = it.id,
                        username = it.username,
                        name = it.name,
                        signing_key = it.signing_key,
                        identity_key = it.identity_key,
                        known = it.known
                    )
                } catch (e: Exception) {
                    db.contactQueries.restoreContactUpdate(
                        id = it.id,
                        username = it.username,
                        name = it.name,
                        signing_key = it.signing_key,
                        identity_key = it.identity_key
                    )
                }
            }
        }
    }
}