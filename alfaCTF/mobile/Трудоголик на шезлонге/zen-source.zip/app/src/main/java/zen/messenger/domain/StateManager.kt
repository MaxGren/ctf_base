package zen.messenger.domain

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onStart
import zen.messenger.backup.repository.BackupRepository
import zen.messenger.client.repository.KeysRepository
import zen.messenger.domain.model.AckStatus
import zen.messenger.domain.model.ServiceMessageContent
import zen.messenger.domain.repository.ContactsRepository
import zen.messenger.domain.repository.MessagesRepository

@OptIn(ExperimentalCoroutinesApi::class)
class StateManager(
    private val keysRepository: KeysRepository,
    private val contactsRepository: ContactsRepository,
    private val messagesRepository: MessagesRepository,
    private val backupRepository: BackupRepository
) {
    private fun <T> Flow<T>.withDefault(defaultValue: T): Flow<T> =
        this.onStart {
            emit(defaultValue)
        }

    val _flow = MutableStateFlow(AppState.LOADING)
    val flow = _flow.asStateFlow()

    val clientUsableFlow = flow.map { it > AppState.KEY_GENERATION }.distinctUntilChanged()

    fun handleStateUpdates(scope: CoroutineScope) {
        combine(
            keysRepository.getIdentityFlow().withDefault(null),
            contactsRepository.getCachedMeFlowable().withDefault(null),
            messagesRepository.serviceMessagesFlow().withDefault(emptyList())
                .map { msg -> msg.filter { it.content is ServiceMessageContent.LicenseAgreements } },
            backupRepository.flowableCurrentProvider().withDefault(null).map { it == null },
        ) { identity, me, licenseAgreements, noBackupConfigured ->
            if (identity == null) {
                return@combine AppState.KEY_GENERATION
            }

            if (me == null || me.username.isEmpty()) {
                return@combine AppState.USERNAME_REGISTRATION
            }

            if (licenseAgreements.isEmpty() || licenseAgreements.any { it.ackStatus != AckStatus.IN_ACKED }) {
                return@combine AppState.LICENSE_AGREEMENTS
            }

            if (noBackupConfigured) {
                return@combine AppState.BACKUP_CONFIG
            }

            AppState.READY
        }.onEach { state ->
            Log.d("StateManager", "New state: $state")
            _flow.value = state
        }
            .launchIn(scope)
    }
}