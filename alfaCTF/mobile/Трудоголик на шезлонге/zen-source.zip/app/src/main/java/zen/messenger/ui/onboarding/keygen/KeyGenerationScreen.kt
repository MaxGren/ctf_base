package zen.messenger.ui.onboarding.keygen

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.koin.compose.viewmodel.koinViewModel
import kotlin.text.Typography.nbsp

@Composable
fun KeyGenerationScreen(
    innerPadding: PaddingValues = PaddingValues(),
    viewModel: KeyGenerationViewModel = koinViewModel()
) {
    val screenState by viewModel.screenState.collectAsState()
    val generatedSeedPhrase by viewModel.generatedSeedPhrase.collectAsState()
    val errorState by viewModel.errorState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = screenState == KeyGenerationScreenState.Initial,
            enter = fadeIn(animationSpec = tween(300)),
            exit = fadeOut(animationSpec = tween(300))
        ) {
            InitialScreen(
                onGenerateNew = { viewModel.provideSeedPhrase() },
                onEnterExisting = { viewModel.setScreenState(KeyGenerationScreenState.InputExisting) }
            )
        }

        AnimatedVisibility(
            visible = screenState == KeyGenerationScreenState.GeneratingNew,
            enter = fadeIn(animationSpec = tween(300)),
            exit = fadeOut(animationSpec = tween(300))
        ) {
            BackHandler(onBack = {
                viewModel.setScreenState(KeyGenerationScreenState.Initial)
            })

            if (generatedSeedPhrase.isEmpty()) {
                GeneratingScreen()
            } else {
                GeneratedSeedScreen(
                    seedPhrase = generatedSeedPhrase,
                    onContinue = {
                        viewModel.proceedWithGenerated()
                    },
                    onGoBack = {
                        viewModel.setScreenState(KeyGenerationScreenState.Initial)
                    }
                )
            }
        }

        AnimatedVisibility(
            visible = screenState == KeyGenerationScreenState.InputExisting,
            enter = fadeIn(animationSpec = tween(300)),
            exit = fadeOut(animationSpec = tween(300))
        ) {
            BackHandler(onBack = {
                viewModel.setScreenState(KeyGenerationScreenState.Initial)
            })

            InputExistingScreen(
                onContinue = { seedPhrase ->
                    viewModel.proceedWithSeedPhrase(seedPhrase)
                },
                onGoBack = { viewModel.setScreenState(KeyGenerationScreenState.Initial) },
                errorState = errorState,
                onInputChanged = { viewModel.clearError() }
            )
        }
    }
}

@Composable
private fun InitialScreen(
    onGenerateNew: () -> Unit,
    onEnterExisting: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "— двенадцать${nbsp}слов?",
            fontStyle = FontStyle.Italic,
            fontSize = 30.sp,
            lineHeight = 36.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(onClick = onEnterExisting) {
            Text(text = "— двенадцать слов.")
        }

        Button(onClick = onGenerateNew) {
            Text(text = "— двенадцать слов?")
        }
    }
}

@Composable
private fun GeneratingScreen() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "двенадцать${nbsp}слов...",
            fontStyle = FontStyle.Italic,
            fontSize = 30.sp,
            lineHeight = 36.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        Text(
            text = "нужно подумать",
            fontSize = 18.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun SeedWordField(
    index: Int,
    word: String,
    isInputMode: Boolean,
    onValueChange: (String) -> Unit = {},
    focusRequester: FocusRequester? = null,
    onNext: () -> Unit = {},
    onDone: () -> Unit = {}
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "${index + 1}",
                fontSize = 56.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray.copy(alpha = 0.15f),
                textAlign = TextAlign.Center
            )
        }

        if (isInputMode) {
            BasicTextField(
                value = word,
                onValueChange = onValueChange,
                modifier = Modifier
                    .fillMaxSize()
                    .wrapContentSize(Alignment.Center)
                    .padding(top = 4.dp)
                    .then(
                        if (focusRequester != null) Modifier.focusRequester(focusRequester)
                        else Modifier
                    ),
                textStyle = TextStyle(
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center,
                    color = LocalContentColor.current
                ),
                singleLine = true,
                cursorBrush = SolidColor(LocalContentColor.current),
                keyboardOptions = KeyboardOptions(
                    imeAction = if (index < 11) ImeAction.Next else ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onNext = { onNext() },
                    onDone = { onDone() }
                )
            )
        } else {
            Text(
                text = word,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 4.dp)
                    .wrapContentSize(Alignment.Center)
            )
        }
    }
}

@Composable
private fun GeneratedSeedScreen(
    seedPhrase: List<CharArray>,
    onContinue: () -> Unit,
    onGoBack: () -> Unit
) {
    AnimatedVisibility(
        visible = seedPhrase.isNotEmpty(),
        enter = fadeIn(animationSpec = tween(500))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "двенадцать${nbsp}слов,",
                fontStyle = FontStyle.Italic,
                fontSize = 30.sp,
                lineHeight = 36.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                itemsIndexed(seedPhrase) { index, word ->
                    SeedWordField(
                        index = index,
                        word = String(word),
                        isInputMode = false
                    )
                }
            }

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Button(onClick = onContinue) {
                    Text(text = "— хорошо, я запомню их.")
                }

                Button(onClick = onGoBack) {
                    Text(text = "— у меня есть другие.")
                }
            }
        }
    }
}

@Composable
private fun InputExistingScreen(
    onContinue: (List<String>) -> Unit,
    onGoBack: () -> Unit,
    errorState: String?,
    onInputChanged: () -> Unit
) {
    val focusRequesters = remember { List(12) { FocusRequester() } }
    val focusManager = LocalFocusManager.current

    val viewModel: KeyGenerationViewModel = koinViewModel()
    val inputFields by viewModel.inputFields.collectAsState()

    val allFieldsFilled = inputFields.all { it.trim().isNotEmpty() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "двенадцать${nbsp}слов:",
            fontStyle = FontStyle.Italic,
            fontSize = 30.sp,
            lineHeight = 36.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            itemsIndexed(inputFields) { index, word ->
                SeedWordField(
                    index = index,
                    word = word,
                    isInputMode = true,
                    onValueChange = { newValue ->
                        viewModel.updateInputField(index, newValue)
                        onInputChanged()
                    },
                    focusRequester = focusRequesters[index],
                    onNext = {
                        if (index < 11) {
                            focusRequesters[index + 1].requestFocus()
                        }
                    },
                    onDone = {
                        focusManager.clearFocus()
                    }
                )
            }
        }

        errorState?.let { error ->
            Text(
                text = error,
                color = MaterialTheme.colorScheme.error,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Button(
                onClick = {
                    onContinue(inputFields)
                },
                enabled = allFieldsFilled
            ) {
                Text(text = "— вот они.")
            }

            Button(onClick = onGoBack) {
                Text(text = "— не помню...")
            }
        }
    }
}