package zen.messenger.client.crypto.x25519

import org.bouncycastle.crypto.agreement.X25519Agreement
import org.bouncycastle.crypto.generators.X25519KeyPairGenerator
import org.bouncycastle.crypto.params.X25519KeyGenerationParameters
import org.bouncycastle.crypto.params.X25519PrivateKeyParameters
import org.bouncycastle.crypto.params.X25519PublicKeyParameters
import java.security.SecureRandom

data class X25519PrivateKey(val encoded: ByteArray) {
    val privateKeyParams by lazy { X25519PrivateKeyParameters(encoded, 0) }
    val publicKeyParams: X25519PublicKeyParameters by lazy { privateKeyParams.generatePublicKey() }
    val publicKey: ByteArray by lazy { publicKeyParams.encoded }

    fun performDH(other: X25519PublicKey): ByteArray {
        val agreement = X25519Agreement().apply {
            init(privateKeyParams)
        }
        val sharedSecret = ByteArray(agreement.agreementSize)
        agreement.calculateAgreement(other.publicKeyParams, sharedSecret, 0)
        return sharedSecret
    }

    fun asPublicKey(): X25519PublicKey {
        return X25519PublicKey(publicKey)
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as X25519PrivateKey

        return encoded.contentEquals(other.encoded)
    }

    override fun hashCode(): Int {
        return encoded.contentHashCode()
    }

    companion object {
        fun generate(): X25519PrivateKey {
            with(X25519KeyPairGenerator()) {
                init(X25519KeyGenerationParameters(SecureRandom()))
                return X25519PrivateKey((generateKeyPair().private as X25519PrivateKeyParameters).encoded)
            }
        }
    }
}
