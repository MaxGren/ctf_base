package zen.messenger.data.db.driver

import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.driver.android.AndroidSqliteDriver
import org.koin.dsl.module
import zen.messenger.data.db.schema.Database

fun dbDriverModule() = module {
    single {
        AndroidSqliteDriver(Database.Schema, get(), "zen.db") as SqlDriver
    }
}