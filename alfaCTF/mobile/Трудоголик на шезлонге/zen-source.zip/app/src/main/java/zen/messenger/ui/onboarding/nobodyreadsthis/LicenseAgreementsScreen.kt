package zen.messenger.ui.onboarding.nobodyreadsthis

import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import org.koin.compose.viewmodel.koinViewModel
import zen.messenger.domain.model.LicenseAgreement
import kotlin.math.pow

@Composable
fun LicenseAgreementsScreen(
    innerPadding: PaddingValues = PaddingValues(),
    viewModel: LicenseAgreementsViewModel = koinViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    var localCheckedAgreements by remember { mutableStateOf(setOf<String>()) }

    val colorTransitionSharpness = 4.0f

    val progress = if (uiState.agreements.isNotEmpty()) {
        localCheckedAgreements.size.toFloat() / uiState.agreements.size.toFloat()
    } else 0f

    val easedProgress = run {
        val x = progress.coerceIn(0f, 1f)

        if (x < 0.3f || x > 0.7f) {
            x
        } else {
            val mid = (x - 0.3f) / 0.4f
            val curved =
                mid.pow(colorTransitionSharpness) / (mid.pow(colorTransitionSharpness) + (1f - mid).pow(
                    colorTransitionSharpness
                ))
            0.3f + (curved * 0.4f)
        }
    }

    val backgroundColor by animateColorAsState(
        targetValue = lerp(Color.Black, Color.White, easedProgress),
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "backgroundColor"
    )

    val textColor by animateColorAsState(
        targetValue = if (progress >= 0.5f) Color.Black else Color.White,
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "textColor"
    )

    val buttonOpacity by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(
            durationMillis = 300,
            easing = FastOutSlowInEasing
        ),
        label = "buttonOpacity"
    )

    val contentOpacity by animateFloatAsState(
        targetValue = if (uiState.agreements.isNotEmpty()) 1f else 0f,
        animationSpec = tween(
            durationMillis = 400,
            easing = FastOutSlowInEasing
        ),
        label = "contentOpacity"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .padding(innerPadding)
            .imePadding()
    ) {
        LazyColumn(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .alpha(contentOpacity),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            item {
                Text(
                    text = "— мирское.",
                    fontStyle = FontStyle.Italic,
                    fontSize = 30.sp,
                    lineHeight = 36.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    color = textColor,
                    modifier = Modifier.padding(vertical = 24.dp)
                )
            }

            items(uiState.agreements) { agreement ->
                LicenseAgreementItem(
                    agreement = agreement,
                    isChecked = localCheckedAgreements.contains(agreement.name),
                    textColor = textColor,
                    onCheckedChange = { isChecked ->
                        localCheckedAgreements = if (isChecked) {
                            localCheckedAgreements + agreement.name
                        } else {
                            localCheckedAgreements - agreement.name
                        }
                    },
                    onLinkClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, agreement.link.toUri())
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Log.e(
                                "LicenseAgreementsScreen",
                                "Cannot open link: ${agreement.link}",
                                e
                            )
                            Toast.makeText(
                                context,
                                "${agreement.name.lowercase()} не открывается",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                )
            }
        }

        Button(
            onClick = { viewModel.accept() },
            enabled = localCheckedAgreements.size == uiState.agreements.size,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .size(56.dp)
                .alpha(buttonOpacity * contentOpacity),
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                disabledContainerColor = ButtonDefaults.buttonColors().containerColor
            ),
            contentPadding = PaddingValues(0.dp)
        ) {}
    }
}

@Composable
private fun LicenseAgreementItem(
    agreement: LicenseAgreement,
    isChecked: Boolean,
    textColor: Color,
    onCheckedChange: (Boolean) -> Unit,
    onLinkClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(
                checkedColor = textColor,
                uncheckedColor = textColor,
                checkmarkColor = Color.Transparent
            ),
            modifier = Modifier.padding(end = 16.dp)
        )

        Text(
            text = agreement.name,
            fontSize = 16.sp,
            lineHeight = 20.sp,
            color = textColor,
            textDecoration = TextDecoration.Underline,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) { onLinkClick() }
                .weight(1f)
        )
    }
}