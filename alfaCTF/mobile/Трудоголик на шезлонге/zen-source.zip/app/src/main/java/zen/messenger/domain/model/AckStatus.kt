package zen.messenger.domain.model

enum class AckStatus {
    NOT_SET,
    OUT_PENDING,
    OUT_SENT,
    OUT_ACKED,
    OUT_SERVER_REJECTED,
    OUT_CLIENT_REJECTED,
    OUT_SEND_FAILED,
    IN_PENDING,
    IN_REJECTED,
    IN_ACKED,
}