package zen.messenger.client.crypto

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import zen.messenger.util.ByteArraySerializer

@Serializable
data class EncryptedData(
    @Serializable(with = ByteArraySerializer::class)
    val ciphertext: ByteArray,
    @Serializable(with = ByteArraySerializer::class)
    val nonce: ByteArray
) {
    fun decrypt(key: SessionKey): ByteArray {
        return key.decrypt(ciphertext, nonce)!!
    }

    fun toJson(): String {
        return Json.encodeToString(this)
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as EncryptedData

        if (!ciphertext.contentEquals(other.ciphertext)) return false
        if (!nonce.contentEquals(other.nonce)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = ciphertext.contentHashCode()
        result = 31 * result + nonce.contentHashCode()
        return result
    }

}