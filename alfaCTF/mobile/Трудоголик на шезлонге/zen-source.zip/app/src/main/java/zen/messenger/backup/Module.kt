package zen.messenger.backup

import org.koin.dsl.module
import zen.messenger.backup.keysprovider.KeysProviderClient
import java.io.File

fun backupModule(backupRoot: File) = module {
    single { KeysProviderClient(get(), get()) }
    single(createdAtStart = true) {
        BackupManager(
            get(),
            get(),
            get(),
            get(),
            get(),
            get(),
            File(backupRoot, "backups").absolutePath,
        )
    }
}