package zen.messenger.domain.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import zen.messenger.backup.model.BackupProvider
import zen.messenger.util.InstantSerializer
import java.time.Instant

sealed interface Message {
    val contactID: String
    val timestampUTC: Instant
    val ackStatus: AckStatus
    val serverID: String?
    val internalID: Long?

    fun updateInternalID(newInternalID: Long): Message
}

data class Ack(
    private val meta: MessageMeta
) : Message by meta

@Serializable
data class MessageMeta(
    override val contactID: String,
    @Serializable(InstantSerializer::class)
    override val timestampUTC: Instant,
    override val ackStatus: AckStatus = AckStatus.NOT_SET,
    override val serverID: String? = null,
    override val internalID: Long? = null,
) : Message {
    override fun updateInternalID(newInternalID: Long): Message {
        error("Do not use MessageBase's updateInternalID")
    }
}

data class TextMessage(
    private val meta: MessageMeta,
    val toMe: Boolean,
    val text: String,
) : Message by meta {
    override fun updateInternalID(newInternalID: Long): Message {
        return copy(meta = meta.copy(internalID = newInternalID))
    }
}

@Serializable
data class LicenseAgreement(val name: String, val link: String)

@Serializable
sealed interface ServiceMessageContent {
    @Serializable
    @SerialName("licenseAgreements")
    data class LicenseAgreements(val agreements: List<LicenseAgreement>) : ServiceMessageContent

    @Serializable
    @SerialName("regionBackupProviders")
    data class RegionBackupProviders(val keyEndpoint: String, val providers: List<BackupProvider>) :
        ServiceMessageContent

    fun toServiceMessage(base: MessageMeta): ServiceMessage {
        return ServiceMessage(base, this)
    }
}

data class ServiceMessage(
    val meta: MessageMeta,
    val content: ServiceMessageContent
) : Message by meta {
    override fun updateInternalID(newInternalID: Long): Message {
        return copy(meta = meta.copy(internalID = newInternalID))
    }
}
