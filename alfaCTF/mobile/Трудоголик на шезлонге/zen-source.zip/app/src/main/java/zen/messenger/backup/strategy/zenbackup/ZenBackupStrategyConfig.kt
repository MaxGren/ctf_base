package zen.messenger.backup.strategy.zenbackup

import kotlinx.serialization.Serializable

@Serializable
data class ZenBackupStrategyConfig(val baseUrl: String)
