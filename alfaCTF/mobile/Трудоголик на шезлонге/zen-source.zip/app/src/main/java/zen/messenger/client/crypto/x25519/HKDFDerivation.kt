package zen.messenger.client.crypto.x25519

import org.bouncycastle.crypto.digests.SHA256Digest
import org.bouncycastle.crypto.generators.HKDFBytesGenerator
import org.bouncycastle.crypto.params.HKDFParameters
import zen.messenger.client.crypto.SessionKey


object HKDFDerivation {
    val SESSION_KEY_DERIVATION_INFO = "zen-messenger-session-key".toByteArray()
    val BACKUP_USER_ID_DERIVATION_INFO = "zen-messenger-backup-user-id".toByteArray()

    fun deriveKey(source: ByteArray, info: ByteArray): ByteArray {
        val hkdf = HKDFBytesGenerator(SHA256Digest())
        val salt: ByteArray? = "zens4lt".toByteArray()
        hkdf.init(HKDFParameters(source, salt, info))
        val derived = ByteArray(32)
        hkdf.generateBytes(derived, 0, derived.size)
        return derived
    }

    fun deriveSessionKey(sharedSecret: ByteArray, info: ByteArray): SessionKey {
        return SessionKey(deriveKey(sharedSecret, info))
    }
}