package zen.messenger.data.db.datasource

import app.cash.sqldelight.coroutines.asFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import zen.messenger.data.db.schema.Database
import zen.messenger.data.db.schema.EncryptionKey

class LocalEncryptionKeys(val db: Database) {
    fun get(id: String): EncryptionKey? =
        db.encryptionKeyQueries.get(id).executeAsOneOrNull()?.let {
            EncryptionKey(it.id, it.private_key, it.public_key)
        }

    fun flow(id: String): Flow<EncryptionKey?> =
        db.encryptionKeyQueries.get(id).asFlow().map { it ->
            it.executeAsOneOrNull()?.let {
                EncryptionKey(it.id, it.private_key, it.public_key)
            }
        }


    fun add(
        id: String,
        privateKey: ByteArray,
        publicKey: ByteArray?,
    ): Boolean = db.encryptionKeyQueries.add(id, publicKey, privateKey).value > 0L

    fun delete(id: String): Long = db.encryptionKeyQueries.delete(id).value
}