package zen.messenger.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import zen.messenger.R

@OptIn(ExperimentalTextApi::class)
val libreFranklin = FontFamily(
    Font(
        R.font.librefranklin_variable,
        weight = FontWeight.Thin,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.Thin.weight),
        )
    ),
    Font(
        R.font.librefranklin_variable,
        weight = FontWeight.ExtraLight,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.ExtraLight.weight),
        )
    ),
    Font(
        R.font.librefranklin_variable,
        weight = FontWeight.Light,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.Light.weight),
        )
    ),
    Font(
        R.font.librefranklin_variable,
        weight = FontWeight.Normal,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.Normal.weight),
        )
    ),
    Font(
        R.font.librefranklin_variable,
        weight = FontWeight.Medium,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.Medium.weight),
        )
    ),
    Font(
        R.font.librefranklin_variable,
        weight = FontWeight.SemiBold,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.SemiBold.weight),
        )
    ),
    Font(
        R.font.librefranklin_variable,
        weight = FontWeight.Bold,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.Bold.weight),
        )
    ),
    Font(
        R.font.librefranklin_variable,
        weight = FontWeight.ExtraBold,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.ExtraBold.weight),
        )
    ),
    Font(
        R.font.librefranklin_variable,
        weight = FontWeight.Black,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.Black.weight),
        )
    ),
    Font(
        R.font.librefranklin_italic_variable,
        weight = FontWeight.Thin,
        style = FontStyle.Italic,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.Thin.weight),
        )
    ),
    Font(
        R.font.librefranklin_italic_variable,
        weight = FontWeight.ExtraLight,
        style = FontStyle.Italic,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.ExtraLight.weight),
        )
    ),
    Font(
        R.font.librefranklin_italic_variable,
        weight = FontWeight.Light,
        style = FontStyle.Italic,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.Light.weight),
        )
    ),
    Font(
        R.font.librefranklin_italic_variable,
        weight = FontWeight.Normal,
        style = FontStyle.Italic,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.Normal.weight),
        )
    ),
    Font(
        R.font.librefranklin_italic_variable,
        weight = FontWeight.Medium,
        style = FontStyle.Italic,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.Medium.weight),
        )
    ),
    Font(
        R.font.librefranklin_italic_variable,
        weight = FontWeight.SemiBold,
        style = FontStyle.Italic,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.SemiBold.weight),
        )
    ),
    Font(
        R.font.librefranklin_italic_variable,
        weight = FontWeight.Bold,
        style = FontStyle.Italic,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.Bold.weight),
        )
    ),
    Font(
        R.font.librefranklin_italic_variable,
        weight = FontWeight.ExtraBold,
        style = FontStyle.Italic,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.ExtraBold.weight),
        )
    ),
    Font(
        R.font.librefranklin_italic_variable,
        weight = FontWeight.Black,
        style = FontStyle.Italic,
        variationSettings = FontVariation.Settings(
            FontVariation.weight(FontWeight.Black.weight),
        )
    ),
)

val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = libreFranklin,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.75.sp
    )
)