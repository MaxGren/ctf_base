package zen.messenger.client

import io.grpc.Channel
import kotlinx.coroutines.flow.Flow
import zen.messenger.client.auth.AuthInterceptor
import zen.messenger.client.auth.PubkeyServiceClient
import zen.messenger.client.discovery.DiscoveryClient
import zen.messenger.client.messaging.MessagingClient
import zen.messenger.client.repository.KeysRepository
import zen.messenger.client.repository.TokensRepository
import zen.messenger.domain.model.AckStatus
import zen.messenger.domain.model.Contact
import zen.messenger.domain.model.Message
import zen.messenger.domain.model.TextMessage

class ZenClient(
    channel: Channel,
    tokensRepository: TokensRepository,
    keysRepository: KeysRepository
) {
    private val pubkeySvcClient = PubkeyServiceClient(channel)
    private val authInterceptor = AuthInterceptor(tokensRepository, keysRepository, pubkeySvcClient)
    private val discoverySvc = DiscoveryClient(channel, authInterceptor)
    private val messagingSvc =
        MessagingClient(channel, authInterceptor, keysRepository, discoverySvc)

    suspend fun sendAck(serverMessageID: String) {
        messagingSvc.ackMessage(serverMessageID, AckStatus.IN_ACKED)
    }

    suspend fun sendMessage(msg: TextMessage): String {
        return messagingSvc.sendMessage(msg)
    }

    suspend fun getMe(): Contact {
        return discoverySvc.getMe()
    }

    suspend fun contactByID(id: String): Contact? {
        return discoverySvc.contactByID(id)?.first
    }

    suspend fun contactsByUsername(username: String): List<Contact> {
        return discoverySvc.contactsByUsername(username)
    }

    suspend fun registerUsername(username: String) {
        discoverySvc.registerUsername(username)
    }

    fun incomingMessagesFlow(): Flow<Message> {
        return messagingSvc.incomingMessagesFlow()
    }
}