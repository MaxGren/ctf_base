package zen.messenger.backup.envelope

import kotlinx.serialization.Serializable

@Serializable
data class BackupData(
    val contacts: List<BackupContact>,
    val messages: List<BackupMessage>,
    val kv: List<BackupKV>
)
