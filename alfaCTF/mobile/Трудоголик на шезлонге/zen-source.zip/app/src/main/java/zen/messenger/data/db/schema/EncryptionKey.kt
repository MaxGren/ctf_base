package zen.messenger.data.db.schema

data class EncryptionKey(val id: String, val privateKey: ByteArray, val publicKey: ByteArray?) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as EncryptionKey

        if (id != other.id) return false
        if (!privateKey.contentEquals(other.privateKey)) return false
        if (!publicKey.contentEquals(other.publicKey)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + privateKey.contentHashCode()
        result = 31 * result + (publicKey?.contentHashCode() ?: 0)
        return result
    }
}
