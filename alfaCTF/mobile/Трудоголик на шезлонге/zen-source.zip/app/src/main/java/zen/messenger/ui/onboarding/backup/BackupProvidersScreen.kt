package zen.messenger.ui.onboarding.backup

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.koin.compose.viewmodel.koinViewModel
import zen.messenger.backup.model.BackupProvider

@Composable
fun BackupProvidersScreen(
    innerPadding: PaddingValues = PaddingValues(),
    viewModel: BackupProvidersViewModel = koinViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()

    var selectedProviderId by remember { mutableStateOf<String?>(null) }
    var showLocalWarning by remember { mutableStateOf(false) }
    var localWarningSkippable by remember { mutableStateOf(false) }

    val isLightMode = selectedProviderId != null && selectedProviderId != "local"

    val backgroundColor by animateColorAsState(
        targetValue = if (isLightMode) Color.White else Color.Black,
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "backgroundColor"
    )

    val textColor by animateColorAsState(
        targetValue = if (isLightMode) Color.Black else Color.White,
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "textColor"
    )

    val buttonOpacity by animateFloatAsState(
        targetValue = if (selectedProviderId != null && !uiState.showBackupList) 1f else 0f,
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "buttonOpacity"
    )

    val contentOpacity by animateFloatAsState(
        targetValue = if (uiState.backupProviders.isNotEmpty()) 1f else 0f,
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "contentOpacity"
    )

    LaunchedEffect(showLocalWarning) {
        if (showLocalWarning) {
            localWarningSkippable = false
            delay(5000)
            localWarningSkippable = true
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .padding(innerPadding)
            .imePadding()
    ) {
        if (!uiState.showBackupList) {
            // Show backup providers selection
            LazyColumn(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(contentOpacity),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                item {
                    Column {
                        Text(
                            text = "— сохраним историю?",
                            fontStyle = FontStyle.Italic,
                            fontSize = 30.sp,
                            lineHeight = 36.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center,
                            color = textColor,
                            modifier = Modifier.padding(top = 24.dp)
                        )

                        Text(
                            text = "без резервных копий история исчезнет.\nданные хорошо зашифрованы.\nнам не прочесть.",
                            fontSize = 12.sp,
                            lineHeight = 14.sp,
                            textAlign = TextAlign.Left,
                            color = textColor,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }
                }

                items(uiState.backupProviders) { provider ->
                    BackupProviderItem(
                        provider = provider,
                        isSelected = selectedProviderId == provider.id,
                        textColor = textColor,
                        onSelectionChanged = { isSelected ->
                            if (isSelected && provider.id == "local") {
                                showLocalWarning = true
                            } else {
                                selectedProviderId = if (isSelected) provider.id else null
                            }
                        }
                    )
                }
            }

            Button(
                onClick = {
                    selectedProviderId?.let { providerId ->
                        viewModel.selectBackupProvider(providerId)
                    }
                },
                enabled = selectedProviderId != null,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .size(56.dp)
                    .alpha(buttonOpacity * contentOpacity),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    disabledContainerColor = ButtonDefaults.buttonColors().containerColor
                ),
                contentPadding = PaddingValues(0.dp)
            ) {}
        } else {
            // Show backup list
            LazyColumn(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(contentOpacity),
                contentPadding = PaddingValues(24.dp)
            ) {
                if (!uiState.isLoadingBackups) {
                    item {
                        Text(
                            text = "— восстановим?",
                            fontStyle = FontStyle.Italic,
                            fontSize = 30.sp,
                            lineHeight = 36.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center,
                            color = textColor,
                            modifier = Modifier.padding(bottom = 24.dp)
                        )
                    }
                }

                if (uiState.isLoadingBackups || uiState.isRestoringBackup) {
                    item {
                        val loadingText = if (uiState.isLoadingBackups) {
                            "ищем..."
                        } else {
                            "восстанавливаем..."
                        }

                        Text(
                            text = loadingText,
                            fontSize = 16.sp,
                            color = textColor,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(24.dp)
                        )
                    }
                } else {
                    items(uiState.backupItems) { backupItem ->
                        BackupListItem(
                            backupItem = backupItem,
                            textColor = textColor,
                            onClick = { viewModel.selectBackup(backupItem) }
                        )
                    }
                }
            }
        }
    }

    if (showLocalWarning) {
        AlertDialog(
            onDismissRequest = { showLocalWarning = false },
            text = {
                Text(
                    text = "потеряешь телефон — историю не вернуть. точно хочешь этого?",
                    color = Color.Black
                )
            },
            confirmButton = {
                Button(
                    onClick = { showLocalWarning = false },
                ) {
                    Text(text = "не хочу...", color = Color.Black)
                }
            },
            dismissButton = {
                if (localWarningSkippable) {
                    TextButton(
                        onClick = {
                            selectedProviderId = "local"
                            showLocalWarning = false
                        },
                        modifier = Modifier
                    ) {
                        Text(text = "рискнём", color = Color.Gray)
                    }
                }
            },
        )
    }
}

@Composable
private fun BackupProviderItem(
    provider: BackupProvider,
    isSelected: Boolean,
    textColor: Color,
    onSelectionChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 12.dp)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { onSelectionChanged(!isSelected) }
            .alpha(if (provider.id == "local") 0.5f else 1f),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = isSelected,
            onClick = { onSelectionChanged(!isSelected) },
            colors = RadioButtonDefaults.colors(
                selectedColor = textColor,
                unselectedColor = textColor
            ),
            modifier = Modifier.padding(end = 16.dp)
        )

        Text(
            text = provider.name,
            fontSize = 16.sp,
            lineHeight = 20.sp,
            color = textColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun BackupListItem(
    backupItem: BackupItem,
    textColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 12.dp)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { onClick() }
    ) {
        Text(
            text = backupItem.title,
            fontSize = 16.sp,
            lineHeight = 20.sp,
            color = textColor,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Text(
            text = backupItem.subtitle,
            fontSize = 14.sp,
            lineHeight = 18.sp,
            color = textColor.copy(alpha = 0.7f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}