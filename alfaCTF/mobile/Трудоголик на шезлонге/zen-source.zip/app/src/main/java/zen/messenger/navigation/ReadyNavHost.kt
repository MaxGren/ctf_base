package zen.messenger.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import zen.messenger.ui.contacts.ContactsScreen
import zen.messenger.ui.dialogue.DialogueScreen


@Composable
fun ReadyNavHost(modifier: Modifier = Modifier) {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = Screen.Contacts.path,
        modifier = modifier
    ) {
        composable(Screen.Contacts.path) {
            ContactsScreen(onContactClick = { id ->
                navController.navigate(Screen.Dialogue.createRoute(id))
            })
        }

        composable(
            Screen.Dialogue.path,
            arguments = listOf(navArgument("id") { type = NavType.StringType })
        ) {
            val contactID = it.arguments?.getString("id") ?: ""
            DialogueScreen(contactID)
        }
    }
}