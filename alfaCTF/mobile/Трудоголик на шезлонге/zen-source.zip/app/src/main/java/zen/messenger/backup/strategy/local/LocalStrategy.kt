package zen.messenger.backup.strategy.local

import zen.messenger.backup.model.BackupMeta
import zen.messenger.backup.model.CloudBackup
import zen.messenger.backup.strategy.Strategy

class LocalStrategy() : Strategy {
    override suspend fun latestUploadedBackup(userID: String): CloudBackup? {
        return null
    }

    override suspend fun fetch(userID: String, id: String): ByteArray {
        return byteArrayOf()
    }

    override suspend fun upload(
        userID: String,
        backup: ByteArray,
        metadata: BackupMeta
    ): String {
        return userID
    }
}