package zen.messenger.ui.onboarding.keygen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import zen.messenger.client.crypto.ZenKeypair
import zen.messenger.client.crypto.mnemonic.MnemonicKeygen
import zen.messenger.client.crypto.x25519.X25519PrivateKey
import zen.messenger.client.repository.KeysRepository

enum class KeyGenerationScreenState {
    Initial,
    GeneratingNew,
    InputExisting
}

class KeyGenerationViewModel(
    private val keysRepository: KeysRepository
) : ViewModel() {

    private val _screenState = MutableStateFlow(KeyGenerationScreenState.Initial)
    val screenState: StateFlow<KeyGenerationScreenState> = _screenState.asStateFlow()

    private val _generatedSeedPhrase = MutableStateFlow<List<CharArray>>(emptyList())
    val generatedSeedPhrase: StateFlow<List<CharArray>> = _generatedSeedPhrase.asStateFlow()

    private val _inputFields = MutableStateFlow(List(12) { "" })
    val inputFields: StateFlow<List<String>> = _inputFields.asStateFlow()

    private val _errorState = MutableStateFlow<String?>(null)
    val errorState: StateFlow<String?> = _errorState.asStateFlow()

    private val _saving = MutableStateFlow(false)

    fun provideSeedPhrase() {
        _screenState.value = KeyGenerationScreenState.GeneratingNew
        if (_generatedSeedPhrase.value.isEmpty()) {
            viewModelScope.launch {
                _generatedSeedPhrase.value = MnemonicKeygen.generateMnemonic()
            }
        }
    }

    fun proceedWithSeedPhrase(seedPhrase: List<String>) {
        viewModelScope.launch {
            val phrase = seedPhrase.map { it.toCharArray() }
            if (seedPhrase.any { it.isBlank() }) {
                _errorState.value = "мало слов"
                return@launch
            }

            _errorState.value = null

            if (!MnemonicKeygen.validateMnemonic(phrase)) {
                _errorState.value = "что-то не так"
                return@launch
            }

            saveKey(phrase)
        }
    }

    fun proceedWithGenerated() {
        val phrase = _generatedSeedPhrase.value
        if (phrase.isEmpty()) {
            _errorState.value = "фразы нет"
            return
        }
        saveKey(phrase)
    }

    private fun saveKey(mnemonic: List<CharArray>) {
        if (_saving.value) return
        _saving.value = true
        viewModelScope.launch {
            try {
                keysRepository.saveIdentity(
                    ZenKeypair.generateFromMnemonic(mnemonic)
                )
                keysRepository.savePrekey(X25519PrivateKey.generate())
            } finally {
                _saving.value = false
            }
        }
    }

    fun setScreenState(state: KeyGenerationScreenState) {
        _screenState.value = state
    }

    fun updateInputField(index: Int, value: String) {
        val currentFields = _inputFields.value.toMutableList()
        currentFields[index] = value
        _inputFields.value = currentFields
        clearError()
    }

    fun clearError() {
        _errorState.value = null
    }

    override fun onCleared() {
        super.onCleared()
        _generatedSeedPhrase.value = emptyList()
    }
}