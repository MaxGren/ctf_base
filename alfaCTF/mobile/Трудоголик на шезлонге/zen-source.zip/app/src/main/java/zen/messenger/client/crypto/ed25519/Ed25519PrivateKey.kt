package zen.messenger.client.crypto.ed25519

import org.bouncycastle.crypto.params.Ed25519PrivateKeyParameters
import org.bouncycastle.crypto.signers.Ed25519Signer

data class Ed25519PrivateKey(val encoded: ByteArray) {
    val privateKeyParams by lazy { Ed25519PrivateKeyParameters(encoded, 0) }
    val publicKey: Ed25519PublicKey by lazy { Ed25519PublicKey(privateKeyParams.generatePublicKey().encoded) }

    fun sign(bytes: ByteArray): ByteArray {
        with(Ed25519Signer()) {
            init(true, privateKeyParams)
            update(bytes, 0, bytes.size)
            return generateSignature()
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Ed25519PrivateKey

        if (!encoded.contentEquals(other.encoded)) return false
        if (privateKeyParams != other.privateKeyParams) return false

        return true
    }

    override fun hashCode(): Int {
        var result = encoded.contentHashCode()
        result = 31 * result + privateKeyParams.hashCode()
        return result
    }

}