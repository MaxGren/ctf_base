package zen.messenger.backup.model

import kotlinx.serialization.Serializable

@Serializable
data class BackupProvider(
    val id: String,
    val name: String,
    val strategy: String,
    val jsonParams: String
)