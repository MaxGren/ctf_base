package zen.messenger.backup.strategy

import okhttp3.OkHttpClient
import zen.messenger.backup.model.BackupProvider
import zen.messenger.backup.strategy.local.LocalStrategy
import zen.messenger.backup.strategy.zenbackup.ZenBackupStrategy

object StrategyRegistry {
    fun newStrategy(provider: BackupProvider, client: OkHttpClient): Strategy {
        return when (provider.strategy) {
            "zenbackup" -> ZenBackupStrategy(
                client,
                provider.jsonParams
            )

            "local" -> LocalStrategy()
            else -> {
                throw Exception("Cannot create strategy for ${provider.strategy}")
            }
        }
    }
}