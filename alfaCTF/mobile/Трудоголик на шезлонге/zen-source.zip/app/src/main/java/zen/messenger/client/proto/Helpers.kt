package zen.messenger.client.proto

import zen.messenger.domain.model.Contact

fun zen.messenger.client.proto.Contact.toDomainContact(): Contact {
    return Contact(
        this.id,
        this.username,
        null,
        this.signingKey.toByteArray(),
        this.identityKey.toByteArray()
    )
}