package zen.messenger.navigation

sealed class Screen(
    val path: String,
) {
    object Contacts : Screen("contacts")
    object Dialogue : Screen("dialogue/{id}") {
        fun createRoute(id: String): String = "dialogue/$id"
    }
}