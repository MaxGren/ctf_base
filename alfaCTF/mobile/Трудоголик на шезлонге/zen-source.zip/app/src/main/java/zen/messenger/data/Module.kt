package zen.messenger.data

import org.koin.dsl.module
import zen.messenger.backup.repository.BackupRepository
import zen.messenger.client.repository.KeysRepository
import zen.messenger.client.repository.TokensRepository
import zen.messenger.data.repository.BackupRepositoryImpl
import zen.messenger.data.repository.ContactsRepositoryImpl
import zen.messenger.data.repository.KeysRepositoryImpl
import zen.messenger.data.repository.MessagesRepositoryImpl
import zen.messenger.data.repository.TokensRepositoryImpl
import zen.messenger.domain.repository.ContactsRepository
import zen.messenger.domain.repository.MessagesRepository

fun dataModule() = module {
    single { ContactsRepositoryImpl(get(), get()) as ContactsRepository }
    single { MessagesRepositoryImpl(get(), get(), get()) as MessagesRepository }
    single { KeysRepositoryImpl(get()) as KeysRepository }
    single { TokensRepositoryImpl(get()) as TokensRepository }
    single { BackupRepositoryImpl(get(), get()) as BackupRepository }
}