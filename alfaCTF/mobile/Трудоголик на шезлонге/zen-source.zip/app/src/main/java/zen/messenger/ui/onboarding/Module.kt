package zen.messenger.ui.onboarding

import org.koin.core.module.dsl.viewModel
import org.koin.dsl.module
import zen.messenger.ui.onboarding.backup.BackupProvidersViewModel
import zen.messenger.ui.onboarding.keygen.KeyGenerationViewModel
import zen.messenger.ui.onboarding.nobodyreadsthis.LicenseAgreementsViewModel
import zen.messenger.ui.onboarding.username.UsernameRegistrationViewModel

fun onboardingModule() = module {
    viewModel { KeyGenerationViewModel(get()) }
    viewModel { UsernameRegistrationViewModel(get()) }
    viewModel { LicenseAgreementsViewModel(get()) }
    viewModel { BackupProvidersViewModel(get(), get()) }
}