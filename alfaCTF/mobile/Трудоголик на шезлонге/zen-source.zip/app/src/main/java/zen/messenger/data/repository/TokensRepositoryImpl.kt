package zen.messenger.data.repository

import zen.messenger.client.repository.TokensRepository
import zen.messenger.data.db.datasource.LocalStringKV

class TokensRepositoryImpl(val stringKV: LocalStringKV) : TokensRepository {
    override fun get(): String? {
        return stringKV.get(TOKEN_KV_KEY)
    }

    override fun set(token: String) {
        stringKV.set(TOKEN_KV_KEY, token)
    }

    companion object {
        private const val TOKEN_KV_KEY = "token"
    }
}