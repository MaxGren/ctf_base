package zen.messenger.backup

import zen.messenger.backup.model.BackupMeta


interface BackupOperator {
    fun collect(): Pair<BackupMeta, ByteArray>
    fun restore(backup: ByteArray, meta: BackupMeta)
}
