package zen.messenger.client.discovery

import org.bouncycastle.crypto.KeyGenerationParameters
import org.bouncycastle.crypto.generators.X25519KeyPairGenerator
import org.bouncycastle.crypto.params.X25519PrivateKeyParameters
import org.bouncycastle.crypto.params.X25519PublicKeyParameters
import zen.messenger.client.crypto.SessionKey
import zen.messenger.client.crypto.ed25519.Ed25519PublicKey
import zen.messenger.client.crypto.x25519.HKDFDerivation
import zen.messenger.client.crypto.x25519.HKDFDerivation.deriveSessionKey
import zen.messenger.client.crypto.x25519.X25519PrivateKey
import zen.messenger.client.crypto.x25519.X25519PublicKey
import java.security.SecureRandom

data class ContactKeys(
    val signing: Ed25519PublicKey,
    val identity: X25519PublicKey,
    val prekey: X25519PublicKey,
) {
    fun offerSessionKey(myIdentity: X25519PrivateKey): Pair<SessionKey, X25519PublicKey> {
        val dh1 = myIdentity.performDH(prekey)

        val ephemeralPair = with(X25519KeyPairGenerator()) {
            init(KeyGenerationParameters(SecureRandom(), 255))
            generateKeyPair()
        }
        val ephemeralPrivate =
            X25519PrivateKey((ephemeralPair.private as X25519PrivateKeyParameters).encoded)
        val ephemeralPublic =
            X25519PublicKey((ephemeralPair.public as X25519PublicKeyParameters).encoded)

        val dh2 = ephemeralPrivate.performDH(identity)
        val dh3 = ephemeralPrivate.performDH(prekey)

        val key = deriveSessionKey(dh1 + dh2 + dh3, HKDFDerivation.SESSION_KEY_DERIVATION_INFO)
        return (key to ephemeralPublic)
    }

    fun acceptSessionKey(myIdentity: X25519PrivateKey, myPrekey: X25519PrivateKey): SessionKey {
        val dh1 = myPrekey.performDH(identity)
        val dh2 = myIdentity.performDH(prekey)
        val dh3 = myPrekey.performDH(prekey)
        return deriveSessionKey(dh1 + dh2 + dh3, HKDFDerivation.SESSION_KEY_DERIVATION_INFO)
    }
}