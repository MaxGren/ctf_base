package zen.messenger.backup.envelope

import kotlinx.serialization.Serializable
import zen.messenger.data.db.schema.MessageType
import zen.messenger.domain.model.AckStatus

@Serializable
data class BackupMessage(
    val internalID: Long,
    val serverID: String?,
    val contactID: String,
    val type: MessageType,
    val timestampUTC: Long,
    val text: String,
    val ackStatus: AckStatus?,
)