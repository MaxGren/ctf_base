package zen.messenger.client.crypto.ed25519

import zen.messenger.client.crypto.mnemonic.MnemonicKeygen

class Ed25519MnemonicKeygen : MnemonicKeygen<Ed25519PrivateKey>() {
    override fun keyFromBytes(bytes: ByteArray): Ed25519PrivateKey {
        return Ed25519PrivateKey(bytes)
    }
}