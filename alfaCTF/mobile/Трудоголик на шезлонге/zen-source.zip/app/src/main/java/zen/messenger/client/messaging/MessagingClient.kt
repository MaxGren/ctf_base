package zen.messenger.client.messaging

import android.util.Log
import com.google.protobuf.Timestamp
import com.google.protobuf.kotlin.toByteString
import io.grpc.Channel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.asFlow
import kotlinx.coroutines.flow.flatMapConcat
import kotlinx.coroutines.flow.mapNotNull
import zen.messenger.backup.model.BackupProvider
import zen.messenger.client.auth.AuthInterceptor
import zen.messenger.client.crypto.EncryptedData
import zen.messenger.client.crypto.SessionKey
import zen.messenger.client.crypto.ed25519.Ed25519PublicKey
import zen.messenger.client.crypto.x25519.X25519PublicKey
import zen.messenger.client.discovery.ContactKeys
import zen.messenger.client.discovery.DiscoveryClient
import zen.messenger.client.proto.AckFlag
import zen.messenger.client.proto.AckMessageRequest
import zen.messenger.client.proto.IncomingMessage
import zen.messenger.client.proto.IncomingMessagesStreamRequest
import zen.messenger.client.proto.MessageEnvelope
import zen.messenger.client.proto.MessagingServiceGrpcKt
import zen.messenger.client.proto.OutgoingMessage
import zen.messenger.client.proto.OutgoingMessageErrorCode
import zen.messenger.client.proto.OutgoingMessageResponse
import zen.messenger.client.repository.KeysRepository
import zen.messenger.domain.model.Ack
import zen.messenger.domain.model.AckStatus
import zen.messenger.domain.model.LicenseAgreement
import zen.messenger.domain.model.Message
import zen.messenger.domain.model.MessageMeta
import zen.messenger.domain.model.ServiceMessage
import zen.messenger.domain.model.ServiceMessageContent
import zen.messenger.domain.model.TextMessage
import java.time.Instant

internal class MessagingClient(
    channel: Channel,
    interceptor: AuthInterceptor,
    private val keysRepository: KeysRepository,
    private val discoveryClient: DiscoveryClient
) {
    private val stub = MessagingServiceGrpcKt.MessagingServiceCoroutineStub(channel)
        .withInterceptors(interceptor)

    private suspend fun ensureSessionKeyPair(contactID: String): Pair<X25519PublicKey?, SessionKey> {
        val existingSessionKey = keysRepository.getSessionKey(contactID)
        var generatedEphemeral: X25519PublicKey? = null
        val sessionKey: SessionKey
        if (existingSessionKey == null) {
            val contactPair =
                requireNotNull(discoveryClient.contactByID(contactID)) { "Backend returned null contact for an ID" }
            val identity =
                requireNotNull(keysRepository.getIdentity()) { "Identity key should not be null" }
            val generatedOffer =
                contactPair.second.offerSessionKey(identity.identity)
            sessionKey = generatedOffer.first
            generatedEphemeral = generatedOffer.second
        } else {
            sessionKey = existingSessionKey
        }
        keysRepository.saveSessionKey(contactID, sessionKey)
        return Pair(generatedEphemeral, sessionKey)
    }

    fun encryptMessage(message: Message, sessionKey: SessionKey): EncryptedData {
        val wrapped = MessageEnvelope.newBuilder().let { envBuilder ->
            when (message) {
                is TextMessage -> {
                    envBuilder.setText(
                        zen.messenger.client.proto.TextMessage.newBuilder()
                            .setMessage(message.text)
                            .setTimestampUtc(
                                Timestamp.newBuilder().setSeconds(message.timestampUTC.epochSecond)
                            )
                            .build()
                    )
                }

                else -> throw Exception("такое не шифруется")
            }
            envBuilder.build()
        }
        return sessionKey.encrypt(wrapped.toByteArray())
    }

    suspend fun sendMessage(message: TextMessage): String {
        val pair = ensureSessionKeyPair(message.contactID)
        val generatedEphemeral: X25519PublicKey? = pair.first
        val sessionKey: SessionKey = pair.second

        val encrypted = encryptMessage(message, sessionKey)

        val request = OutgoingMessage.newBuilder()
            .setToId(message.contactID)
            .setCiphertext(encrypted.ciphertext.toByteString())
            .setNonce(encrypted.nonce.toByteString())
        if (generatedEphemeral != null) {
            request.setEphemeralKey(generatedEphemeral.publicKey.toByteString())
        }

        val response = stub.sendMessage(request.build())
        return when (response.resultCase) {
            OutgoingMessageResponse.ResultCase.ERROR -> {
                throw when (response.error.code) {
                    OutgoingMessageErrorCode.UNRECOGNIZED -> Exception("хаос возобладал")
                    else -> Exception(response.error.message)
                }
            }

            OutgoingMessageResponse.ResultCase.RESULT_NOT_SET -> throw Exception("никаких результатов")
            OutgoingMessageResponse.ResultCase.SUCCESS -> response.success.msgid
        }
    }

    suspend fun ackMessage(messageID: String, status: AckStatus) {
        val request = AckMessageRequest.newBuilder()
            .setId(messageID)
            .setCode(
                when (status) {
                    AckStatus.IN_REJECTED -> AckFlag.ACK_CLIENT_REJECTED
                    AckStatus.IN_ACKED -> AckFlag.ACK_OK
                    else -> throw Exception("не знаю, что такое $status")
                }
            )
            .build()

        stub.ackMessage(request)
    }

    fun unwrapMessage(msg: IncomingMessage): Message {
        val sessionKey = if (!msg.ephemeralKey.isEmpty) {
            val ephemeralOffer = ContactKeys(
                signing = Ed25519PublicKey(msg.from.signingKey.toByteArray()),
                identity = X25519PublicKey(msg.from.identityKey.toByteArray()),
                prekey = X25519PublicKey(msg.ephemeralKey.toByteArray())
            )
            val myIdentity = keysRepository.getIdentity()!!
            val myPrekey = keysRepository.getPrekey()!!
            val key = ephemeralOffer.acceptSessionKey(
                myIdentity = myIdentity.identity,
                myPrekey = myPrekey
            )
            keysRepository.saveSessionKey(msg.from.id, key)
            key
        } else {
            keysRepository.getSessionKey(msg.from.id)
        }
        if (sessionKey == null) {
            throw Exception("нет сессионного ключа")
        }

        val data = EncryptedData(
            ciphertext = msg.ciphertext.toByteArray(),
            nonce = msg.nonce.toByteArray()
        ).decrypt(sessionKey)

        val envelope = MessageEnvelope.parseFrom(data)
        return when (envelope.msgCase) {
            MessageEnvelope.MsgCase.ACK -> Ack(
                meta = MessageMeta(
                    contactID = msg.from.id,
                    timestampUTC = Instant.now(),
                    ackStatus = when (envelope.ack.ack) {
                        AckFlag.ACK_OK -> AckStatus.OUT_ACKED
                        AckFlag.ACK_SERVER_REJECTED -> AckStatus.OUT_SERVER_REJECTED
                        AckFlag.ACK_CLIENT_REJECTED -> AckStatus.OUT_CLIENT_REJECTED
                        AckFlag.UNRECOGNIZED -> AckStatus.OUT_SERVER_REJECTED
                    },
                    serverID = envelope.ack.msgid
                )
            )

            MessageEnvelope.MsgCase.SERVICE -> unwrapServiceMessage(msg, envelope)
            MessageEnvelope.MsgCase.TEXT -> TextMessage(
                meta = MessageMeta(
                    contactID = msg.from.id,
                    timestampUTC = Instant.now(),
                    ackStatus = AckStatus.IN_PENDING,
                    serverID = msg.id,
                    internalID = null,
                ),
                text = envelope.text.message,
                toMe = true
            )

            MessageEnvelope.MsgCase.MSG_NOT_SET -> throw Exception("сервер пьян")
        }
    }

    fun unwrapServiceMessage(msg: IncomingMessage, envelope: MessageEnvelope): ServiceMessage {
        return ServiceMessage(
            meta = MessageMeta(
                contactID = msg.from.id,
                timestampUTC = Instant.now(),
                ackStatus = AckStatus.IN_PENDING,
                serverID = msg.id,
                internalID = null,
            ),
            content = when (envelope.service.msgCase) {
                zen.messenger.client.proto.ServiceMessage.MsgCase.AGREEMENT_UPDATES -> ServiceMessageContent.LicenseAgreements(
                    agreements = envelope.service.agreementUpdates.agreementsList.map {
                        LicenseAgreement(it.name, it.link)
                    }
                )

                zen.messenger.client.proto.ServiceMessage.MsgCase.REGION_BACKUP_PROVIDERS -> ServiceMessageContent.RegionBackupProviders(
                    keyEndpoint = envelope.service.regionBackupProviders.keyEndpoint,
                    providers = envelope.service.regionBackupProviders.providersList.map {
                        BackupProvider(
                            it.id, it.name, strategy = it.strategy, jsonParams = it.jsonParams,
                        )
                    }
                )

                zen.messenger.client.proto.ServiceMessage.MsgCase.MSG_NOT_SET -> throw Exception("сообщение потерялось")
            }
        )
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    fun incomingMessagesFlow(): Flow<Message> {
        return stub.incomingMessagesStream(IncomingMessagesStreamRequest.newBuilder().build())
            .flatMapConcat { batch ->
                batch.messagesList.asFlow().mapNotNull { msg ->
                    try {
                        unwrapMessage(msg)
                    } catch (e: Exception) {
                        Log.e("MessagingClient", "Cannot unwrap message", e)
                        ackMessage(msg.id, AckStatus.IN_REJECTED)
                        null
                    }
                }
            }
    }
}