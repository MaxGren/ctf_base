package zen.messenger.data.repository

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import zen.messenger.client.crypto.SessionKey
import zen.messenger.client.crypto.ZenKeypair
import zen.messenger.client.crypto.ed25519.Ed25519PrivateKey
import zen.messenger.client.crypto.x25519.X25519PrivateKey
import zen.messenger.client.repository.KeysRepository
import zen.messenger.data.db.datasource.LocalEncryptionKeys

val mnemonicSeparator = charArrayOf(' ')

class KeysRepositoryImpl(
    private val local: LocalEncryptionKeys
) : KeysRepository {
    override fun getIdentity(): ZenKeypair? {
        val signingRaw = local.get(SIGNING_KEY_ID) ?: return null
        val identityRaw = local.get(IDENTITY_KEY_ID) ?: return null
        return ZenKeypair(
            Ed25519PrivateKey(signingRaw.privateKey),
            X25519PrivateKey(identityRaw.privateKey)
        )
    }

    override fun getIdentityFlow(): Flow<ZenKeypair?> {
        return combine(
            local.flow(SIGNING_KEY_ID),
            local.flow(IDENTITY_KEY_ID)
        ) { (signingRaw, identityRaw) ->
            if (signingRaw == null || identityRaw == null) {
                return@combine null
            }
            ZenKeypair(
                Ed25519PrivateKey(signingRaw.privateKey),
                X25519PrivateKey(identityRaw.privateKey)
            )
        }
    }

    override fun saveIdentity(identity: ZenKeypair) {
        local.add(SIGNING_KEY_ID, identity.signing.encoded, null)
        local.add(IDENTITY_KEY_ID, identity.identity.encoded, null)
    }

    override fun getPrekey(): X25519PrivateKey? {
        return local.get(PREKEY_ID)?.let {
            X25519PrivateKey(it.privateKey)
        }
    }

    override fun savePrekey(pair: X25519PrivateKey) {
        local.add(PREKEY_ID, pair.encoded, null)
    }

    fun sessionKeyID(id: String) = SESSION_KEY_ID_PREFIX + id

    override fun getSessionKey(id: String): SessionKey? {
        return local.get(sessionKeyID(id))?.let {
            SessionKey(it.privateKey)
        }
    }

    override fun saveSessionKey(id: String, key: SessionKey) {
        local.add(sessionKeyID(id), key.bytes, null)
    }

    companion object {
        const val SIGNING_KEY_ID = "signing"
        const val IDENTITY_KEY_ID = "identity"
        const val PREKEY_ID = "prekey"
        const val SESSION_KEY_ID_PREFIX = "session-"
    }
}