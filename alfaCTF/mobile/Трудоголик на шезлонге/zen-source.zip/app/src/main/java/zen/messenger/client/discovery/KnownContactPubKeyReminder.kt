package zen.messenger.client.discovery

interface KnownContactPubKeyReminder {
    fun remindKnownContactPubKey(id: String): ByteArray?
}