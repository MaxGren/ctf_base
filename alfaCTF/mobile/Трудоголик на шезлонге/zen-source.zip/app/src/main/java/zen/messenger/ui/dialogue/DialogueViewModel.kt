package zen.messenger.ui.dialogue

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import zen.messenger.domain.model.Contact
import zen.messenger.domain.model.Message
import zen.messenger.domain.repository.ContactsRepository
import zen.messenger.domain.repository.MessagesRepository

sealed class UiState {
    data object Loading : UiState()
    data class Ready(
        val contact: Contact,
        val existingMessages: List<Message>,
        val newMessages: List<Message>,
    ) : UiState()

    data class Error(
        val message: String
    ) : UiState()
}

@OptIn(ExperimentalCoroutinesApi::class)
class DialogueViewModel(
    private val contactsRepository: ContactsRepository,
    private val messagesRepository: MessagesRepository,
    private val id: String,
) : ViewModel() {
    private val _uiState = MutableStateFlow<UiState>(UiState.Loading)
    val uiState = _uiState.asStateFlow()

    private val _isLoadingMessages = MutableStateFlow(false)

    private val _hasMoreMessages = MutableStateFlow(true)
    val hasMoreMessages = _hasMoreMessages.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private var currentOffset = 0L
    private val pageSize = 100L

    init {
        viewModelScope.launch {
            _isLoadingMessages.value = true
            try {
                val contact = contactsRepository.getContact(id)
                if (contact == null) {
                    throw Exception("контакт не установлен")
                }
                val messages = messagesRepository.get(
                    contactID = id,
                    limit = pageSize
                )
                _uiState.emit(
                    UiState.Ready(
                        contact,
                        existingMessages = messages,
                        newMessages = emptyList()
                    )
                )

                viewModelScope.launch {
                    messagesRepository.getNewSince(id, messages.lastOrNull()?.internalID ?: 0)
                        .collect {
                            val currentState = _uiState.value
                            if (currentState is UiState.Ready && !it.isEmpty()) {
                                _uiState.emit(currentState.copy(newMessages = it))
                            }
                        }
                }
            } catch (e: Exception) {
                _uiState.emit(UiState.Error(e.message ?: "неизвестная ошибка"))
            } finally {
                _isLoadingMessages.value = false
            }
        }
    }

    fun olderMessages() {
        if (_isLoadingMessages.value || !_hasMoreMessages.value) return

        viewModelScope.launch {
            _isLoadingMessages.value = true
            try {
                val olderMessages = messagesRepository.get(
                    contactID = id,
                    limit = pageSize,
                    offsetID = currentOffset
                )

                if (olderMessages.isEmpty()) {
                    _hasMoreMessages.value = false
                } else {
                    val currentState = _uiState.value
                    if (currentState is UiState.Ready) {
                        val updatedMessages = olderMessages + currentState.existingMessages
                        _uiState.emit(currentState.copy(existingMessages = updatedMessages))
                    }
                    currentOffset = olderMessages.first().internalID!!
                }
            } catch (e: Exception) {
                _toastMessage.emit(e.message)
            } finally {
                _isLoadingMessages.value = false
            }
        }
    }

    fun sendMessage(text: String) {
        viewModelScope.launch {
            try {
                val currentState = _uiState.value
                if (currentState is UiState.Ready) {
                    contactsRepository.rememberContact(currentState.contact)
                }
                messagesRepository.sendText(
                    text = text.trim(),
                    contactID = id
                )
            } catch (e: Exception) {
            }
        }
    }
}