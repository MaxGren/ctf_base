package zen.messenger.ui.contacts

import org.koin.core.module.dsl.viewModel
import org.koin.dsl.module

fun contactsViewModelModule() =
    module {
        viewModel { ContactsViewModel(get()) }
    }