package zen.messenger.backup.repository

import kotlinx.coroutines.flow.Flow
import zen.messenger.backup.model.BackupProvider

interface BackupRepository {
    fun getKeyEndpoint(): String
    fun setKeyEndpoint(new: String)

    fun providers(): List<BackupProvider>
    fun providersFlow(): Flow<List<BackupProvider>>
    fun updateProviders(new: List<BackupProvider>)
    fun getProviderByID(id: String): BackupProvider?
    fun getCurrentProviderID(): String?
    fun setCurrentProviderID(new: String?)
    fun getCurrentProvider(): BackupProvider?
    fun flowableCurrentProvider(): Flow<BackupProvider?>
}