package zen.messenger.data.db.datasource

import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.decodeFromStream
import zen.messenger.backup.BackupOperator
import zen.messenger.backup.envelope.BackupContact
import zen.messenger.backup.envelope.BackupData
import zen.messenger.backup.envelope.BackupKV
import zen.messenger.backup.envelope.BackupMessage
import zen.messenger.backup.model.BackupMeta
import zen.messenger.data.db.schema.ContactRecord
import zen.messenger.data.db.schema.Database
import zen.messenger.data.db.schema.MessageRecord
import java.time.Instant
import java.util.UUID

class LocalBackupOperator(
    private val localContacts: LocalContacts,
    private val localMessages: LocalMessages,
    private val localStringKV: LocalStringKV,
    private val db: Database
) : BackupOperator {
    override fun collect(): Pair<BackupMeta, ByteArray> {
        val backedUp = db.transactionWithResult {
            val backupContacts = localContacts.allContactRecords().map {
                BackupContact(
                    id = it.id,
                    username = it.username,
                    name = it.name,
                    signingKey = it.signing_key,
                    identityKey = it.identity_key
                )
            }

            val backupMessages = localMessages.allMessageRecords().map {
                BackupMessage(
                    internalID = it.internal_id,
                    serverID = it.server_id,
                    contactID = it.contact_id,
                    type = it.type,
                    timestampUTC = it.timestamp_utc,
                    text = it.text,
                    ackStatus = it.ack_status
                )
            }

            val backupKV = localStringKV.all().filter {
                it.key != "token" && it.key != "key_endpoint"
            }.map {
                BackupKV(key = it.key, value = it.value_)
            }

            BackupData(
                contacts = backupContacts,
                messages = backupMessages,
                kv = backupKV
            )
        }
        val serialized = Json.encodeToString(backedUp).toByteArray()

        return BackupMeta(
            id = UUID.randomUUID().toString(),
            createdAt = Instant.now(),
            contactsCount = backedUp.contacts.size,
            messagesCount = backedUp.messages.size
        ) to serialized
    }

    @OptIn(ExperimentalSerializationApi::class)
    override fun restore(backup: ByteArray, meta: BackupMeta) {
        val deserialized = Json.decodeFromStream<BackupData>(backup.inputStream())
        if (deserialized.contacts.size != meta.contactsCount) {
            throw Exception("Contacts count mismatch")
        }
        if (deserialized.messages.size != meta.messagesCount) {
            throw Exception("Messages count mismatch")
        }

        db.transaction {
            localContacts.restoreContacts(
                deserialized.contacts.map {
                    ContactRecord(
                        id = it.id,
                        username = it.username,
                        name = it.name,
                        signing_key = it.signingKey,
                        identity_key = it.identityKey,
                        known = 1L
                    )
                }
            )

            localMessages.restoreMessages(
                deserialized.messages.map {
                    MessageRecord(
                        internal_id = it.internalID,
                        server_id = it.serverID,
                        contact_id = it.contactID,
                        type = it.type,
                        timestamp_utc = it.timestampUTC,
                        text = it.text,
                        ack_status = it.ackStatus
                    )
                }
            )

            deserialized.kv.forEach { localStringKV.set(it.key, it.value) }
        }
    }
}