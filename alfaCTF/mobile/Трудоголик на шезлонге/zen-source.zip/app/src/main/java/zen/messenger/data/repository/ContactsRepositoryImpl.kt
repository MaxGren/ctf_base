package zen.messenger.data.repository

import kotlinx.coroutines.flow.Flow
import zen.messenger.client.ZenClient
import zen.messenger.client.discovery.KnownContactPubKeyReminder
import zen.messenger.data.db.datasource.LocalContacts
import zen.messenger.domain.model.Contact
import zen.messenger.domain.repository.ContactsRepository

class ContactsRepositoryImpl(val local: LocalContacts, val remote: ZenClient) : ContactsRepository,
    KnownContactPubKeyReminder {

    override fun rememberContact(contact: Contact) = local.rememberContact(contact)

    override suspend fun getContact(id: String): Contact? {
        return local.get(id) ?: remote.contactByID(id)?.also { local.cacheContact(it) }
    }

    override fun knownContactsFlow(): Flow<List<Contact>> = local.listFlow()

    override fun localSearch(
        query: String
    ): List<Contact> = local.search(query)

    override suspend fun remoteSearch(username: String): List<Contact> {
        return remote.contactsByUsername(username).map { contact ->
            local.cacheContact(contact)
            contact
        }
    }

    override suspend fun getMe(force: Boolean): Contact {
        val localMe = local.getMe()
        if (localMe == null || force) {
            val remoteMe = remote.getMe()
            local.setMe(remoteMe.id, remoteMe)
            return remoteMe
        }
        return localMe
    }

    override fun getCachedMeFlowable(): Flow<Contact?> {
        return local.getMeFlow()
    }

    override suspend fun setMyUsername(username: String) {
        remote.registerUsername(username)
        val remoteMe = remote.getMe()
        local.setMe(remoteMe.id, remoteMe)
    }

    override fun remindKnownContactPubKey(id: String): ByteArray? {
        return local.get(id)?.signingKey
    }
}