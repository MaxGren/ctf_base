package zen.messenger.backup.strategy

import zen.messenger.backup.model.BackupMeta
import zen.messenger.backup.model.CloudBackup

interface Strategy {
    suspend fun latestUploadedBackup(userID: String): CloudBackup?
    suspend fun fetch(userID: String, id: String): ByteArray

    suspend fun upload(userID: String, backup: ByteArray, metadata: BackupMeta): String
}