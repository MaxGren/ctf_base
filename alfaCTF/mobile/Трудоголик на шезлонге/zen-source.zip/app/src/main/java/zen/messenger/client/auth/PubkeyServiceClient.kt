package zen.messenger.client.auth

import com.google.protobuf.kotlin.toByteString
import io.grpc.Channel
import zen.messenger.client.crypto.ZenKeypair
import zen.messenger.client.crypto.x25519.X25519PublicKey
import zen.messenger.client.proto.Prekey
import zen.messenger.client.proto.PubkeyOwnershipProofErrorCode
import zen.messenger.client.proto.PubkeyOwnershipProofRequest
import zen.messenger.client.proto.PubkeyOwnershipProofResponse
import zen.messenger.client.proto.PubkeyServiceGrpcKt
import zen.messenger.client.proto.RegisterPubkeyErrorCode
import zen.messenger.client.proto.RegisterPubkeyRequest
import zen.messenger.client.proto.RegisterPubkeyResponse

internal class PubkeyServiceClient(channel: Channel) {
    private val stub = PubkeyServiceGrpcKt.PubkeyServiceCoroutineStub(channel)

    suspend fun registerPubkey(identity: ZenKeypair, prekey: X25519PublicKey): String {
        val response = stub.registerPubkey(
            RegisterPubkeyRequest.newBuilder()
                .setPubkey(identity.signing.publicKey.encoded.toByteString())
                .build()
        )

        when (response.resultCase) {
            RegisterPubkeyResponse.ResultCase.ERROR -> RegisterPubkeyException(
                response.error.code,
                response.error.message
            )

            RegisterPubkeyResponse.ResultCase.RESULT_NOT_SET -> RegisterPubkeyException(
                RegisterPubkeyErrorCode.UNRECOGNIZED, "Empty response provided by server"
            )

            RegisterPubkeyResponse.ResultCase.CHALLENGE -> null
        }?.let {
            throw it
        }

        val signedChallenge = identity.signing.sign(response.challenge.challenge.toByteArray())
        val challengeResponse = stub.provePubkeyOwnership(
            PubkeyOwnershipProofRequest.newBuilder()
                .setChallengeId(response.challenge.challengeId)
                .setProof(signedChallenge.toByteString())
                .setIdentityKey(identity.identity.publicKey.toByteString())
                .setPrekey(
                    Prekey.newBuilder()
                        .setId("default")
                        .setPrekey(prekey.publicKey.toByteString())
                        .setSignature(identity.signing.sign(prekey.publicKey).toByteString())
                )
                .build()
        )

        when (challengeResponse.resultCase) {
            PubkeyOwnershipProofResponse.ResultCase.ERROR -> PubkeyOwnershipProofException(
                challengeResponse.error.code,
                response.error.message
            )

            PubkeyOwnershipProofResponse.ResultCase.RESULT_NOT_SET -> PubkeyOwnershipProofException(
                PubkeyOwnershipProofErrorCode.UNRECOGNIZED, "Empty response provided by server"
            )

            PubkeyOwnershipProofResponse.ResultCase.SUCCESS -> null
        }?.let {
            throw it
        }

        return challengeResponse.success.token
    }
}