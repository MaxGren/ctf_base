import contextlib
import os
import tempfile
import torch
import types

from flask import Flask, request, render_template
from werkzeug.utils import secure_filename

# внимание: вмешательство человека!
torch.serialization.add_safe_globals([(types.ModuleType, 'types.ModuleType')])

app = Flask(__name__)


class ModelFile:
    def __init__(self, orig_file, ctx):
        self.orig_file = orig_file
        self.filename = secure_filename(self.orig_file.filename)
        self.file_obj = ctx.enter_context(open(self.filename, 'w+b'))


@app.route('/', methods=['GET', 'POST'])
def check_files():
    results = []

    if request.method == 'POST':
        with tempfile.TemporaryDirectory() as temp_dir, contextlib.chdir(temp_dir), contextlib.ExitStack() as ctx:
            models = [ModelFile(f, ctx) for f in request.files.getlist('files')]
            for model in models:
                try:
                    model.orig_file.save(model.file_obj)
                    model.file_obj.flush()
                    model.file_obj.seek(0)
                    torch.load(model.file_obj, weights_only=True)
                    results.append((True, model.filename, 'дикий огурец'))
                except Exception as e:
                    results.append((False, model.filename, f'{str(e)}'))

    return render_template('index.html', results=results)
