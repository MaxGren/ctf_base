<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['chunks']) || !is_array($input['chunks']) || empty($input['chunks'])) {
    http_response_code(400);
    echo json_encode(['error' => 'No chunks provided']);
    exit;
}

$chunks = $input['chunks'];

$tempFile = tempnam(sys_get_temp_dir(), 'wrap_');
unlink($tempFile);
$tempDir = $tempFile;

if (!mkdir($tempDir, 0755, true)) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to create temp directory']);
    exit;
}

try {
    $key = random_bytes(256);
    $keyPath = $tempDir . '/key.bin';
    if (file_put_contents($keyPath, $key) === false) {
        throw new Exception('Failed to write key file');
    }

    $encipheredImages = [];
    $base64Images = [];

    foreach ($chunks as $index => $chunk) {
        $imageNumber = $index + 1;
        $imagePath = $tempDir . '/' . $imageNumber . '.png';
        
        $pipeline = sprintf(
            'qrencode -s 50 -o - %s | convert - -resize 1000x1000 -encipher %s %s',
            escapeshellarg($chunk),
            escapeshellarg($keyPath),
            escapeshellarg($imagePath)
        );
        
        exec($pipeline, $output, $return_code);
        
        if ($return_code !== 0 || !file_exists($imagePath)) {
            throw new Exception("Failed to generate enciphered image for chunk $index");
        }
        
        $imageData = file_get_contents($imagePath);
        $base64 = 'data:image/png;base64,' . base64_encode($imageData);
        $base64Images[] = [
            'index' => $index,
            'image' => $base64,
            'text' => $chunk
        ];
        
        $encipheredImages[] = $imagePath;
    }

    // Create ZIP archive
    $zipPath = $tempDir . '/wrapped_tiles.zip';
    $zip = new ZipArchive();
    
    if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
        throw new Exception('Failed to create ZIP archive');
    }
    
    $zip->addFile($keyPath, 'key.bin');
    
    foreach ($encipheredImages as $index => $imagePath) {
        $imageNumber = $index + 1;
        $zip->addFile($imagePath, $imageNumber . '.png');
    }
    
    $zip->close();
    
    if (!file_exists($zipPath)) {
        throw new Exception('ZIP file was not created');
    }
    
    $zipData = file_get_contents($zipPath);
    $zipBase64 = base64_encode($zipData);

    echo json_encode([
        'success' => true,
        'images' => $base64Images,
        'download' => [
            'filename' => 'wrapped_tiles.zip',
            'data' => $zipBase64,
            'size' => filesize($zipPath)
        ]
    ]);

    cleanupTempDir($tempDir);

} catch (Exception $e) {
    cleanupTempDir($tempDir);
    
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

function cleanupTempDir($tempDir) {
    if (is_dir($tempDir)) {
        $files = glob($tempDir . '/*');
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }
        rmdir($tempDir);
    }
}
