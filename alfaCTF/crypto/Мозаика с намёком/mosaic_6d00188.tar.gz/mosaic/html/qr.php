<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['text']) || empty($input['text'])) {
    http_response_code(400);
    echo json_encode(['error' => 'No text provided']);
    exit;
}

$text = $input['text'];

$command = sprintf(
    'qrencode -s 50 -o - %s',
    escapeshellarg($text)
);

$imageData = shell_exec($command);

if (!$imageData) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to generate QR code']);
    exit;
}

$base64 = 'data:image/png;base64,' . base64_encode($imageData);

echo json_encode([
    'success' => true,
    'image' => $base64,
    'text' => $text
]);
