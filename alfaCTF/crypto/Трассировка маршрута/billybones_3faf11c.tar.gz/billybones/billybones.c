#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "des.h"

#define BUFFER_SIZE 2048
#define TREE_DEPTH 128
#define MAX_PATH_LENGTH 256

#define DEFAULT_FLAG "alfa{XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX}"

static unsigned char secret_seed[16] = {
    0x42, 0x69, 0xDE, 0xAD, 0xBE, 0xEF, 0x13, 0x37,
    0x13, 0x37, 0x42, 0x69, 0xBE, 0xEF, 0xDE, 0xAD,
};

typedef struct {
    unsigned __int128 current_position;
    char path[TREE_DEPTH + 1];
    char encrypted_map[48];  // 32 bytes prefix + 16 bytes packed path
    unsigned __int128 treasure_position;
    int path_length;
    int need_quit;
} game_state_t;


unsigned long generate_random_key() {
    unsigned long key;
    FILE *urandom = fopen("/dev/urandom", "rb");
    if (urandom) {
        if (fread(&key, sizeof(key), 1, urandom) != 1) {
            perror("Failed to read random key");
            exit(1);
        }
        fclose(urandom);
    } else {
        perror("Failed to open /dev/urandom");
        exit(1);
    }
    return key;
}


void generate_treasure_path(unsigned __int128 *position, char *path) {
    unsigned long treasure_key = generate_random_key();
    des_encrypt_ecb(secret_seed, (unsigned char *)position, treasure_key, 16);

    int path_index = 0;
    for (int i = 127; i >= 0 && path_index < TREE_DEPTH; i--) {
        path[path_index] = ((*position >> i) & 1) + '0';
        path_index++;
    }
    path[TREE_DEPTH] = '\0';
}

void pack_path(const char * path, char * packed_path) {
    memset(packed_path, 0, TREE_DEPTH/8);
    for (int i = 0; i < TREE_DEPTH; i++) {
        packed_path[i / 8] |= (path[i] - '0') << (7 - (i % 8));
    }
}

void encrypt_path(char * path, char * encrypted_story) {

    char packed_treasure_path[TREE_DEPTH / 8];
    memset(packed_treasure_path, 0, sizeof(packed_treasure_path));
    pack_path(path, packed_treasure_path);

    char message[48];
    memset(message, 0, sizeof(message));

    strncpy(message, "Flints treasure is hidden here ", 32);

    memcpy(message + 32, packed_treasure_path, 16);

    unsigned long story_des_key = generate_random_key();

    des_encrypt_ecb((unsigned char*)message, (unsigned char*)encrypted_story, story_des_key, 48);
}

void print_message(const char *message) {
    printf("%s", message);
    fflush(stdout);
}

void get_position_description(int depth, char *description) {
    if (depth == 0) {
        strcpy(description, "🏝️  You stand at the very shore of Treasure Island, matey!\n");
        strcat(description, "   Before you the path splits in two...\n");
        strcat(description, "   Will you venture 'left' through the swamps or 'right' through the jungle?\n");
        strcat(description, "   Or perhaps you know the true path to Captain Flint's treasure?\n");
        strcat(description, "   But to reach it, you need to navigate through 128 such forks...\n");

    } else {
        sprintf(description, "🌴 You've wandered into the treacherous heart of the island (%d fathoms from shore, %d fathoms from the treasure)\n", depth, TREE_DEPTH - depth);
        strcat(description, "   The jungle is thick as thieves, but the path still beckons:\n");
        strcat(description, "   Choose 'left' toward the setting sun or 'right' toward dawn\n");
        strcat(description, "   Or 'back' to return like a cautious sea wolf\n");
        strcat(description, "   Speak the true path if you know where Billy's gold is buried!\n");
    }
}

void handle_command(game_state_t *game, const char *command) {
    char response[BUFFER_SIZE];
    char clean_command[256];

    strncpy(clean_command, command, 255);
    clean_command[255] = '\0';
    char *newline = strchr(clean_command, '\n');
    if (newline) *newline = '\0';
    char *carriage = strchr(clean_command, '\r');
    if (carriage) *carriage = '\0';
    
    if (strcmp(clean_command, "left") == 0) {
        if (game->path_length < TREE_DEPTH) {
            game->path[game->path_length] = '0';
            game->path_length++;
            game->current_position = game->current_position * 2 + 0;
            
            sprintf(response, "⬅️  You turn left and venture deeper into the island...\n");
            get_position_description(game->path_length, response + strlen(response));
        } else {
            strcpy(response, "❌ Blast it! The swamps have become too treacherous to go further, matey!\n");
        }
    } else if (strcmp(clean_command, "right") == 0) {
        if (game->path_length < TREE_DEPTH) {
            game->path[game->path_length] = '1';
            game->path_length++;
            game->current_position = game->current_position * 2 + 1;

            sprintf(response, "➡️  You turn right and venture deeper into the island...\n");
            get_position_description(game->path_length, response + strlen(response));
        } else {
            strcpy(response, "❌ Blast it! The jungle has become too thick to go further, matey!\n");
        }
    } else if (strcmp(clean_command, "back") == 0) {
        if (game->path_length > 0) {
            game->path_length--;
            game->path[game->path_length] = '\0';
            game->current_position = (game->current_position - 1) / 2;

            sprintf(response, "🔙 Maybe it was a wrong way, you return to previous position...\n");
            get_position_description(game->path_length, response + strlen(response));
        } else {
            strcpy(response, "❌ You're already on the ship!\n");
        }
    } else if (strcmp(clean_command, "home") == 0 || strcmp(clean_command, "restart") == 0) {
        // Return to starting position
        game->path_length = 0;
        game->current_position = 0;
        memset(game->path, 0, TREE_DEPTH + 1);
        
        sprintf(response, "🏠 You've returned to the ship at the shore of Treasure Island!\n");
        strcat(response, "   Ready for a fresh adventure, matey!\n\n");
        get_position_description(game->path_length, response + strlen(response));
    } else if (strncmp(clean_command, "path ", 5) == 0) {
        // Handle complete path submission
        char submitted_path[TREE_DEPTH + 1];
        strncpy(submitted_path, clean_command + 5, TREE_DEPTH);
        submitted_path[TREE_DEPTH] = '\0';
        
        int valid = 1;
        size_t path_len = strlen(submitted_path);
        for (size_t i = 0; i < path_len; i++) {
            if (submitted_path[i] != '0' && submitted_path[i] != '1') {
                valid = 0;
                break;
            }
        }
        
        if (!valid) {
            strcpy(response, "❌ The path can only contain zeros and ones, landlubber!\n");
        } else {
            if (strcmp(submitted_path, game->path) == 0) {
                sprintf(response, "🎉 SHIVER ME TIMBERS! YOU'VE FOUND CAPTAIN FLINT'S TREASURE!\n");
                strcat(response, "🏴‍☠️  The ancient doubloons and legendary flag are yours: ");
                strcat(response, getenv("FLAG") ? getenv("FLAG") : DEFAULT_FLAG);
                strcat(response, "\n");
                strcat(response, "   Fifteen men on a dead man's chest, yo-ho-ho and a bottle of rum!\n");
                strcat(response, "   Don't forget the story of young Bobby who loved money...\n");
                game->need_quit = 1;
            } else {
                strcpy(response, "💀 Arr! Damn it! No treasure here! We'll have to go back...\n");
            }
        }
    } else if (strcmp(clean_command, "message") == 0) {
        strcpy(response, "📜 Billy Bones' encrypted map lies before ye!\n");
        strcat(response, "=============================================\n");

        char hex_message[192];
        for (int i = 0; i < 48; i++) {
            sprintf(hex_message + i*2, "%02x", (unsigned char)game->encrypted_map[i]);
        }
        hex_message[96] = '\0';
        strcat(response, hex_message);
        strcat(response, "\n\n");

    } else if (strcmp(clean_command, "help") == 0) {
        strcpy(response, "🏴‍☠️  TREASURE ISLAND NAVIGATION MAP 🏴‍☠️\n");
        strcat(response, "=====================================\n");
        strcat(response, "You need these commands, matey:\n");
        strcat(response, "  left  - Take the left path through the swamps\n");
        strcat(response, "  right - Take the right path through the jungle\n");
        strcat(response, "  back  - Return to the previous position\n");
        strcat(response, "  home  - Return to the starting position (same as 'restart')\n");
        strcat(response, "  message - Show Billy Bones' encrypted treasure map story\n");
        strcat(response, "  path <binary> - Move to the supposed treasure location at once (e.g., path 0101), but note that you need to specify 128 such forks...\n");
        strcat(response, "  help  - Show this navigation map again\n");
        strcat(response, "  quit  - Give up and return to port\n");
        strcat(response, "\nThe treasure chest is buried in the heart of the island, you'll have to walk far to find it\n");
        strcat(response, "If you don't find it, return to the ship and start over!\n");
    } else if (strcmp(clean_command, "quit") == 0) {
        strcpy(response, "⚓ Safe sailing back home!\n");
        game->need_quit = 1;
    } else {
        strcpy(response, "❓ I don't understand what you mean! Type 'help' to study the navigation map!\n");
    }

    if (game->current_position == game->treasure_position) {
        sprintf(response, "🎉 SHIVER ME TIMBERS! YOU'VE FOUND CAPTAIN FLINT'S TREASURE ON FOOT!\n");
        strcat(response, "🏴‍☠️  The ancient doubloons and legendary flag are yours: ");
        strcat(response, getenv("FLAG") ? getenv("FLAG") : DEFAULT_FLAG);
        strcat(response, "\n");
        strcat(response, "   Fifteen men on a dead man's chest, yo-ho-ho and a bottle of rum!\n");
        strcat(response, "   Don't forget the story of young Bobby who loved money...\n");
        game->need_quit = 1;
    }

    print_message(response);
}

void run_game() {
    game_state_t *game = malloc(sizeof(game_state_t));
    char buffer[BUFFER_SIZE];
    char welcome[BUFFER_SIZE];

    generate_treasure_path(&game->treasure_position, game->path);
    encrypt_path(game->path, game->encrypted_map);
    game->path_length = 0;
    game->current_position = 0;
    game->need_quit = 0;
    
    strcpy(welcome, "🏴‍☠️  AHOY, BRAVE SOUL! WELCOME TO TREASURE ISLAND! 🏴‍☠️\n");
    strcat(welcome, "=====================================================\n");
    strcat(welcome, "Ye seek Captain Flint's legendary treasure, do ye?\n");
    strcat(welcome, "But beware! Old Billy Bones was cunning as a sea serpent...\n");
    strcat(welcome, "He encrypted his treasure map with a one-time key, then cast it into the depths!\n");
    strcat(welcome, "Only Billy knew where the gold was buried, and he took this secret to his grave with him.\n");
    strcat(welcome, "The encrypted map remains, but the key... lost forever in the briny deep!\n\n");

    strcat(welcome, "📜 Here be Billy Bones' encrypted map, matey!\n");
    strcat(welcome, "🔐 Encrypted with his one-time key (now lost to the sea):\n");

    char hex_message[192];
    for (int i = 0; i < 48; i++) {
        sprintf(hex_message + i*2, "%02x", (unsigned char)game->encrypted_map[i]);
    }
    hex_message[96] = '\0';
    strcat(welcome, hex_message);
    strcat(welcome, "\n\n");

    
    get_position_description(0, welcome + strlen(welcome));

    print_message(welcome);

    while (!game->need_quit) {
        printf("> ");
        if (fgets(buffer, BUFFER_SIZE, stdin) == NULL) {
            break;
        }

        handle_command(game, buffer);
    }

    print_message("⚓ Farewell, brave adventurer! May your next voyage be filled with riches!\n");
    free(game);
}

int main() {
    run_game();

    return 0;
}
