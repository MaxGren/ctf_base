#ifndef DES_H
#define DES_H

#include <stdint.h>

// DES key size (64 bits = 8 bytes)
#define DES_KEY_SIZE 8

// DES block size (64 bits = 8 bytes)
#define DES_BLOCK_SIZE 8

// Function declarations

/**
 * Generate 16 subkeys from the main DES key
 * @param key: 64-bit DES key as unsigned long
 * @param subkeys: Output array of 16 subkeys (each 6 bytes)
 */
void des_generate_subkeys(uint64_t key, uint8_t subkeys[16][6]);

/**
 * Encrypt a single 64-bit block using DES
 * @param plaintext: 8-byte input block
 * @param ciphertext: 8-byte output block
 * @param key: 64-bit DES key as unsigned long
 */
void des_encrypt_block(const uint8_t *plaintext, uint8_t *ciphertext, unsigned long key);

/**
 * Decrypt a single 64-bit block using DES
 * @param ciphertext: 8-byte input block
 * @param plaintext: 8-byte output block
 * @param key: 64-bit DES key as unsigned long
 */
void des_decrypt_block(const uint8_t *ciphertext, uint8_t *plaintext, unsigned long key);

/**
 * Encrypt data using DES in ECB mode
 * @param input: Input data
 * @param output: Output data (same size as input)
 * @param key: 64-bit DES key as unsigned long
 * @param length: Length of input/output data in bytes
 */
void des_encrypt_ecb(const uint8_t *input, uint8_t *output, unsigned long key, int length);

#endif // DES_H
